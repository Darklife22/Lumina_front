// src/app/app.routes.ts
import { Routes } from '@angular/router';
import { requireRole } from './core/role.guard';

export const routes: Routes = [
  // =========================
  // LOGIN
  // =========================
  {
    path: 'login',
    loadComponent: () =>
      import('./pages/login/login.component').then(m => m.LoginComponent),
  },

  // =========================
  // ADMIN (layout + children)
  // =========================
  {
    path: 'admin',
    canActivate: [requireRole('admin')],
    loadComponent: () =>
      import('./pages/admin/admin-layout.component').then(m => m.AdminLayoutComponent),
    children: [
      // Dashboard
      {
        path: '',
        loadComponent: () =>
          import('./pages/admin/dashboard.component').then(m => m.AdminDashboardComponent),
        data: { title: 'Panel de control' },
      },

      // =========================
      // Usuarios base
      // =========================
      {
        path: 'usuarios',
        loadComponent: () =>
          import('./pages/admin/admin-usuarios.component').then(m => m.AdminUsuariosComponent),
        data: { title: 'Usuarios' },
      },

      // =========================
      // Catálogos globales
      // =========================
      {
        path: 'areas',
        loadComponent: () =>
          import('./pages/admin/areas.component').then(m => m.AreasComponent),
        data: { title: 'Gestión de Áreas' },
      },

      {
        path: 'responsables',
        loadComponent: () =>
          import('./pages/admin/responsables-academicos.component').then(m => m.ResponsablesAcademicosComponent),
        data: { title: 'Responsables académicos' },
      },

      {
        path: 'evaluadores',
        loadComponent: () =>
          import('./pages/admin/evaluadores.component').then(m => m.EvaluadoresComponent),
        data: { title: 'Evaluadores' },
      },

      // =========================
      // Importaciones globales
      // =========================
      {
        path: 'importaciones',
        loadComponent: () =>
          import('./pages/admin/importar-inscritos.component').then(m => m.ImportarInscritosComponent),
        data: { title: 'Importación de inscritos' },
      },

      // =============================
      // EDICIONES / COMPETENCIAS
      // =============================
      {
        path: 'ediciones',
        loadComponent: () =>
          import('./pages/admin/admin-ediciones.component').then(m => m.AdminEdicionesComponent),
        data: { title: 'Ediciones / Competencias' },
      },

      // =============================
      // EDICIÓN SCOPED (POR ID)
      // =============================
      {
        path: 'ediciones/:id',
        children: [
          // --- CONFIGURACIÓN CENTRAL ---
          {
            path: 'configuracion',
            loadComponent: () =>
              import('./pages/admin/edicion-configuracion.component')
                .then(m => m.EdicionConfiguracionComponent),
            data: { title: 'Configuración de la Competencia' },
          },

          // --- ROLES POR EDICIÓN ---
          {
            path: 'roles',
            loadComponent: () =>
              import('./pages/admin/edicion-roles.component')
                .then(m => m.EdicionRolesComponent),
            data: { title: 'Roles de la Competencia' },
          },

          // --- INSCRITOS POR EDICIÓN ---
          {
            path: 'inscritos',
            loadComponent: () =>
              import('./pages/admin/edicion-inscritos.component')
                .then(m => m.EdicionInscritosComponent),
            data: { title: 'Inscritos de la Competencia' },
          },

          // --- CLASIFICACIÓN / PROCESOS ---
          {
            path: 'clasificacion',
            loadComponent: () =>
              import('./pages/admin/edicion-clasificacion.component')
                .then(m => m.EdicionClasificacionComponent),
            data: { title: 'Clasificación' },
          },

          {
            path: 'medallero',
            loadComponent: () =>
              import('./pages/admin/edicion-medallero.component')
                .then(m => m.EdicionMedalleroComponent),
            data: { title: 'Medallero' },
          },

          // Alias defensivo
          {
            path: '',
            redirectTo: 'configuracion',
            pathMatch: 'full',
          },
        ],
      },

      // =============================
      // Filtros / utilitarios
      // =============================
      {
        path: 'filtro-clasificacion',
        loadComponent: () =>
          import('./pages/admin/filtro-umbral.component').then(m => m.FiltroUmbralComponent),
        data: { title: 'Filtro por Umbral' },
      },
    ],
  },

  // =========================
  // RESPONSABLE DE ÁREA
  // =========================
  {
    path: 'responsable',
    canActivate: [requireRole('responsable_area')],
    loadComponent: () =>
      import('./pages/responsable/responsable-layout.component').then(m => m.ResponsableLayoutComponent),
    children: [
      {
        path: '',
        loadComponent: () =>
          import('./pages/responsable/dashboard.component').then(m => m.ResponsableDashboardComponent),
        data: { title: 'Panel responsable' },
      },
      {
        path: 'listas',
        loadComponent: () =>
          import('./pages/responsable/competidores.component').then(m => m.CompetidoresComponent),
        data: { title: 'Listas de competidores' },
      },
      {
        path: 'desclasificados',
        loadComponent: () =>
          import('./pages/responsable/desclasificados.component').then(m => m.DesclasificadosComponent),
        data: { title: 'Informe de desclasificados' },
      },
      {
        path: 'no-clasificados',
        loadComponent: () =>
          import('./pages/responsable/no-clasificados.component').then(m => m.NoClasificadosComponent),
        data: { title: 'No clasificados' },
      },

      // Alias
      { path: 'competidores', redirectTo: 'listas', pathMatch: 'full' },
    ],
  },

  // =========================
  // EVALUADOR
  // =========================
  {
    path: 'evaluador',
    canActivate: [requireRole('evaluador')],
    loadComponent: () =>
      import('./pages/evaluador/evaluador-layout.component').then(m => m.EvaluadorLayoutComponent),
    children: [
      {
        path: '',
        loadComponent: () =>
          import('./pages/evaluador/evaluador-dashboard.component').then(m => m.EvaluadorDashboardComponent),
        data: { title: 'Panel del Evaluador' },
      },
      {
        path: 'registrar',
        loadComponent: () =>
          import('./pages/evaluador/registrar-calificaciones.component')
            .then(m => m.RegistrarCalificacionesComponent),
        data: { title: 'Registrar calificaciones' },
      },
      {
        path: 'historial',
        loadComponent: () =>
          import('./pages/evaluador/historial-calificaciones.component')
            .then(m => m.HistorialCalificacionesComponent),
        data: { title: 'Historial de calificaciones' },
      },
    ],
  },

  // =========================
  // CONSULTA
  // =========================
  {
    path: 'consulta',
    canActivate: [requireRole('consulta')],
    loadComponent: () =>
      import('./pages/consulta/consulta.component').then(m => m.default),
  },

  // =========================
  // HOME
  // =========================
  {
    path: '',
    loadComponent: () =>
      import('./pages/home/home.component').then(m => m.HomeComponent),
  },

  // =========================
  // FALLBACK
  // =========================
  { path: '**', redirectTo: '' },
];
