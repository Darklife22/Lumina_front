import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AuthService } from '../../core/auth.service';

function pathForRole(role: string | null) {
  switch (role) {
    case 'admin': return '/admin';
    case 'responsable_area': return '/responsable';
    case 'evaluador': return '/evaluador';
    case 'consulta': return '/consulta';
    default: return '/login';
  }
}

@Component({
  standalone: true,
  selector: 'app-home',
  imports: [CommonModule],
  template: `
    <section class="p-6 text-slate-800">
      <h2 class="text-xl font-semibold">Oh! SanSi</h2>
      <p class="text-slate-600">Redirigiendo según tu rol...</p>
      <!-- Botón de escape por si algo falla en el router -->
      <div class="mt-4">
        <a routerLink="/login" class="underline text-blue-700">Ir al login</a>
      </div>
    </section>
  `
})
export class HomeComponent implements OnInit {
  private auth = inject(AuthService);
  private router = inject(Router);

  ngOnInit() {
    // Reevaluamos y redirigimos en el próximo tick para asegurar que el Router esté listo
    queueMicrotask(() => {
      const role = this.auth.role();
      const target = pathForRole(role);
      if (this.router.url !== target) {
        this.router.navigateByUrl(target);
      }
    });
  }
}
