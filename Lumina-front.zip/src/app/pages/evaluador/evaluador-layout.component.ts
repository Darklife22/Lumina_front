import { Component, effect, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  Router,
  RouterLink,
  RouterLinkActive,
  RouterOutlet,
  NavigationEnd,
} from '@angular/router';
import { filter } from 'rxjs/operators';
import { AuthService } from '../../core/auth.service';
import { ApiService } from '../../core/api.service';

@Component({
  standalone: true,
  selector: 'app-evaluador-layout',
  imports: [CommonModule, RouterLink, RouterLinkActive, RouterOutlet],
  template: `
    <div class="h-screen w-screen bg-slate-100 text-slate-800 overflow-hidden flex">

      <!-- Overlay móvil -->
      <div
        *ngIf="sidebarOpen()"
        class="fixed inset-0 z-30 bg-black/50 md:hidden"
        (click)="toggleSidebar()"
      ></div>

      <!-- Sidebar -->
      <aside
        class="fixed md:static top-0 left-0 z-40 h-full w-72 md:w-64
               bg-gradient-to-b from-[#0b1f46] via-[#13366f] to-[#1a55a9] text-white
               transform transition-transform duration-300 ease-in-out md:translate-x-0 shadow-lg flex flex-col"
        [class.-translate-x-full]="!sidebarOpen() && isMobile()"
      >
        <!-- Scroll interno del sidebar -->
        <div class="flex-1 overflow-y-auto p-4">
          <div class="flex items-center gap-2 mb-6">
            <img src="/logo/logo.png" alt="Logo" class="h-8 w-auto" />
            <span class="font-bold tracking-wide text-lg">Oh! SanSi</span>
          </div>

          <nav class="space-y-1 text-sm">
            <a
              routerLink="/evaluador"
              routerLinkActive="bg-white/20"
              [routerLinkActiveOptions]="{ exact: true }"
              class="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-white/10 transition"
            >
              <i class="bi bi-house-door"></i>
              <span>Inicio</span>
            </a>

            <a
              routerLink="/evaluador/registrar"
              routerLinkActive="bg-white/20"
              class="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-white/10 transition"
            >
              <i class="bi bi-pencil-square"></i>
              <span>Registrar calificaciones</span>
            </a>

            <a
              routerLink="/evaluador/historial"
              routerLinkActive="bg-white/20"
              class="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-white/10 transition"
            >
              <i class="bi bi-journal-text"></i>
              <span>Historial de calificaciones</span>
            </a>

            <a
              routerLink="/evaluador/mis-evaluaciones"
              routerLinkActive="bg-white/20"
              class="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-white/10 transition"
            >
              <i class="bi bi-clipboard2-check"></i>
              <span>Mis evaluaciones</span>
            </a>

            <a
              routerLink="/evaluador/progreso"
              routerLinkActive="bg-white/20"
              class="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-white/10 transition"
            >
              <i class="bi bi-graph-up"></i>
              <span>Progreso</span>
            </a>

            <a
              routerLink="/evaluador/resultados"
              routerLinkActive="bg-white/20"
              class="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-white/10 transition"
            >
              <i class="bi bi-file-earmark-check"></i>
              <span>Resultados</span>
            </a>
          </nav>
        </div>

        <!-- Footer usuario -->
        <div class="bg-white/10 rounded-xl p-3 m-4 mt-0">
          <div class="text-xs opacity-80 truncate">
            {{ userName() || 'Evaluador' }}
          </div>
          <div class="text-[11px] opacity-70">Evaluador</div>
          <button
            (click)="logout()"
            class="mt-3 w-full text-sm rounded-lg bg-white/20 hover:bg-white/25 py-1.5 transition flex items-center justify-center gap-1"
          >
            <i class="bi bi-box-arrow-right"></i>
            <span>Salir</span>
          </button>
        </div>
      </aside>

      <!-- Contenido -->
      <main class="flex-1 h-full flex flex-col">
        <!-- Header fijo como en admin -->
        <header
          class="sticky top-0 z-20 bg-white border-b border-slate-200/70 shadow-sm flex-none"
        >
          <div class="w-full px-4 py-4 flex items-center justify-between">
            <div>
              <h1 class="text-2xl md:text-3xl font-bold tracking-tight text-slate-800">
                {{ pageTitle() }}
              </h1>
            </div>

            <button
              (click)="toggleSidebar()"
              class="md:hidden inline-flex items-center justify-center w-10 h-10 rounded-lg border border-slate-200 hover:bg-slate-50"
            >
              <i class="bi bi-list text-xl"></i>
            </button>
          </div>
        </header>

        <!-- Área de contenido: mismo patrón h-0 + overflow-y-auto -->
        <section class="flex-1 w-full h-0 overflow-y-auto px-4 py-4">
          <router-outlet></router-outlet>
        </section>
      </main>
    </div>
  `,
})
export class EvaluadorLayoutComponent {
  private auth = inject(AuthService);
  private api = inject(ApiService);
  private router = inject(Router);

  sidebarOpen = signal(false);
  userName = signal(this.auth.user()?.nombre ?? null);
  pageTitle = signal('Panel del Evaluador');

  constructor() {
    // Redirección inmediata al desloguearse
    effect(() => {
      if (!this.auth.isLoggedIn()) this.router.navigateByUrl('/login');
    });

    // Cerrar menú en navegación móvil y actualizar título desde data.title
    this.router.events
      .pipe(filter((e) => e instanceof NavigationEnd))
      .subscribe(() => {
        if (this.isMobile()) this.sidebarOpen.set(false);

        let r = this.router.routerState.snapshot.root;
        while (r.firstChild) r = r.firstChild;
        this.pageTitle.set(r.data?.['title'] || 'Panel del Evaluador');
      });
  }

  isMobile() {
    return window.innerWidth < 768;
  }

  toggleSidebar() {
    this.sidebarOpen.set(!this.sidebarOpen());
  }

  logout() {
    this.api.post('/logout', {}).subscribe({
      next: () => {
        this.auth.clear();
        this.router.navigateByUrl('/login');
      },
      error: () => {
        this.auth.clear();
        this.router.navigateByUrl('/login');
      },
    });
  }
}
