import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';

type Row = {
  id: number;
  evaluacion_id: number;
  nota: number;
  comentario: string | null;
  fecha_nota: string;
  area: string;
  nivel: string;
  participante: string;
  participante_ci: string;
  evaluador_nombre: string | null;
  evaluador_apellidos: string | null;
};

type Meta = { page: number; per_page: number; total: number; total_pages: number; };

@Component({
  standalone: true,
  selector: 'app-historial-calificaciones',
  imports: [CommonModule, FormsModule],
  template: `
  <section class="space-y-4">
    <!-- Filtros -->
    <div class="bg-white rounded-2xl border border-slate-200 p-4">
      <div class="grid gap-3 md:grid-cols-5">
        <div class="md:col-span-2">
          <label class="text-xs text-slate-500">Buscar</label>
          <input [(ngModel)]="q" (keyup.enter)="search()" placeholder="Nombre, CI, área, nivel, comentario"
                 class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-200 focus:border-blue-300">
        </div>
        <div>
          <label class="text-xs text-slate-500">Desde</label>
          <input type="date" [(ngModel)]="from"
                 class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
        </div>
        <div>
          <label class="text-xs text-slate-500">Hasta</label>
          <input type="date" [(ngModel)]="to"
                 class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
        </div>
        <div class="flex items-end gap-2">
          <button (click)="search()" class="rounded-lg bg-[#0f3f94] hover:bg-[#0d3580] text-white px-3 py-2 text-sm">
            <i class="bi bi-search"></i> Filtrar
          </button>
          <button (click)="clear()" class="rounded-lg bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50">
            Limpiar
          </button>
        </div>
      </div>

      <div class="mt-3 flex flex-wrap items-center gap-2">
        <div>
          <label class="text-xs text-slate-500">Área</label>
          <input [(ngModel)]="area" class="ml-2 rounded-lg border border-slate-300 px-2 py-1 text-sm">
        </div>
        <div>
          <label class="text-xs text-slate-500">Nivel</label>
          <input [(ngModel)]="nivel" class="ml-2 rounded-lg border border-slate-300 px-2 py-1 text-sm">
        </div>
        <div class="ml-auto flex items-center gap-2">
          <button (click)="export('csv')" class="rounded-lg bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50">
            <i class="bi bi-filetype-csv"></i> Exportar CSV
          </button>
          <button (click)="export('pdf')" class="rounded-lg bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50">
            <i class="bi bi-file-pdf"></i> Exportar PDF
          </button>
        </div>
      </div>
    </div>

    <!-- Tabla -->
    <div class="bg-white rounded-2xl border border-slate-200 p-0">
      <div class="flex items-center justify-between p-3">
        <div class="font-semibold">Historial ({{ meta().total }} reg.)</div>
        <div class="text-xs text-slate-500">Notas realizadas por ti</div>
      </div>
      <div class="overflow-auto">
        <table class="min-w-full text-sm">
          <thead class="bg-slate-50 sticky top-0">
            <tr class="text-left text-slate-600">
              <th class="py-2 px-3">Fecha</th>
              <th class="py-2 px-3">Participante</th>
              <th class="py-2 px-3">CI</th>
              <th class="py-2 px-3">Área</th>
              <th class="py-2 px-3">Nivel</th>
              <th class="py-2 px-3">Nota</th>
              <th class="py-2 px-3">Comentario</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngIf="rows().length === 0">
              <td colspan="7" class="text-center text-slate-400 py-4">No hay registros</td>
            </tr>
            <tr *ngFor="let r of rows()" class="border-t border-slate-100">
              <td class="py-2 px-3 whitespace-nowrap">{{ r.fecha_nota | date:'short' }}</td>
              <td class="py-2 px-3">{{ r.participante }}</td>
              <td class="py-2 px-3">{{ r.participante_ci }}</td>
              <td class="py-2 px-3">{{ r.area }}</td>
              <td class="py-2 px-3">{{ r.nivel }}</td>
              <td class="py-2 px-3 font-semibold">{{ r.nota }}</td>
              <td class="py-2 px-3 max-w-[380px] truncate" title="{{ r.comentario || '' }}">
                {{ r.comentario || '—' }}
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Paginación -->
      <div class="flex items-center justify-between p-3 text-sm">
        <div class="text-slate-500">
          Página {{ meta().page }} de {{ meta().total_pages }} • {{ meta().total }} registros
        </div>
        <div class="flex items-center gap-2">
          <button (click)="goTo(meta().page - 1)" [disabled]="meta().page <= 1"
                  class="rounded-lg bg-white border border-slate-200 px-3 py-1.5 disabled:opacity-50 hover:bg-slate-50">
            <i class="bi bi-chevron-left"></i>
          </button>
          <button (click)="goTo(meta().page + 1)" [disabled]="meta().page >= meta().total_pages"
                  class="rounded-lg bg-white border border-slate-200 px-3 py-1.5 disabled:opacity-50 hover:bg-slate-50">
            <i class="bi bi-chevron-right"></i>
          </button>
          <select [(ngModel)]="perPage" (change)="search()"
                  class="rounded-lg border border-slate-300 px-2 py-1">
            <option [value]="10">10</option>
            <option [value]="20">20</option>
            <option [value]="50">50</option>
            <option [value]="100">100</option>
          </select>
        </div>
      </div>
    </div>
  </section>
  `
})
export class HistorialCalificacionesComponent {
  private api = inject(ApiService);

  // filtros
  q = '';
  from = '';
  to = '';
  area = '';
  nivel = '';

  // paginación
  page = 1;
  perPage = 20;

  rows = signal<Row[]>([]);
  meta = signal<Meta>({ page: 1, per_page: 20, total: 0, total_pages: 0 });

  ngOnInit() { this.search(); }

  private params() {
    const p: any = { page: this.page, per_page: this.perPage };
    if (this.q) p.q = this.q;
    if (this.from) p.from = this.from;
    if (this.to) p.to = this.to;
    if (this.area) p.area = this.area;
    if (this.nivel) p.nivel = this.nivel;
    return p;
  }

 search() {
  const params = new URLSearchParams(this.params()).toString();
  this.api.get<{data: Row[]; meta: Meta; diag?: any; ok?:boolean; message?:string; error?:string}>(`/evaluador/historial?${params}`)
    .subscribe({
      next: (res) => {
        // Si el back respondió 422 con diag
        if ((res as any)?.ok === false && (res as any)?.message) {
          console.warn('Diagnóstico backend:', (res as any).diag);
          this.rows.set([]);
          this.meta.set({ page: 1, per_page: this.perPage, total: 0, total_pages: 0 });
          alert((res as any).message + ' (revisa consola para diag)');
          return;
        }
        this.rows.set(res.data || []);
        this.meta.set(res.meta || { page: 1, per_page: this.perPage, total: 0, total_pages: 0 });
        this.page = this.meta().page;
        this.perPage = this.meta().per_page;
        if ((res as any)?.diag) console.log('Diag backend:', (res as any).diag);
      },
      error: (err) => {
        console.error('Error /historial:', err?.error || err);
        this.rows.set([]);
        this.meta.set({ page: 1, per_page: this.perPage, total: 0, total_pages: 0 });
        alert(err?.error?.message || 'No se pudo cargar el historial.');
      }
    });
}


  clear() {
    this.q = ''; this.from = ''; this.to = ''; this.area = ''; this.nivel = '';
    this.page = 1; this.search();
  }

  goTo(p: number) {
    if (p < 1 || p > this.meta().total_pages) return;
    this.page = p; this.search();
  }

  export(format: 'csv'|'pdf') {
    const params = new URLSearchParams(this.params()).toString();
    // Usa el baseURL de tu ApiService si lo manejas global, si no, ajusta:
    // Ajusta la base URL según tu configuración real de ApiService
        // Ajusta la base URL según tu entorno, por ejemplo usando environment.apiUrl
                window.open(`${(window as any).environment?.apiUrl || ''}/evaluador/historial/export?format=${format}&${params}`, '_blank');
  }
}
