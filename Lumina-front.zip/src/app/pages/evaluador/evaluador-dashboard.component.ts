import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  standalone: true,
  selector: 'app-evaluador-dashboard',
  imports: [CommonModule],
  template: `
    <div class="space-y-4">
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="bg-white rounded-2xl border border-slate-200 p-4">
          <div class="text-slate-500 text-sm flex items-center gap-2"><i class="bi bi-clipboard2-check"></i> Asignadas</div>
          <div class="text-3xl font-bold mt-1">12</div>
        </div>
        <div class="bg-white rounded-2xl border border-slate-200 p-4">
          <div class="text-slate-500 text-sm flex items-center gap-2"><i class="bi bi-check2-circle"></i> Completadas</div>
          <div class="text-3xl font-bold mt-1 text-emerald-600">8</div>
        </div>
        <div class="bg-white rounded-2xl border border-slate-200 p-4">
          <div class="text-slate-500 text-sm flex items-center gap-2"><i class="bi bi-hourglass-split"></i> Pendientes</div>
          <div class="text-3xl font-bold mt-1 text-amber-600">4</div>
        </div>
        <div class="bg-white rounded-2xl border border-slate-200 p-4">
          <div class="text-slate-500 text-sm flex items-center gap-2"><i class="bi bi-trophy"></i> Clasificados</div>
          <div class="text-3xl font-bold mt-1 text-blue-600">3</div>
        </div>
      </div>

      <div class="bg-white rounded-2xl border border-slate-200 p-4">
        <h2 class="text-base font-semibold mb-2">Bienvenido</h2>
        <p class="text-sm text-slate-600">Usa el menú para registrar calificaciones o revisar tus evaluaciones.</p>
      </div>
    </div>
  `
})
export class EvaluadorDashboardComponent {}
