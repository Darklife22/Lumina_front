import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';

type Item = {
  id: number;
  nombre: string;
  ci: string;
  area: string;
  nivel: string;
  unidad_educativa: string | null;
  profesor: string | null;
  created_at: string;
  calificacion: null | {
    id: number;
    nota: number;
    comentario: string | null;
    updated_at: string;
  };
  estado_final?: string | null;
  puede_descalificar?: boolean;
};

type PageMeta = {
  current_page: number;
  per_page: number;
  total: number;
  last_page: number;
  edicion_archivada?: boolean;
};

type PageRes = {
  data: Item[];
  meta: PageMeta;
};

@Component({
  standalone: true,
  selector: 'app-registrar-calificaciones',
  imports: [CommonModule, FormsModule],
  template: `
  <section class="space-y-4">
    <!-- HEADER / RESUMEN -->
    <div class="bg-white rounded-2xl border border-slate-200 p-4 md:p-5 shadow-sm">
      <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div class="space-y-1.5">
          <div class="inline-flex items-center gap-2">
            <span class="inline-flex h-8 w-8 items-center justify-center rounded-xl bg-indigo-100 text-indigo-700">
              <i class="bi bi-check2-square text-lg"></i>
            </span>
            <div>
              <h1 class="text-lg md:text-xl font-bold text-slate-900">
                Registrar calificaciones
              </h1>
              <p class="text-xs md:text-sm text-slate-500">
                Escala de notas {{ notaMin }}–{{ notaMax }} · Comentario opcional (hasta 250 caracteres).
              </p>
            </div>
          </div>

          <div class="flex flex-wrap gap-2 mt-2 text-xs">
            <span class="inline-flex items-center gap-1 rounded-full bg-emerald-50 text-emerald-700 px-2.5 py-1 border border-emerald-100">
              <span class="inline-flex h-1.5 w-1.5 rounded-full bg-emerald-500"></span>
              {{ countCalificados() }} calificados
            </span>
            <span class="inline-flex items-center gap-1 rounded-full bg-slate-50 text-slate-600 px-2.5 py-1 border border-slate-200">
              <span class="inline-flex h-1.5 w-1.5 rounded-full bg-slate-400"></span>
              {{ countSinCalificar() }} sin calificar
            </span>
          </div>

          <div *ngIf="edicionArchivada"
               class="mt-2 inline-flex items-center gap-2 text-[11px] md:text-xs text-amber-800 bg-amber-50 border border-amber-200 rounded-lg px-2.5 py-1.5">
            <i class="bi bi-info-circle-fill"></i>
            <span>Esta edición está archivada. No se permiten nuevas descalificaciones.</span>
          </div>
        </div>

        <div class="w-full md:w-80">
          <label class="text-[11px] font-medium text-slate-500 mb-1 block">
            Buscar competidor
          </label>
          <div class="relative">
            <i class="bi bi-search absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-sm"></i>
            <input
              [(ngModel)]="q"
              (ngModelChange)="onSearchChange()"
              placeholder="Nombre, CI, área o nivel"
              class="w-full rounded-xl border border-slate-300 bg-slate-50/60 px-8 py-2 text-sm outline-none
                     focus:bg-white focus:ring-2 focus:ring-indigo-100 focus:border-indigo-300 transition">
          </div>
        </div>
      </div>
    </div>

    <!-- FILTROS -->
    <div class="bg-white rounded-2xl border border-slate-200 p-3 md:p-4">
      <div class="flex flex-col lg:flex-row lg:items-center gap-3 lg:gap-4">
        <div class="flex-1 flex flex-wrap gap-2">
          <!-- Área -->
          <div class="min-w-[150px]">
            <label class="text-[11px] text-slate-500 block mb-1">Área</label>
            <select
              [(ngModel)]="fArea"
              (ngModelChange)="onFilterChange()"
              class="w-full rounded-xl border border-slate-300 px-2.5 py-1.5 text-xs md:text-sm bg-slate-50/60
                     focus:bg-white focus:ring-2 focus:ring-indigo-100 focus:border-indigo-300">
              <option value="todos">Todas las áreas</option>
              <option *ngFor="let a of areas" [value]="a">{{ a }}</option>
            </select>
          </div>

          <!-- Nivel -->
          <div class="min-w-[150px]">
            <label class="text-[11px] text-slate-500 block mb-1">Nivel</label>
            <select
              [(ngModel)]="fNivel"
              (ngModelChange)="onFilterChange()"
              class="w-full rounded-xl border border-slate-300 px-2.5 py-1.5 text-xs md:text-sm bg-slate-50/60
                     focus:bg-white focus:ring-2 focus:ring-indigo-100 focus:border-indigo-300">
              <option value="todos">Todos los niveles</option>
              <option *ngFor="let n of niveles" [value]="n">{{ n }}</option>
            </select>
          </div>

          <!-- Unidad educativa -->
          <div class="min-w-[180px]">
            <label class="text-[11px] text-slate-500 block mb-1">Unidad educativa</label>
            <select
              [(ngModel)]="fUnidad"
              (ngModelChange)="onFilterChange()"
              class="w-full rounded-xl border border-slate-300 px-2.5 py-1.5 text-xs md:text-sm bg-slate-50/60
                     focus:bg-white focus:ring-2 focus:ring-indigo-100 focus:border-indigo-300">
              <option value="todos">Todas las unidades</option>
              <option *ngFor="let u of unidades" [value]="u">{{ u }}</option>
            </select>
          </div>

          <!-- Estado calificación -->
          <div class="min-w-[180px]">
            <label class="text-[11px] text-slate-500 block mb-1">Estado de calificación</label>
            <select
              [(ngModel)]="fEstado"
              (ngModelChange)="onFilterChange()"
              class="w-full rounded-xl border border-slate-300 px-2.5 py-1.5 text-xs md:text-sm bg-slate-50/60
                     focus:bg-white focus:ring-2 focus:ring-indigo-100 focus:border-indigo-300">
              <option value="todos">Todos los competidores</option>
              <option value="sin_calificar">Solo sin calificar</option>
              <option value="calificados">Solo calificados</option>
            </select>
          </div>
        </div>

        <!-- Chips filtros activos -->
        <div class="flex-1 flex flex-wrap gap-2 justify-start lg:justify-end text-[11px] md:text-xs text-slate-500">
          <span *ngIf="fArea !== 'todos'" class="px-2.5 py-1 rounded-full bg-slate-50 border border-slate-200 flex items-center gap-1">
            <i class="bi bi-ui-radios-grid text-[10px]"></i> Área: {{ fArea }}
          </span>
          <span *ngIf="fNivel !== 'todos'" class="px-2.5 py-1 rounded-full bg-slate-50 border border-slate-200 flex items-center gap-1">
            <i class="bi bi-bar-chart-steps text-[10px]"></i> Nivel: {{ fNivel }}
          </span>
          <span *ngIf="fUnidad !== 'todos'" class="px-2.5 py-1 rounded-full bg-slate-50 border border-slate-200 flex items-center gap-1">
            <i class="bi bi-building text-[10px]"></i> Unidad: {{ fUnidad }}
          </span>
          <span *ngIf="fEstado !== 'todos'" class="px-2.5 py-1 rounded-full bg-slate-50 border border-slate-200 flex items-center gap-1">
            <i class="bi bi-funnel text-[10px]"></i>
            {{ fEstado === 'calificados' ? 'Solo calificados' : 'Solo sin calificar' }}
          </span>

          <button
            *ngIf="hasActiveFilters()"
            (click)="clearFilters()"
            class="text-[11px] text-slate-500 hover:text-slate-700 underline-offset-2 hover:underline ml-auto">
            Limpiar filtros
          </button>
        </div>
      </div>
    </div>

    <!-- TABLA / LISTADO -->
    <div class="relative bg-white rounded-2xl border border-slate-200 overflow-hidden">
      <!-- loading overlay -->
      <div *ngIf="loading()" class="absolute inset-0 z-20 bg-white/70 backdrop-blur-[1px] flex items-center justify-center">
        <div class="flex flex-col items-center gap-2 text-slate-500 text-sm">
          <span class="inline-block h-6 w-6 border-2 border-slate-300 border-t-indigo-500 rounded-full animate-spin"></span>
          <span>Cargando competidores...</span>
        </div>
      </div>

      <!-- Desktop table -->
      <div class="hidden md:block">
        <div class="overflow-auto max-h-[65vh]">
          <table class="min-w-full text-sm">
            <thead class="bg-slate-50 sticky top-0 z-10">
              <tr class="text-left text-slate-600">
                <th class="py-2.5 px-4 w-64">Competidor</th>
                <th class="py-2.5 px-4 w-28">CI</th>
                <th class="py-2.5 px-4 w-32">Área</th>
                <th class="py-2.5 px-4 w-28">Nivel</th>
                <th class="py-2.5 px-4 w-44">Unidad educativa</th>
                <th class="py-2.5 px-4 w-32">Nota ({{ notaMin }}–{{ notaMax }})</th>
                <th class="py-2.5 px-4 w-[360px]">Comentario (opcional, máx 250)</th>
                <th class="py-2.5 px-4 w-64">Acciones</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngIf="rows().length === 0">
                <td class="py-6 px-4 text-slate-400 text-center" colspan="8">
                  No hay resultados con los filtros actuales.
                </td>
              </tr>

              <tr *ngFor="let r of rows(); trackBy: trackById" class="border-t border-slate-100 hover:bg-slate-50/60">
                <!-- Competidor -->
                <td class="py-2.5 px-4 align-top">
                  <div class="flex flex-col gap-0.5">
                    <div class="font-medium text-slate-900">{{ r.nombre }}</div>
                    <div class="text-[11px] text-slate-500">Creado: {{ r.created_at | date:'short' }}</div>
                    <div class="flex flex-wrap gap-1 mt-1">
                      <span *ngIf="isDescalificado(r)"
                            class="inline-flex items-center gap-1 text-[11px] text-red-700 bg-red-50 rounded-full px-2 py-0.5 border border-red-200">
                        <span class="inline-flex h-1.5 w-1.5 rounded-full bg-red-500"></span>
                        Descalificado
                      </span>
                      <span *ngIf="r.calificacion"
                            class="inline-flex items-center gap-1 text-[11px] text-emerald-700 bg-emerald-50 rounded-full px-2 py-0.5 border border-emerald-200">
                        <i class="bi bi-check2-circle"></i>
                        Calificado
                      </span>
                    </div>
                  </div>
                </td>

                <td class="py-2.5 px-4 align-top">{{ r.ci }}</td>
                <td class="py-2.5 px-4 align-top">{{ r.area }}</td>
                <td class="py-2.5 px-4 align-top">{{ r.nivel }}</td>
                <td class="py-2.5 px-4 align-top">
                  <div class="text-xs text-slate-700">{{ r.unidad_educativa || '—' }}</div>
                  <div class="text-[11px] text-slate-500" *ngIf="r.profesor">
                    Prof.: {{ r.profesor }}
                  </div>
                </td>

                <!-- Nota -->
                <td class="py-2.5 px-4 align-top">
                  <input
                    type="number"
                    step="0.01"
                    [min]="notaMin"
                    [max]="notaMax"
                    class="w-28 rounded-lg border px-2 py-1 outline-none
                           focus:ring-2 focus:ring-indigo-100 focus:border-indigo-300
                           border-slate-300 bg-white"
                    [disabled]="isDescalificado(r)"
                    [ngModel]="getNota(r)"
                    (ngModelChange)="setNota(r.id, $event)">
                  <div class="text-[11px] text-red-600 mt-1" *ngIf="!isDescalificado(r) && invalidNota(r.id)">
                    La nota debe estar entre {{ notaMin }} y {{ notaMax }}.
                  </div>
                </td>

                <!-- Comentario -->
                <td class="py-2.5 px-4 align-top">
                  <textarea
                    rows="2"
                    maxlength="250"
                    class="w-full rounded-lg border px-2 py-1 text-xs outline-none
                           focus:ring-2 focus:ring-indigo-100 focus:border-indigo-300
                           border-slate-300 bg-white resize-none"
                    [disabled]="isDescalificado(r)"
                    [ngModel]="getComentario(r)"
                    (ngModelChange)="setComentario(r.id, $event)">
                  </textarea>
                  <div class="text-[11px] text-slate-500 text-right mt-0.5">
                    {{ comentarioLength(r) }}/250
                  </div>
                </td>

                <!-- Acciones -->
                <td class="py-2.5 px-4 align-top">
                  <div class="flex flex-wrap items-center gap-2">
                    <button
                      (click)="save(r)"
                      [disabled]="isDescalificado(r) || !dirty(r.id) || invalidNota(r.id) || saving(r.id)"
                      class="inline-flex items-center gap-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1.5 text-xs md:text-sm shadow-sm disabled:opacity-60">
                      <ng-container *ngIf="!saving(r.id); else savingTpl">
                        <i class="bi bi-save"></i> Guardar
                      </ng-container>
                    </button>

                    <button
                      (click)="openHistory(r)"
                      class="inline-flex items-center gap-1.5 rounded-xl bg-white border border-slate-200 px-3 py-1.5 text-xs md:text-sm hover:bg-slate-50">
                      <i class="bi bi-clock-history"></i> Historial
                    </button>

                    <a
                      [href]="historyPdfUrl(r)"
                      target="_blank"
                      class="inline-flex items-center gap-1.5 rounded-xl bg-white border border-slate-200 px-3 py-1.5 text-xs md:text-sm hover:bg-slate-50">
                      <i class="bi bi-file-earmark-pdf"></i> PDF
                    </a>

                    <button
                      type="button"
                      (click)="openDescalificar(r)"
                      [disabled]="!canDescalificar(r)"
                      class="inline-flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs md:text-sm border
                             disabled:opacity-60 disabled:cursor-not-allowed
                             border-red-200 text-red-700 bg-red-50 hover:bg-red-100">
                      <i class="bi bi-slash-circle"></i> Descalificar
                    </button>
                  </div>

                  <div *ngIf="!isDescalificado(r) && !canDescalificar(r)" class="mt-1 text-[11px] text-slate-400">
                    No puede descalificar este participante (edición archivada o fuera de su responsabilidad).
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Mobile cards -->
      <div class="md:hidden px-3 py-2 space-y-2 max-h-[70vh] overflow-auto">
        <div *ngIf="rows().length === 0" class="text-slate-400 text-sm py-4 text-center">
          No hay resultados con los filtros actuales.
        </div>

        <div *ngFor="let r of rows(); trackBy: trackById"
             class="rounded-2xl border border-slate-200 p-3 bg-white shadow-xs space-y-2">
          <div class="flex items-start justify-between gap-2">
            <div>
              <div class="font-semibold text-slate-900 text-sm">{{ r.nombre }}</div>
              <div class="text-[11px] text-slate-500">
                CI {{ r.ci }} · {{ r.area }} · {{ r.nivel }}
              </div>
              <div class="text-[11px] text-slate-500 mt-0.5">
                {{ r.unidad_educativa || 'Sin unidad' }}
                <span *ngIf="r.profesor"> · Prof. {{ r.profesor }}</span>
              </div>
            </div>
            <div class="flex flex-col items-end gap-1">
              <span *ngIf="isDescalificado(r)"
                    class="inline-flex items-center gap-1 text-[10px] text-red-700 bg-red-50 rounded-full px-2 py-0.5 border border-red-200">
                <span class="inline-flex h-1.5 w-1.5 rounded-full bg-red-500"></span>
                Descalificado
              </span>
              <span *ngIf="r.calificacion"
                    class="inline-flex items-center gap-1 text-[10px] text-emerald-700 bg-emerald-50 rounded-full px-2 py-0.5 border border-emerald-200">
                <i class="bi bi-check2-circle"></i>
                Calificado
              </span>
            </div>
          </div>

          <div class="grid grid-cols-[1fr_1.4fr] gap-2 text-xs items-start mt-1">
            <div>
              <label class="text-[11px] text-slate-500 mb-1 block">Nota ({{ notaMin }}–{{ notaMax }})</label>
              <input
                type="number"
                step="0.01"
                [min]="notaMin"
                [max]="notaMax"
                class="w-full rounded-lg border px-2 py-1 outline-none
                       focus:ring-2 focus:ring-indigo-100 focus:border-indigo-300
                       border-slate-300 bg-white"
                [disabled]="isDescalificado(r)"
                [ngModel]="getNota(r)"
                (ngModelChange)="setNota(r.id, $event)">
              <div class="text-[11px] text-red-600 mt-1" *ngIf="!isDescalificado(r) && invalidNota(r.id)">
                Nota fuera de rango.
              </div>
            </div>

            <div>
              <label class="text-[11px] text-slate-500 mb-1 block">Comentario (opcional)</label>
              <textarea
                rows="2"
                maxlength="250"
                class="w-full rounded-lg border px-2 py-1 outline-none
                       focus:ring-2 focus:ring-indigo-100 focus:border-indigo-300
                       border-slate-300 bg-white resize-none"
                [disabled]="isDescalificado(r)"
                [ngModel]="getComentario(r)"
                (ngModelChange)="setComentario(r.id, $event)">
              </textarea>
              <div class="text-[11px] text-slate-500 text-right mt-0.5">
                {{ comentarioLength(r) }}/250
              </div>
            </div>
          </div>

          <div class="flex flex-wrap items-center gap-2 pt-1 border-t border-slate-100 mt-1">
            <button
              (click)="save(r)"
              [disabled]="isDescalificado(r) || !dirty(r.id) || invalidNota(r.id) || saving(r.id)"
              class="flex-1 inline-flex items-center justify-center gap-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1.5 text-xs shadow-sm disabled:opacity-60">
              <ng-container *ngIf="!saving(r.id); else savingTpl">
                <i class="bi bi-save"></i> Guardar
              </ng-container>
            </button>

            <button
              (click)="openHistory(r)"
              class="inline-flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-white border border-slate-200 px-3 py-1.5 text-xs hover:bg-slate-50">
              <i class="bi bi-clock-history"></i> Historial
            </button>

            <button
              type="button"
              (click)="openDescalificar(r)"
              [disabled]="!canDescalificar(r)"
              class="inline-flex flex-1 items-center justify-center gap-1.5 rounded-xl px-3 py-1.5 text-xs border
                     disabled:opacity-60 disabled:cursor-not-allowed
                     border-red-200 text-red-700 bg-red-50 hover:bg-red-100">
              <i class="bi bi-slash-circle"></i> Descalificar
            </button>
          </div>
        </div>
      </div>

      <!-- Paginación -->
      <div class="border-t border-slate-200 p-3 flex flex-col md:flex-row md:items-center md:justify-between gap-2 bg-slate-50/60">
        <div class="text-xs md:text-sm text-slate-500">
          Página {{ meta().current_page }} de {{ meta().last_page }} — {{ meta().total }} registros
        </div>
        <div class="flex items-center gap-2 text-xs md:text-sm">
          <button
            (click)="goTo(meta().current_page - 1)"
            [disabled]="meta().current_page <= 1"
            class="rounded-lg border border-slate-200 px-3 py-1 hover:bg-white disabled:opacity-50">
            Anterior
          </button>
          <button
            (click)="goTo(meta().current_page + 1)"
            [disabled]="meta().current_page >= meta().last_page"
            class="rounded-lg border border-slate-200 px-3 py-1 hover:bg-white disabled:opacity-50">
            Siguiente
          </button>
        </div>
      </div>
    </div>

    <!-- MODAL HISTORIAL -->
    <div *ngIf="histOpen()" class="fixed inset-0 z-40 flex items-center justify-center">
      <div class="absolute inset-0 bg-black/40" (click)="closeHistory()"></div>
      <div class="relative bg-white rounded-2xl shadow-2xl w-full max-w-3xl max-h-[80vh] overflow-hidden border border-slate-200">
        <div class="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/70">
          <div class="flex items-center gap-2">
            <span class="inline-flex h-7 w-7 items-center justify-center rounded-xl bg-indigo-100 text-indigo-700">
              <i class="bi bi-clock-history text-sm"></i>
            </span>
            <div>
              <div class="font-semibold text-sm md:text-base">Historial de cambios</div>
              <div class="text-[11px] md:text-xs text-slate-500">{{ histTitle() }}</div>
            </div>
          </div>
          <button
            class="w-8 h-8 rounded-lg border border-slate-200 hover:bg-white bg-slate-50"
            (click)="closeHistory()">
            <i class="bi bi-x-lg text-slate-600 text-sm"></i>
          </button>
        </div>
        <div class="p-4 overflow-auto max-h-[65vh]">
          <table class="min-w-full text-xs md:text-sm">
            <thead class="bg-slate-50 sticky top-0">
              <tr class="text-left text-slate-600">
                <th class="py-2 px-3">#</th>
                <th class="py-2 px-3">Nota anterior</th>
                <th class="py-2 px-3">Nota nueva</th>
                <th class="py-2 px-3">Comentario anterior</th>
                <th class="py-2 px-3">Comentario nuevo</th>
                <th class="py-2 px-3">Fecha</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngIf="histRows().length === 0">
                <td class="py-4 px-3 text-slate-400 text-center" colspan="6">Sin cambios registrados.</td>
              </tr>
              <tr *ngFor="let h of histRows(); let i = index" class="border-t border-slate-100">
                <td class="py-2 px-3 align-top">{{ i + 1 }}</td>
                <td class="py-2 px-3 align-top">{{ h.nota_anterior ?? '—' }}</td>
                <td class="py-2 px-3 align-top">{{ h.nota_nueva ?? '—' }}</td>
                <td class="py-2 px-3 align-top">{{ h.comentario_anterior ?? '—' }}</td>
                <td class="py-2 px-3 align-top">{{ h.comentario_nuevo ?? '—' }}</td>
                <td class="py-2 px-3 align-top">{{ h.created_at | date:'short' }}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- MODAL DESCALIFICAR -->
    <div *ngIf="descalOpen()" class="fixed inset-0 z-40 flex items-center justify-center">
      <div class="absolute inset-0 bg-black/40" (click)="closeDescalificar()"></div>
      <div class="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden border border-red-200">
        <div class="p-4 border-b border-red-200 flex items-center justify-between bg-red-50/80">
          <div class="font-semibold text-red-700 flex items-center gap-2 text-sm md:text-base">
            <i class="bi bi-exclamation-triangle-fill"></i>
            Descalificar participante
          </div>
          <button
            class="w-8 h-8 rounded-lg border border-red-200 hover:bg-red-50 bg-white"
            (click)="closeDescalificar()"
            [disabled]="descalSaving()">
            <i class="bi bi-x-lg text-red-600 text-sm"></i>
          </button>
        </div>

        <div class="p-4 space-y-3 text-sm">
          <div class="text-slate-700">
            Estás a punto de descalificar a:
            <span class="font-semibold" *ngIf="descalTarget()">
              {{ descalTarget()?.nombre }} (CI {{ descalTarget()?.ci }})
            </span>
          </div>

          <div class="text-xs text-slate-600 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2">
            Esta acción modifica el <span class="font-semibold">Estado Final</span>.
            Un participante descalificado tiene prioridad máxima y se excluye de los procesos de clasificación por nota.
          </div>

          <div>
            <label class="block text-xs font-medium text-slate-700 mb-1">
              Motivo de la descalificación <span class="text-red-500">*</span>
            </label>
            <textarea
              rows="4"
              class="w-full rounded-lg border px-3 py-2 text-sm outline-none
                     focus:ring-2 focus:ring-red-100 focus:border-red-300 border-slate-300"
              [ngModel]="descalMotivo()"
              (ngModelChange)="descalMotivo.set($event)"
              [disabled]="descalSaving()"
              maxlength="500"
              placeholder="Describe brevemente la razón de la descalificación..."></textarea>
            <div class="flex justify-between items-center mt-1">
              <span class="text-xs text-slate-500">
                Mínimo 5 caracteres. Máximo 500.
              </span>
              <span class="text-xs text-slate-400">
                {{ descalMotivo().length }}/500
              </span>
            </div>
          </div>

          <div class="flex items-start gap-2 mt-1">
            <input
              id="chkConfirmDescal"
              type="checkbox"
              class="mt-0.5 rounded border-slate-300"
              [ngModel]="descalConfirm()"
              (ngModelChange)="descalConfirm.set($event)"
              [disabled]="descalSaving()">
            <label for="chkConfirmDescal" class="text-xs text-slate-700">
              Confirmo que deseo descalificar a este participante y entiendo el impacto en los resultados.
            </label>
          </div>

          <div *ngIf="descalError()" class="text-xs text-red-700 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
            {{ descalError() }}
          </div>
        </div>

        <div class="p-4 border-t border-slate-200 flex items-center justify-end gap-2 bg-slate-50/60">
          <button
            type="button"
            class="rounded-lg px-3 py-1.5 text-xs md:text-sm border border-slate-200 hover:bg-white"
            (click)="closeDescalificar()"
            [disabled]="descalSaving()">
            Cancelar
          </button>
          <button
            type="button"
            class="rounded-lg px-4 py-1.5 text-xs md:text-sm text-white bg-red-600 hover:bg-red-700 disabled:opacity-60 disabled:cursor-not-allowed"
            (click)="submitDescalificar()"
            [disabled]="descalSaving() || !canSubmitDescalificar()">
            <ng-container *ngIf="!descalSaving(); else descalSavingTpl">
              Confirmar descalificación
            </ng-container>
          </button>
        </div>
      </div>
    </div>

    <!-- templates -->
    <ng-template #savingTpl>
      <span class="inline-flex items-center gap-2">
        <span class="inline-block h-4 w-4 border-2 border-white/60 border-t-white rounded-full animate-spin"></span>
        Guardando...
      </span>
    </ng-template>

    <ng-template #descalSavingTpl>
      <span class="inline-flex items-center gap-2">
        <span class="inline-block h-4 w-4 border-2 border-white/60 border-t-white rounded-full animate-spin"></span>
        Procesando...
      </span>
    </ng-template>
  </section>
  `
})
export class RegistrarCalificacionesComponent {
  private api = inject(ApiService);

  readonly notaMin = 0;
  readonly notaMax = 100;

  q = '';
  page = 1;
  per = 25;

  areas: string[] = [];
  niveles: string[] = [];
  unidades: string[] = [];

  fArea: string = 'todos';
  fNivel: string = 'todos';
  fUnidad: string = 'todos';
  fEstado: 'todos' | 'calificados' | 'sin_calificar' = 'todos';

  rows = signal<Item[]>([]);
  meta = signal<PageMeta>({
    current_page: 1,
    per_page: 25,
    total: 0,
    last_page: 1,
  });

  editing = signal<Record<number, { nota: number | null; comentario: string }>>({});
  savingIds = signal<Set<number>>(new Set());
  loading = signal<boolean>(false);

  edicionArchivada = false;

  histOpen = signal(false);
  histTitle = signal('');
  histRows = signal<any[]>([]);

  descalOpen = signal(false);
  descalTarget = signal<Item | null>(null);
  descalMotivo = signal<string>('');
  descalConfirm = signal<boolean>(false);
  descalSaving = signal<boolean>(false);
  descalError = signal<string | null>(null);

  ngOnInit() {
    this.fetch();
  }

  trackById = (_: number, r: Item) => r.id;

  // --------- helpers de filtros / resumen ---------

  private refreshFilterOptions(data: Item[]) {
    const areaSet = new Set<string>();
    const nivelSet = new Set<string>();
    const unidadSet = new Set<string>();

    for (const r of data) {
      if (r.area) areaSet.add(r.area);
      if (r.nivel) nivelSet.add(r.nivel);
      if (r.unidad_educativa) unidadSet.add(r.unidad_educativa);
    }

    this.areas = Array.from(areaSet).sort();
    this.niveles = Array.from(nivelSet).sort();
    this.unidades = Array.from(unidadSet).sort();
  }

  hasActiveFilters(): boolean {
    return (
      this.fArea !== 'todos' ||
      this.fNivel !== 'todos' ||
      this.fUnidad !== 'todos' ||
      this.fEstado !== 'todos'
    );
  }

  clearFilters() {
    this.fArea = 'todos';
    this.fNivel = 'todos';
    this.fUnidad = 'todos';
    this.fEstado = 'todos';
    this.page = 1;
    this.fetch();
  }

  onFilterChange() {
    this.page = 1;
    this.fetch();
  }

  onSearchChange() {
    this.page = 1;
    this.fetch();
  }

  private buildQueryString(): string {
    const params = new URLSearchParams();
    if (this.q) params.set('q', this.q);
    params.set('page', String(this.page));
    params.set('per_page', String(this.per));

    if (this.fArea !== 'todos') params.set('area', this.fArea);
    if (this.fNivel !== 'todos') params.set('nivel', this.fNivel);
    if (this.fUnidad !== 'todos') params.set('unidad', this.fUnidad);
    if (this.fEstado !== 'todos') params.set('estado', this.fEstado);

    return params.toString();
  }

  // --------- resumen de estado ---------

  countCalificados(): number {
    return this.rows().filter(r => !!r.calificacion).length;
  }

  countSinCalificar(): number {
    return this.rows().filter(r => !r.calificacion).length;
  }

  // --------- UI helpers ---------

  isDescalificado(r: Item): boolean {
    if (!r.estado_final) return false;
    const val = r.estado_final.toString().toLowerCase();
    return val === 'des' || val === 'descalificado' || val === 'descal';
  }

  canDescalificar(r: Item): boolean {
    if (this.edicionArchivada) return false;
    if (this.isDescalificado(r)) return false;
    if (r.puede_descalificar === false) return false;
    return true;
  }

  getNota(r: Item): number | '' {
    const e = this.editing()[r.id];
    if (e && e.nota !== null && e.nota !== undefined) {
      return e.nota;
    }
    if (r.calificacion && r.calificacion.nota !== undefined && r.calificacion.nota !== null) {
      return r.calificacion.nota;
    }
    return '';
  }

  getComentario(r: Item): string {
    const e = this.editing()[r.id];
    if (e && typeof e.comentario === 'string') {
      return e.comentario;
    }
    if (r.calificacion && typeof r.calificacion.comentario === 'string') {
      return r.calificacion.comentario;
    }
    return '';
  }

  comentarioLength(r: Item): number {
    return this.getComentario(r).length;
  }

  dirty(id: number): boolean {
    const r = this.rows().find(x => x.id === id);
    const e = this.editing()[id];
    if (!r || !e) return false;

    const notaActual = r.calificacion ? r.calificacion.nota : null;
    const comentarioActual = r.calificacion?.comentario ?? '';

    const editedNota = e.nota !== null && e.nota !== undefined ? e.nota : null;
    const editedComentario = e.comentario || '';

    return (
      editedNota !== (notaActual ?? null) ||
      editedComentario !== (comentarioActual ?? '')
    );
  }

  invalidNota(id: number): boolean {
    const e = this.editing()[id];
    if (!e || e.nota === null || e.nota === undefined) return true;
    return !(e.nota >= this.notaMin && e.nota <= this.notaMax);
  }

  saving(id: number): boolean {
    return this.savingIds().has(id);
  }

  // --------- setters ---------

  setNota(id: number, val: any) {
    const num = val === '' ? null : Number(val);
    const current = { ...this.editing() };
    const baseRow = this.rows().find(x => x.id === id);

    const prev = current[id] || {
      nota: baseRow?.calificacion?.nota ?? null,
      comentario: baseRow?.calificacion?.comentario ?? '',
    };

    current[id] = {
      nota: typeof num !== 'number' || isNaN(num) ? null : num,
      comentario: prev.comentario,
    };

    this.editing.set(current);
  }

  setComentario(id: number, val: string) {
    const current = { ...this.editing() };
    const baseRow = this.rows().find(x => x.id === id);

    const prev = current[id] || {
      nota: baseRow?.calificacion?.nota ?? null,
      comentario: '',
    };

    current[id] = {
      nota: prev.nota,
      comentario: (val || '').slice(0, 250),
    };

    this.editing.set(current);
  }

  // --------- API ---------

  fetch() {
    const qs = this.buildQueryString();
    this.loading.set(true);

    this.api.get<PageRes>(`/evaluador/inscritos?${qs}`)
      .subscribe({
        next: res => {
          this.rows.set(res.data);
          this.meta.set(res.meta);
          this.edicionArchivada = !!res.meta.edicion_archivada;

          this.refreshFilterOptions(res.data);

          const map: Record<number, { nota: number | null; comentario: string }> = {};
          for (const r of res.data) {
            map[r.id] = {
              nota: r.calificacion ? r.calificacion.nota : null,
              comentario: r.calificacion?.comentario ?? '',
            };
          }
          this.editing.set(map);
          this.loading.set(false);
        },
        error: () => {
          this.rows.set([]);
          this.loading.set(false);
        }
      });
  }

  goTo(p: number) {
    if (p < 1 || p > this.meta().last_page) return;
    this.page = p;
    this.fetch();
  }

  save(r: Item) {
    const e = this.editing()[r.id];
    if (!e || e.nota === null || e.nota === undefined || e.nota < this.notaMin || e.nota > this.notaMax) {
      return;
    }

    const set = new Set(this.savingIds());
    set.add(r.id);
    this.savingIds.set(set);

    this.api.post<{ ok: boolean; data: any }>('/evaluador/calificaciones', {
      inscrito_id: r.id,
      nota: e.nota,
      comentario: (e.comentario || '').slice(0, 250) || null,
    }).subscribe({
      next: res => {
        if (res.ok) {
          const updated = this.rows().map(x =>
            x.id === r.id
              ? {
                  ...x,
                  calificacion: {
                    id: res.data.id,
                    nota: res.data.nota,
                    comentario: res.data.comentario,
                    updated_at: res.data.updated_at,
                  },
                }
              : x
          );
          this.rows.set(updated);
        }
        const s2 = new Set(this.savingIds());
        s2.delete(r.id);
        this.savingIds.set(s2);
      },
      error: () => {
        const s2 = new Set(this.savingIds());
        s2.delete(r.id);
        this.savingIds.set(s2);
      }
    });
  }

  // --------- historial ---------

  openHistory(r: Item) {
    this.histTitle.set(`${r.nombre} — CI ${r.ci}`);
    this.histRows.set([]);
    this.histOpen.set(true);
    this.api
      .get<{ data: any[] }>(`/evaluador/calificaciones/${r.id}/historial`)
      .subscribe({
        next: res => this.histRows.set(res.data || []),
        error: () => this.histRows.set([]),
      });
  }

  closeHistory() {
    this.histOpen.set(false);
  }

  historyPdfUrl(r: Item) {
    // Ajusta si tienes prefix /api en backend (por ejemplo, usando full URL)
    return `/api/evaluador/calificaciones/${r.id}/historial.pdf`;
  }

  // --------- descalificar ---------

  openDescalificar(r: Item) {
    if (!this.canDescalificar(r)) return;
    this.descalTarget.set(r);
    this.descalMotivo.set('');
    this.descalConfirm.set(false);
    this.descalError.set(null);
    this.descalSaving.set(false);
    this.descalOpen.set(true);
  }

  closeDescalificar() {
    if (this.descalSaving()) return;
    this.descalOpen.set(false);
    this.descalTarget.set(null);
    this.descalMotivo.set('');
    this.descalConfirm.set(false);
    this.descalError.set(null);
  }

  canSubmitDescalificar(): boolean {
    const motivoVal = (this.descalMotivo() || '').trim();
    if (motivoVal.length < 5) return false;
    if (!this.descalConfirm()) return false;
    if (!this.descalTarget()) return false;
    return true;
  }

  submitDescalificar() {
    if (!this.canSubmitDescalificar() || this.descalSaving()) return;

    const target = this.descalTarget();
    if (!target) return;

    const motivoVal = (this.descalMotivo() || '').trim();

    this.descalSaving.set(true);
    this.descalError.set(null);

    this.api
      .post<any>('/evaluador/descalificar', {
        inscrito_id: target.id,
        motivo: motivoVal,
      })
      .subscribe({
        next: res => {
          if (res?.ok) {
            const updatedRows = this.rows().map(r =>
              r.id === target.id
                ? { ...r, estado_final: res?.data?.estado_final ?? 'DES' }
                : r
            );
            this.rows.set(updatedRows);
            this.descalSaving.set(false);
            this.closeDescalificar();
          } else {
            this.descalSaving.set(false);
            this.descalError.set(res?.error || 'No se pudo registrar la descalificación.');
          }
        },
        error: err => {
          this.descalSaving.set(false);
          this.descalError.set(err?.error?.error || 'No se pudo registrar la descalificación. Intente nuevamente.');
        }
      });
  }
}
