import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

import { AuthService } from '../../core/auth.service';
import { ApiService } from '../../core/api.service';

@Component({
  standalone: true,
  selector: 'app-consulta',
  imports: [CommonModule],
  template: `
    <div class="p-6 w-full h-full flex flex-col items-start gap-4">

      <div>
        <h1 class="text-3xl font-bold mb-1 text-slate-800">
          Panel de Consulta
        </h1>
        <p class="text-slate-600">
          Acceso de solo lectura a reportes y estados.
        </p>
      </div>

      <div class="mt-6 bg-white shadow rounded-lg p-4 border border-slate-200">
        <div class="text-sm text-slate-700">Usuario:</div>
        <div class="font-semibold text-slate-900">{{ userName() }}</div>

        <button
          (click)="logout()"
          class="mt-4 text-sm px-4 py-2 rounded-lg bg-red-600 text-white
                 hover:bg-red-700 transition-colors"
        >
          <i class="bi bi-box-arrow-right me-1"></i> Cerrar sesión
        </button>
      </div>

    </div>
  `,
})
export default class ConsultaComponent {

  private auth = inject(AuthService);
  private api = inject(ApiService);
  private router = inject(Router);

  userName = signal(this.auth.user()?.nombre ?? 'Consulta');

  logout() {
    // Disparo corporativo al endpoint backend
    this.api.post('/logout', {}).subscribe({
      next: () => {
        this.auth.clear();
        this.router.navigateByUrl('/login');
      },
      error: () => {
        // fallback para garantizar separación de sesión
        this.auth.clear();
        this.router.navigateByUrl('/login');
      },
    });
  }
}
