import { Component, inject, signal, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink, RouterLinkActive, RouterOutlet, NavigationEnd } from '@angular/router';
import { AuthService } from '../../core/auth.service';
import { ApiService } from '../../core/api.service';
import { filter } from 'rxjs/operators';

@Component({
  standalone: true,
  selector: 'app-responsable-layout',
  imports: [CommonModule, RouterLink, RouterLinkActive, RouterOutlet],
  template: `
  <!-- Wrapper general: ocupa siempre la pantalla y bloquea overflow global -->
  <div class="h-screen min-h-screen flex bg-slate-100 text-slate-800 overflow-hidden">

    <!-- Overlay móvil -->
    <div
      *ngIf="sidebarOpen()"
      class="fixed inset-0 bg-black/50 z-30 md:hidden"
      (click)="toggleSidebar()">
    </div>

    <!-- Sidebar -->
    <aside
      class="fixed md:static top-0 left-0 z-40 h-screen w-72 md:w-64
             bg-gradient-to-b from-[#0b1f46] via-[#13366f] to-[#1a55a9]
             text-white transform transition-transform duration-300 ease-in-out
             md:translate-x-0 shadow-lg flex flex-col"
      [class.-translate-x-full]="!sidebarOpen() && isMobile()">

      <div class="flex-1 overflow-y-auto p-4">
        <div class="flex items-center gap-2 mb-6">
          <img src="/logo/logo.png" alt="Logo" class="h-8 w-auto" />
          <span class="font-bold tracking-wide text-lg">Oh! SanSi</span>
        </div>

        <nav class="space-y-1 text-sm">
          <a
            [routerLink]="['/responsable']"
            [routerLinkActiveOptions]="{ exact: true }"
            routerLinkActive="bg-white/20"
            class="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-white/10 transition">
            <i class="bi bi-house-door"></i><span>Inicio</span>
          </a>

          <a
            [routerLink]="['/responsable/listas']"
            routerLinkActive="bg-white/20"
            class="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-white/10 transition">
            <i class="bi bi-table"></i><span>Listas por área/nivel</span>
          </a>

          <a
            [routerLink]="['/responsable/desclasificados']"
            routerLinkActive="bg-white/20"
            class="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-white/10 transition">
            <i class="bi bi-x-octagon"></i><span>Desclasificados</span>
          </a>

          <a
            [routerLink]="['/responsable/no-clasificados']"
            routerLinkActive="bg-white/20"
            class="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-white/10 transition">
            <i class="bi bi-x-octagon"></i><span>No clasificados</span>
          </a>

          <a
            [routerLink]="['/responsable/responsables']"
            routerLinkActive="bg-white/20"
            class="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-white/10 transition">
            <i class="bi bi-people"></i><span>Responsables</span>
          </a>

          <a
            [routerLink]="['/responsable/guardadas']"
            routerLinkActive="bg-white/20"
            class="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-white/10 transition">
            <i class="bi bi-bookmark-check"></i><span>Listas guardadas</span>
          </a>
        </nav>
      </div>

      <div class="bg-white/10 rounded-xl p-3 m-4 mt-0">
        <div class="text-xs opacity-80 truncate">
          {{ userName() || 'Responsable de área' }}
        </div>
        <div class="text-[11px] opacity-70">Responsable</div>
        <button
          (click)="logout()"
          class="mt-3 w-full text-sm rounded-lg bg-white/20 hover:bg-white/25 py-1.5 transition">
          <i class="bi bi-box-arrow-right me-1"></i> Salir
        </button>
      </div>
    </aside>

    <!-- Contenido principal -->
    <main class="flex-1 flex flex-col h-screen min-h-0">
      <!-- Header -->
      <header class="sticky top-0 z-20 bg-white border-b border-slate-200/70 shadow-sm">
        <div class="flex items-center justify-between max-w-7xl mx-auto px-4 py-3">
          <div>
            <h1 class="text-lg font-bold">{{ pageTitle() }}</h1>
            <p class="text-sm text-slate-500 -mt-0.5">
              Gestión de competidores por área
            </p>
          </div>
          <button
            (click)="toggleSidebar()"
            class="md:hidden inline-flex items-center justify-center w-9 h-9 rounded-lg border border-slate-200 hover:bg-slate-50">
            <i class="bi bi-list text-lg"></i>
          </button>
        </div>
      </header>

      <!-- Área de contenido con scroll propio -->
      <section
        class="flex-1 w-full max-w-7xl mx-auto p-4 overflow-y-auto overflow-x-hidden min-h-0">
        <router-outlet></router-outlet>
      </section>
    </main>
  </div>
  `
})
export class ResponsableLayoutComponent {
  private auth = inject(AuthService);
  private api = inject(ApiService);
  private router = inject(Router);

  sidebarOpen = signal(false);
  userName = signal(this.auth.user()?.nombre ?? null);
  pageTitle = signal('Panel del responsable');

  constructor() {
    // Watch de sesión
    effect(() => {
      if (!this.auth.isLoggedIn()) {
        this.router.navigateByUrl('/login');
      }
    });

    // Título dinámico por data.title
    this.router.events
      .pipe(filter(e => e instanceof NavigationEnd))
      .subscribe(() => {
        let route = this.router.routerState.snapshot.root;
        while (route.firstChild) route = route.firstChild;
        this.pageTitle.set(route.data?.['title'] || 'Panel del responsable');
      });
  }

  isMobile() {
    return window.innerWidth < 768;
  }

  toggleSidebar() {
    this.sidebarOpen.set(!this.sidebarOpen());
  }

  logout() {
    this.api.post('/logout', {}).subscribe({
      next: () => {
        this.auth.clear();
        this.router.navigateByUrl('/login');
      },
      error: () => {
        this.auth.clear();
        this.router.navigateByUrl('/login');
      }
    });
  }
}
