import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';

type Area = { id: number; nombre: string };

type Row = {
  id: number;
  nombre: string;
  email: string;
  nivel: string | null;
  activo: boolean;
  areas: Area[];
  areas_csv?: string | null;
};

type Meta = {
  page: number;
  per_page: number;
  total: number;
  total_pages: number;
};

@Component({
  standalone: true,
  selector: 'app-responsables-listado',
  imports: [CommonModule, FormsModule],
  template: `
  <section class="space-y-4">
    <!-- Header -->
    <div class="bg-white rounded-2xl border border-slate-200 p-4">
      <div class="flex items-center justify-between">
        <div>
          <div class="text-lg font-bold">Responsables de área</div>
          <div class="text-sm text-slate-500 -mt-0.5">Consulta y filtros por área y nivel</div>
        </div>
      </div>
    </div>

    <!-- Filtros -->
    <div class="bg-white rounded-2xl border border-slate-200 p-4">
      <div class="grid gap-3 md:grid-cols-5">
        <div class="md:col-span-2">
          <label class="text-xs text-slate-500">Buscar</label>
          <input
            [(ngModel)]="q"
            (input)="debouncedSearch()"
            placeholder="Nombre o email"
            class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none
                   focus:ring-2 focus:ring-blue-200 focus:border-blue-300">
        </div>

        <div>
          <label class="text-xs text-slate-500">Área (ID)</label>
          <input
            [(ngModel)]="areaId"
            type="number"
            min="0"
            (input)="search()"
            class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
          <div class="text-[11px] text-slate-400 mt-1">Deja 0 para todas</div>
        </div>

        <div>
          <label class="text-xs text-slate-500">Nivel</label>
          <input
            [(ngModel)]="nivel"
            (input)="search()"
            placeholder="Ej: Inicial, Intermedio..."
            class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
        </div>

        <div class="flex items-end gap-2">
          <div class="flex-1">
            <label class="text-xs text-slate-500">Orden</label>
            <select
              [(ngModel)]="order"
              (change)="search()"
              class="w-full rounded-lg border border-slate-300 px-2 py-2 text-sm">
              <option value="nombre">Nombre</option>
              <option value="area">Área</option>
              <option value="nivel">Nivel</option>
            </select>
          </div>
          <div>
            <label class="text-xs text-slate-500 invisible">.</label>
            <select
              [(ngModel)]="dir"
              (change)="search()"
              class="w-full rounded-lg border border-slate-300 px-2 py-2 text-sm">
              <option value="asc">Asc</option>
              <option value="desc">Desc</option>
            </select>
          </div>
        </div>
      </div>

      <div class="mt-3 flex items-center gap-2">
        <button
          (click)="clear()"
          class="rounded-lg bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50">
          Limpiar
        </button>
        <div class="ml-auto text-xs text-slate-500">
          Filtros activos:
          <span
            class="inline-flex items-center gap-1 bg-slate-100 rounded-full px-2 py-0.5 mr-1"
            *ngIf="areaId && areaId > 0">
            Área ID: {{ areaId }}
            <button
              class="ml-1 text-slate-500 hover:text-slate-700"
              (click)="areaId = 0; search()">
              &times;
            </button>
          </span>
          <span
            class="inline-flex items-center gap-1 bg-slate-100 rounded-full px-2 py-0.5"
            *ngIf="nivel">
            Nivel: {{ nivel }}
            <button
              class="ml-1 text-slate-500 hover:text-slate-700"
              (click)="nivel = ''; search()">
              &times;
            </button>
          </span>
        </div>
      </div>
    </div>

    <!-- Tabla -->
    <div class="bg-white rounded-2xl border border-slate-200 overflow-auto">
      <table class="min-w-full text-sm">
        <thead class="bg-slate-50 sticky top-0">
          <tr class="text-left text-slate-600">
            <th class="py-2 px-3">Nombre</th>
            <th class="py-2 px-3">Email</th>
            <th class="py-2 px-3">Áreas</th>
            <th class="py-2 px-3">Nivel</th>
            <th class="py-2 px-3">Estado</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngIf="rows().length === 0">
            <td colspan="5" class="text-center text-slate-400 py-4">Sin resultados</td>
          </tr>

          <tr *ngFor="let r of rows()" class="border-t border-slate-100">
            <td class="py-2 px-3">{{ r.nombre }}</td>
            <td class="py-2 px-3">{{ r.email }}</td>
            <td class="py-2 px-3">
              <div class="flex flex-wrap gap-1">
                <span
                  *ngFor="let a of r.areas"
                  class="inline-flex items-center rounded-full bg-blue-50 text-blue-700
                         px-2 py-0.5 text-[11px] border border-blue-200">
                  {{ a.nombre }}
                </span>

                <span
                  *ngIf="!r.areas?.length && r.areas_csv"
                  class="text-slate-400">
                  {{ r.areas_csv }}
                </span>

                <span
                  *ngIf="!r.areas?.length && !r.areas_csv"
                  class="text-slate-400">
                  —
                </span>
              </div>
            </td>
            <td class="py-2 px-3">{{ r.nivel ?? '—' }}</td>
            <td class="py-2 px-3">
              <span
                class="text-xs rounded-full px-2 py-1"
                [class.bg-emerald-100]="r.activo"
                [class.text-emerald-700]="r.activo"
                [class.bg-red-100]="!r.activo"
                [class.text-red-700]="!r.activo">
                {{ r.activo ? 'Activo' : 'Inactivo' }}
              </span>
            </td>
          </tr>
        </tbody>
      </table>

      <!-- Paginación -->
      <div class="flex items-center justify-between p-3 text-sm">
        <div class="text-slate-500">
          Página {{ meta().page }} de {{ meta().total_pages }} • {{ meta().total }} registros
        </div>
        <div class="flex items-center gap-2">
          <button
            (click)="goTo(meta().page - 1)"
            [disabled]="meta().page <= 1"
            class="rounded-lg bg-white border border-slate-200 px-3 py-1.5
                   disabled:opacity-50 hover:bg-slate-50">
            <i class="bi bi-chevron-left"></i>
          </button>
          <button
            (click)="goTo(meta().page + 1)"
            [disabled]="meta().page >= meta().total_pages"
            class="rounded-lg bg-white border border-slate-200 px-3 py-1.5
                   disabled:opacity-50 hover:bg-slate-50">
            <i class="bi bi-chevron-right"></i>
          </button>
          <select
            [(ngModel)]="perPage"
            (change)="search()"
            class="rounded-lg border border-slate-300 px-2 py-1">
            <option [value]="15">15</option>
            <option [value]="30">30</option>
            <option [value]="50">50</option>
          </select>
        </div>
      </div>
    </div>
  </section>
  `
})
export class ResponsablesListadoComponent {
  private api = inject(ApiService);

  q = '';
  areaId: number = 0;
  nivel = '';
  order: 'nombre' | 'area' | 'nivel' = 'nombre';
  dir: 'asc' | 'desc' = 'asc';

  page = 1;
  perPage = 15;

  rows = signal<Row[]>([]);
  meta = signal<Meta>({ page: 1, per_page: 15, total: 0, total_pages: 0 });

  private debounceTimer: any = null;

  ngOnInit() {
    this.search();
  }

  params(): Record<string, string> {
    const p: Record<string, string> = {
      page: String(this.page),
      per_page: String(this.perPage),
      order: this.order,
      dir: this.dir,
    };

    if (this.q) p['q'] = this.q;
    if (this.areaId && this.areaId > 0) p['area_id'] = String(this.areaId);
    if (this.nivel) p['nivel'] = this.nivel;

    return p;
  }

  search() {
    const qs = new URLSearchParams(this.params()).toString();

    this.api
      .get<{ ok: boolean; data: Row[]; meta: Meta }>(`/responsable/responsables?${qs}`)
      .subscribe({
        next: (res) => {
          if (res?.ok) {
            this.rows.set(res.data || []);
            this.meta.set(
              res.meta || { page: 1, per_page: this.perPage, total: 0, total_pages: 0 }
            );
          } else {
            this.rows.set([]);
            this.meta.set({ page: 1, per_page: this.perPage, total: 0, total_pages: 0 });
          }
        },
        error: (err) => {
          console.error('Error cargando responsables:', err);
          this.rows.set([]);
          this.meta.set({ page: 1, per_page: this.perPage, total: 0, total_pages: 0 });
        },
      });
  }

  debouncedSearch() {
    clearTimeout(this.debounceTimer);
    this.debounceTimer = setTimeout(() => this.search(), 300);
  }

  clear() {
    this.q = '';
    this.areaId = 0;
    this.nivel = '';
    this.order = 'nombre';
    this.dir = 'asc';
    this.page = 1;
    this.search();
  }

  goTo(p: number) {
    if (p < 1 || p > this.meta().total_pages) return;
    this.page = p;
    this.search();
  }
}
