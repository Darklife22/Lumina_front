import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  standalone: true,
  selector: 'app-responsable-dashboard',
  imports: [CommonModule],
  template: `
  <div class="space-y-4">
    <!-- Resumen (dummy por ahora) -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      <div class="bg-white rounded-2xl border border-slate-200 p-4">
        <div class="text-slate-500 text-sm flex items-center gap-2">
          <i class="bi bi-people"></i> Competidores totales
        </div>
        <div class="text-3xl font-bold mt-1">—</div>
      </div>
      <div class="bg-white rounded-2xl border border-slate-200 p-4">
        <div class="text-slate-500 text-sm flex items-center gap-2">
          <i class="bi bi-check2-circle"></i> Calificados
        </div>
        <div class="text-3xl font-bold mt-1 text-emerald-600">—</div>
      </div>
      <div class="bg-white rounded-2xl border border-slate-200 p-4">
        <div class="text-slate-500 text-sm flex items-center gap-2">
          <i class="bi bi-hourglass-split"></i> Pendientes
        </div>
        <div class="text-3xl font-bold mt-1 text-amber-600">—</div>
      </div>
      <div class="bg-white rounded-2xl border border-slate-200 p-4">
        <div class="text-slate-500 text-sm flex items-center gap-2">
          <i class="bi bi-save"></i> Listas guardadas
        </div>
        <div class="text-3xl font-bold mt-1 text-blue-600">—</div>
      </div>
    </div>

    <div class="bg-white rounded-2xl border border-slate-200 p-4">
      <h2 class="text-base font-semibold mb-2">Accesos rápidos</h2>
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        <a routerLink="/responsable/listas"
           class="rounded-xl border border-slate-200 p-4 hover:bg-slate-50 transition flex items-center gap-3">
          <i class="bi bi-funnel"></i>
          <div>
            <div class="font-medium">Filtrar competidores</div>
            <div class="text-xs text-slate-500">Por área, nivel, estado y nombre</div>
          </div>
        </a>
        <a routerLink="/responsable/guardadas"
           class="rounded-xl border border-slate-200 p-4 hover:bg-slate-50 transition flex items-center gap-3">
          <i class="bi bi-bookmark-check"></i>
          <div>
            <div class="font-medium">Listas guardadas</div>
            <div class="text-xs text-slate-500">Ver/descargar CSV o PDF</div>
          </div>
        </a>
      </div>
    </div>
  </div>
  `
})
export class ResponsableDashboardComponent {}
