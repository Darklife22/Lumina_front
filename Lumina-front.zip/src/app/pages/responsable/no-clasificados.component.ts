import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';

type Row = {
  id: number;
  nombre: string;
  ci: string;
  area?: string;
  area_id?: number;
  nivel: string;
  nota?: number | null;
  motivo_no_clasificacion?: string | null;
  created_at?: string;
};

type Meta = {
  page: number;
  per_page: number;
  total: number;
  total_pages: number;
};

@Component({
  standalone: true,
  selector: 'app-no-clasificados',
  imports: [CommonModule, FormsModule],
  template: `
  <section class="space-y-4">
    <!-- Header -->
    <div class="bg-white rounded-2xl border border-slate-200 p-4 flex items-center justify-between">
      <div>
        <div class="text-lg font-bold">Informe oficial de no clasificados</div>
        <div class="text-sm text-slate-500 -mt-0.5">
          Listado con nombre, nivel, nota y motivo de no clasificación
        </div>
      </div>
      <div class="flex items-center gap-2">
        <button
          class="rounded-lg bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50"
          (click)="export('pdf')">
          <i class="bi bi-file-pdf"></i> Exportar PDF
        </button>
        <button
          class="rounded-lg bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50"
          (click)="export('csv')">
          <i class="bi bi-filetype-csv"></i> Exportar CSV
        </button>
      </div>
    </div>

    <!-- Filtros -->
    <div class="bg-white rounded-2xl border border-slate-200 p-4">
      <div class="grid gap-3 md:grid-cols-4">
        <div class="md:col-span-2">
          <label class="text-xs text-slate-500">Buscar</label>
          <input
            [(ngModel)]="q"
            (keyup.enter)="search()"
            placeholder="Nombre, CI, área o nivel"
            class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-200 focus:border-blue-300">
        </div>
        <div>
          <label class="text-xs text-slate-500">Área (ID)</label>
          <input
            [(ngModel)]="areaId"
            type="number"
            min="0"
            class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
        </div>
        <div>
          <label class="text-xs text-slate-500">Nivel</label>
          <input
            [(ngModel)]="nivel"
            placeholder="Ej: Inicial, Intermedio..."
            class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
        </div>
      </div>

      <div class="mt-3 flex items-center gap-2">
        <button
          (click)="search()"
          class="rounded-lg bg-[#0f3f94] hover:bg-[#0d3580] text-white px-3 py-2 text-sm">
          <i class="bi bi-search"></i> Filtrar
        </button>
        <button
          (click)="clear()"
          class="rounded-lg bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50">
          Limpiar
        </button>

        <div class="ml-auto flex items-center gap-2">
          <label class="text-xs text-slate-500">Orden</label>
          <select
            [(ngModel)]="order"
            class="rounded-lg border border-slate-300 px-2 py-1 text-sm">
            <option value="nombre">Nombre</option>
            <option value="ci">CI</option>
            <option value="area">Área</option>
            <option value="nivel">Nivel</option>
            <option value="nota">Nota</option>
            <option value="fecha">Fecha</option>
          </select>
          <select
            [(ngModel)]="dir"
            class="rounded-lg border border-slate-300 px-2 py-1 text-sm">
            <option value="asc">Asc</option>
            <option value="desc">Desc</option>
          </select>
        </div>
      </div>
    </div>

    <!-- Tabla -->
    <div class="bg-white rounded-2xl border border-slate-200 p-0">
      <div class="flex items-center justify-between p-3">
        <div class="font-semibold">
          Listado ({{ meta().total }} reg.)
        </div>
      </div>

      <div class="overflow-auto">
        <table class="min-w-full text-sm">
          <thead class="bg-slate-50 sticky top-0">
            <tr class="text-left text-slate-600">
              <th class="py-2 px-3">Nombre</th>
              <th class="py-2 px-3">CI</th>
              <th class="py-2 px-3">Área</th>
              <th class="py-2 px-3">Nivel</th>
              <th class="py-2 px-3">Nota</th>
              <th class="py-2 px-3">Motivo</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngIf="rows().length === 0">
              <td colspan="6" class="text-center text-slate-400 py-4">
                Sin resultados
              </td>
            </tr>
            <tr *ngFor="let r of rows()" class="border-t border-slate-100">
              <td class="py-2 px-3">{{ r.nombre }}</td>
              <td class="py-2 px-3">{{ r.ci }}</td>
              <td class="py-2 px-3">{{ r.area ?? r.area_id ?? '-' }}</td>
              <td class="py-2 px-3">{{ r.nivel }}</td>
              <td class="py-2 px-3">{{ r.nota ?? '-' }}</td>
              <td class="py-2 px-3">{{ r.motivo_no_clasificacion ?? '-' }}</td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Paginación -->
      <div class="flex items-center justify-between p-3 text-sm">
        <div class="text-slate-500">
          Página {{ meta().page }} de {{ meta().total_pages }} • {{ meta().total }} registros
        </div>
        <div class="flex items-center gap-2">
          <button
            (click)="goTo(meta().page - 1)"
            [disabled]="meta().page <= 1"
            class="rounded-lg bg-white border border-slate-200 px-3 py-1.5 disabled:opacity-50 hover:bg-slate-50">
            <i class="bi bi-chevron-left"></i>
          </button>
          <button
            (click)="goTo(meta().page + 1)"
            [disabled]="meta().page >= meta().total_pages"
            class="rounded-lg bg-white border border-slate-200 px-3 py-1.5 disabled:opacity-50 hover:bg-slate-50">
            <i class="bi bi-chevron-right"></i>
          </button>
        </div>
      </div>
    </div>
  </section>
  `
})
export class NoClasificadosComponent {
  private api = inject(ApiService);

  q = '';
  areaId: number | null = null;
  nivel = '';
  order: 'nombre' | 'ci' | 'area' | 'nivel' | 'nota' | 'fecha' = 'nombre';
  dir: 'asc' | 'desc' = 'asc';

  rows = signal<Row[]>([]);
  meta = signal<Meta>({ page: 1, per_page: 15, total: 0, total_pages: 0 });

  ngOnInit() {
    this.search();
  }

  params(): Record<string, string> {
    const m = this.meta();
    const p: Record<string, string> = {
      page: String(m.page),
      per_page: String(m.per_page),
      order: this.order,
      dir: this.dir,
    };

    if (this.q) p['q'] = this.q;
    if (this.areaId && this.areaId > 0) p['area_id'] = String(this.areaId);
    if (this.nivel) p['nivel'] = this.nivel;

    return p;
  }

  search() {
    this.api
      .get<{ ok: boolean; data: Row[]; meta: Meta; message?: string }>(
        '/responsable/no-clasificados',
        this.params()
      )
      .subscribe({
        next: (res) => {
          if (res?.ok) {
            this.rows.set(res.data || []);
            this.meta.set(res.meta);
          } else {
            this.rows.set([]);
            this.meta.set({ page: 1, per_page: 15, total: 0, total_pages: 0 });
          }
        },
        error: () => {
          this.rows.set([]);
          this.meta.set({ page: 1, per_page: 15, total: 0, total_pages: 0 });
        },
      });
  }

  clear() {
    this.q = '';
    this.areaId = null;
    this.nivel = '';
    this.meta.set({ page: 1, per_page: 15, total: 0, total_pages: 0 });
    this.search();
  }

  goTo(p: number) {
    const m = this.meta();
    if (p < 1 || p > m.total_pages) return;
    this.meta.set({ ...m, page: p });
    this.search();
  }

  export(format: 'pdf' | 'csv') {
    const params: Record<string, any> = {
      ...this.params(),
      format,
    };

    this.api
      .download('/responsable/no-clasificados/export', params)
      .subscribe({
        next: (blob: Blob) => {
          const mime =
            format === 'pdf'
              ? 'application/pdf'
              : 'text/csv;charset=utf-8';

          const fileName =
            format === 'pdf'
              ? 'no-clasificados.pdf'
              : 'no-clasificados.csv';

          const fileBlob = new Blob([blob], { type: mime });
          const url = URL.createObjectURL(fileBlob);

          const a = document.createElement('a');
          a.href = url;
          a.download = fileName;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);

          URL.revokeObjectURL(url);
        },
        error: (err) => {
          console.error('Error exportando no clasificados', err);
          alert('No se pudo generar el informe. Verifica tu sesión o vuelve a intentarlo.');
        },
      });
  }
}
