import { Component } from '@angular/core';

@Component({
  standalone: true,
  selector: 'app-responsable',
  template: `
    <div class="p-4">
      <h1>Panel Responsable de Área</h1>
      <p>Gestión de área/niveles, cierres y parametrizaciones.</p>
    </div>
  `
})
export default class ResponsableComponent {}
