import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';

type Row = {
  id: number;
  nombre: string;
  nivel: string;
  nota: number | null;
  motivo: string | null;
  fecha_descalificacion: string | null;
  ci?: string;
  area?: string;
  area_id?: number;
};

type Meta = {
  page: number;
  per_page: number;
  total: number;
  total_pages: number;
};

@Component({
  standalone: true,
  selector: 'app-resp-desclasificados',
  imports: [CommonModule, FormsModule],
  template: `
  <section class="space-y-4">

    <!-- Header -->
    <div class="bg-white rounded-2xl border border-slate-200 p-4 flex items-center justify-between">
      <div>
        <div class="text-lg font-bold">Informe oficial de desclasificados</div>
        <div class="text-sm text-slate-500 -mt-0.5">
          Listado oficial para auditoría del área responsable
        </div>
      </div>

      <div class="flex items-center gap-2">
        <button (click)="export('pdf')"
                class="rounded-lg bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50">
          <i class="bi bi-file-pdf"></i> Exportar PDF
        </button>
        <button (click)="export('csv')"
                class="rounded-lg bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50">
          <i class="bi bi-filetype-csv"></i> Exportar CSV
        </button>
      </div>
    </div>

    <!-- Filtros -->
    <div class="bg-white rounded-2xl border border-slate-200 p-4">
      <div class="grid gap-3 md:grid-cols-5">

        <div class="md:col-span-2">
          <label class="text-xs text-slate-500">Buscar</label>
          <input [(ngModel)]="q" (keyup.enter)="search()" placeholder="Nombre, CI, Nivel, Área"
                 class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:ring-2 focus:ring-blue-200">
        </div>

        <div>
          <label class="text-xs text-slate-500">Nivel</label>
          <input [(ngModel)]="nivel" (keyup.enter)="search()" placeholder="Ej: Inicial, Medio, Avanzado"
                 class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
        </div>

        <div>
          <label class="text-xs text-slate-500">Desde</label>
          <input [(ngModel)]="from" type="date"
                 class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
        </div>

        <div>
          <label class="text-xs text-slate-500">Hasta</label>
          <input [(ngModel)]="to" type="date"
                 class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
        </div>

      </div>

      <div class="mt-3 flex items-end gap-2">
        <div>
          <label class="text-xs text-slate-500">Orden</label>
          <select [(ngModel)]="order" class="rounded-lg border border-slate-300 px-3 py-2 text-sm">
            <option value="nombre">Nombre</option>
            <option value="nivel">Nivel</option>
            <option value="nota">Nota</option>
            <option value="fecha">Fecha</option>
          </select>
        </div>

        <div>
          <label class="text-xs text-slate-500">Dirección</label>
          <select [(ngModel)]="dir" class="rounded-lg border border-slate-300 px-3 py-2 text-sm">
            <option value="asc">Asc</option>
            <option value="desc">Desc</option>
          </select>
        </div>

        <button (click)="search()"
                class="rounded-lg bg-[#0f3f94] hover:bg-[#0d3580] text-white px-3 py-2 text-sm">
          <i class="bi bi-search"></i> Filtrar
        </button>

        <button (click)="clear()"
                class="rounded-lg bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50">
          Limpiar
        </button>
      </div>
    </div>

    <!-- Tabla -->
    <div class="bg-white rounded-2xl border border-slate-200 p-0">
      <div class="flex items-center justify-between p-3">
        <div class="font-semibold">Listado ({{ meta().total }} reg.)</div>
      </div>

      <div class="overflow-auto">
        <table class="min-w-full text-sm">
          <thead class="bg-slate-50 sticky top-0">
            <tr class="text-left text-slate-600">
              <th class="py-2 px-3">Nombre</th>
              <th class="py-2 px-3">Nivel</th>
              <th class="py-2 px-3">Nota</th>
              <th class="py-2 px-3">Descripción</th>
              <th class="py-2 px-3">Fecha</th>
              <th class="py-2 px-3">CI</th>
              <th class="py-2 px-3">Área</th>
            </tr>
          </thead>
          <tbody>

            <tr *ngIf="rows().length === 0">
              <td colspan="7" class="text-center text-slate-400 py-4">No hay registros</td>
            </tr>

            <tr *ngFor="let r of rows()" class="border-t border-slate-100">
              <td class="py-2 px-3">{{ r.nombre }}</td>
              <td class="py-2 px-3">{{ r.nivel }}</td>
              <td class="py-2 px-3">{{ r.nota ?? '—' }}</td>
              <td class="py-2 px-3">{{ r.motivo || '—' }}</td>
              <td class="py-2 px-3">{{ r.fecha_descalificacion | date:'yyyy-MM-dd HH:mm' }}</td>
              <td class="py-2 px-3">{{ r.ci || '—' }}</td>
              <td class="py-2 px-3">{{ r.area ?? r.area_id ?? '—' }}</td>
            </tr>

          </tbody>
        </table>
      </div>

      <!-- Paginación -->
      <div class="flex items-center justify-between p-3 text-sm">
        <div class="text-slate-500">
          Página {{ meta().page }} de {{ meta().total_pages }} • {{ meta().total }} registros
        </div>

        <div class="flex items-center gap-2">
          <button (click)="goTo(meta().page - 1)" [disabled]="meta().page <= 1"
                  class="rounded-lg bg-white border border-slate-200 px-3 py-1.5 disabled:opacity-50 hover:bg-slate-50">
            <i class="bi bi-chevron-left"></i>
          </button>

          <button (click)="goTo(meta().page + 1)" [disabled]="meta().page >= meta().total_pages"
                  class="rounded-lg bg-white border border-slate-200 px-3 py-1.5 disabled:opacity-50 hover:bg-slate-50">
            <i class="bi bi-chevron-right"></i>
          </button>
        </div>
      </div>

    </div>
  </section>
  `
})
export class DesclasificadosComponent {
  private api = inject(ApiService);

  // filtros
  q = '';
  nivel = '';
  from = '';
  to = '';
  order: 'nombre' | 'nivel' | 'nota' | 'fecha' = 'nombre';
  dir: 'asc' | 'desc' = 'asc';

  // estado
  rows = signal<Row[]>([]);
  meta = signal<Meta>({ page: 1, per_page: 15, total: 0, total_pages: 0 });

  ngOnInit() {
    this.search();
  }

  params(): Record<string, string> {
    const m = this.meta();
    const p: Record<string, string> = {
      page: String(m.page),
      per_page: String(m.per_page),
      order: this.order,
      dir: this.dir,
    };

    if (this.q)     p['q'] = this.q;
    if (this.nivel) p['nivel'] = this.nivel;
    if (this.from)  p['from'] = this.from;
    if (this.to)    p['to'] = this.to;

    return p;
  }

  search() {
    this.api
      .get<{ ok: boolean; data: Row[]; meta: Meta }>('/responsable/desclasificados', this.params())
      .subscribe({
        next: res => {
          this.rows.set(res.data || []);
          this.meta.set(res.meta);
        },
        error: () => {
          this.rows.set([]);
          this.meta.set({ page: 1, per_page: 15, total: 0, total_pages: 0 });
        },
      });
  }

  clear() {
    this.q = '';
    this.nivel = '';
    this.from = '';
    this.to = '';
    this.meta.set({ ...this.meta(), page: 1 });
    this.search();
  }

  goTo(p: number) {
    if (p < 1 || p > this.meta().total_pages) return;
    this.meta.set({ ...this.meta(), page: p });
    this.search();
  }

  export(format: 'pdf' | 'csv') {
  const params: Record<string, any> = {
    ...this.params(),
    format,
  };

  this.api
    .download('/responsable/desclasificados/export', params)
    .subscribe({
      next: (blob: Blob) => {
        // Tipo MIME y nombre sugerido
        const mime =
          format === 'pdf'
            ? 'application/pdf'        // aunque el backend manda HTML, esto fuerza trato de "archivo pdf"
            : 'text/csv;charset=utf-8';

        const fileName =
          format === 'pdf'
            ? 'desclasificados.pdf'
            : 'desclasificados.csv';

        const fileBlob = new Blob([blob], { type: mime });
        const url = URL.createObjectURL(fileBlob);

        // 🔽 Forzar descarga (igual para PDF y CSV)
        const a = document.createElement('a');
        a.href = url;
        a.download = fileName;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);

        URL.revokeObjectURL(url);
      },
      error: err => {
        console.error('Error exportando', err);
        alert(
          'No se pudo generar el informe. Verifica tu sesión o vuelve a intentarlo.'
        );
      },
    });
}

}
