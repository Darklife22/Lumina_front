// src/app/pages/responsable/competidores.component.ts
import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';

type Row = {
  id: number;
  nombre: string;
  ci: string;
  area: string;
  nivel: string;
  estado?: string;
  created_at?: string;
};

type Meta = {
  page: number;
  per_page: number;
  total: number;
  total_pages: number;
};

type Area = { id: number; nombre: string };

@Component({
  standalone: true,
  selector: 'app-competidores',
  imports: [CommonModule, FormsModule],
  template: `
  <section class="space-y-4 max-w-6xl mx-auto">
    <!-- Header -->
    <div class="bg-white rounded-2xl border border-slate-200 p-4 flex items-center justify-between">
      <div>
        <div class="text-lg font-bold">Competidores por área y nivel</div>
        <div class="text-sm text-slate-500 -mt-0.5">
          Filtra por nombre, área, nivel y estado
        </div>
      </div>
      <div class="flex items-center gap-2">
        <button
          (click)="export('pdf')"
          class="rounded-lg bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50">
          <i class="bi bi-file-pdf"></i> Exportar PDF
        </button>
        <button
          (click)="export('csv')"
          class="rounded-lg bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50">
          <i class="bi bi-filetype-csv"></i> Exportar CSV
        </button>
        <button
          (click)="openSave()"
          class="rounded-lg bg-[#0f3f94] hover:bg-[#0d3580] text-white px-3 py-2 text-sm">
          <i class="bi bi-save"></i> Guardar lista
        </button>
      </div>
    </div>

    <!-- Filtros -->
    <div class="bg-white rounded-2xl border border-slate-200 p-4">
      <div class="grid gap-3 md:grid-cols-6">
        <div class="md:col-span-2">
          <label class="text-xs text-slate-500">Buscar</label>
          <input
            [(ngModel)]="q"
            (keyup.enter)="applyFilters()"
            placeholder="Nombre o CI"
            class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-200 focus:border-blue-300">
        </div>

        <div>
          <label class="text-xs text-slate-500">Área</label>
          <select
            [(ngModel)]="areaId"
            class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
            <option [ngValue]="0">Todas</option>
            <option *ngFor="let a of areas()" [ngValue]="a.id">{{ a.nombre }}</option>
          </select>
        </div>

        <div>
          <label class="text-xs text-slate-500">Nivel</label>
          <input
            [(ngModel)]="nivel"
            class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
        </div>

        <div>
          <label class="text-xs text-slate-500">Estado</label>
          <select
            [(ngModel)]="estado"
            class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
            <option [ngValue]="''">Todos</option>
            <option value="pendiente">Pendiente</option>
            <option value="desclasificado">Desclasificado</option>
            <option value="no_clasificado">No clasificado</option>
            <option value="evaluado">Evaluado</option>
            <option value="clasificado">Clasificado</option>
          </select>
        </div>

        <div class="flex items-end gap-2">
          <button
            (click)="applyFilters()"
            class="rounded-lg bg-[#0f3f94] hover:bg-[#0d3580] text-white px-3 py-2 text-sm">
            <i class="bi bi-search"></i> Filtrar
          </button>
          <button
            (click)="clear()"
            class="rounded-lg bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50">
            Limpiar
          </button>
        </div>
      </div>

      <div class="mt-3 flex items-center gap-2">
        <label class="text-xs text-slate-500">Ordenar por</label>
        <select
          [(ngModel)]="order"
          (change)="applyFilters()"
          class="rounded-lg border border-slate-300 px-2 py-1 text-sm">
          <option value="nombre">Nombre (A–Z)</option>
          <option value="area">Área</option>
          <option value="nivel">Nivel</option>
        </select>
        <select
          [(ngModel)]="dir"
          (change)="applyFilters()"
          class="rounded-lg border border-slate-300 px-2 py-1 text-sm">
          <option value="asc">Asc</option>
          <option value="desc">Desc</option>
        </select>
      </div>
    </div>

    <!-- Tabla + paginación -->
    <div class="bg-white rounded-2xl border border-slate-200 p-0 overflow-hidden flex flex-col">
      <div class="flex items-center justify-between p-3">
        <div class="font-semibold">
          Resultados ({{ meta().total }} reg.)
        </div>
      </div>

      <!-- Contenedor scroll interno -->
      <div class="overflow-x-auto overflow-y-auto max-h-[60vh] border-t border-slate-100">
        <table class="min-w-full text-sm">
          <thead class="bg-slate-50 sticky top-0 z-10">
            <tr class="text-left text-slate-600">
              <th class="py-2 px-3">Nombre</th>
              <th class="py-2 px-3">CI</th>
              <th class="py-2 px-3">Área</th>
              <th class="py-2 px-3">Nivel</th>
              <th class="py-2 px-3">Estado</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngIf="rows().length === 0">
              <td colspan="5" class="py-4 text-center text-slate-400">
                Sin resultados
              </td>
            </tr>

            <tr *ngFor="let r of rows()" class="border-t border-slate-100">
              <td class="py-2 px-3 whitespace-nowrap">{{ r.nombre }}</td>
              <td class="py-2 px-3 whitespace-nowrap">{{ r.ci }}</td>
              <td class="py-2 px-3 whitespace-nowrap">{{ r.area }}</td>
              <td class="py-2 px-3 whitespace-nowrap">{{ r.nivel }}</td>
              <td class="py-2 px-3">
                <span
                  class="inline-flex text-xs rounded-full px-2 py-1 capitalize"
                  [class.bg-amber-100]="r.estado === 'pendiente'"
                  [class.text-amber-700]="r.estado === 'pendiente'"
                  [class.bg-red-100]="r.estado === 'desclasificado' || r.estado === 'no_clasificado'"
                  [class.text-red-700]="r.estado === 'desclasificado' || r.estado === 'no_clasificado'"
                  [class.bg-emerald-100]="r.estado === 'evaluado'"
                  [class.text-emerald-700]="r.estado === 'evaluado'"
                  [class.bg-blue-100]="r.estado === 'clasificado'"
                  [class.text-blue-700]="r.estado === 'clasificado'">
                  {{ r.estado || '—' }}
                </span>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Paginación -->
      <div class="flex items-center justify-between p-3 text-sm border-t border-slate-100">
        <div class="text-slate-500">
          Página {{ meta().page }} de {{ meta().total_pages }} • {{ meta().total }} registros
        </div>
        <div class="flex items-center gap-2">
          <button
            (click)="go(meta().page - 1)"
            [disabled]="meta().page <= 1"
            class="rounded-lg bg-white border border-slate-200 px-3 py-1.5 disabled:opacity-50 hover:bg-slate-50">
            <i class="bi bi-chevron-left"></i>
          </button>
          <button
            (click)="go(meta().page + 1)"
            [disabled]="meta().page >= meta().total_pages"
            class="rounded-lg bg-white border border-slate-200 px-3 py-1.5 disabled:opacity-50 hover:bg-slate-50">
            <i class="bi bi-chevron-right"></i>
          </button>
        </div>
      </div>
    </div>

    <!-- Modal Guardar lista -->
    <div *ngIf="saveOpen()" class="fixed inset-0 z-50 flex items-center justify-center">
      <div class="absolute inset-0 bg-black/50" (click)="closeSave()"></div>
      <div class="relative bg-white rounded-2xl shadow-xl w-full max-w-md">
        <div class="p-4 border-b border-slate-200 font-semibold">
          Guardar lista
        </div>
        <div class="p-4 space-y-3">
          <div>
            <label class="text-xs text-slate-500">Fecha de competición *</label>
            <input
              type="date"
              [(ngModel)]="fecha"
              class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
          </div>
          <div>
            <label class="text-xs text-slate-500">Nombre (opcional)</label>
            <input
              [(ngModel)]="nombre"
              class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              placeholder="Ej. Clasificados Área X">
          </div>
          <div
            *ngIf="saveMsg()"
            class="text-sm"
            [class.text-red-600]="!saveOk()"
            [class.text-emerald-600]="saveOk()">
            {{ saveMsg() }}
          </div>
        </div>
        <div class="p-4 border-t border-slate-200 flex items-center justify-end gap-2">
          <button
            (click)="closeSave()"
            class="rounded-lg bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50">
            Cancelar
          </button>
          <button
            (click)="doSave()"
            [disabled]="saving()"
            class="rounded-lg bg-[#0f3f94] hover:bg-[#0d3580] text-white px-4 py-2 text-sm">
            <ng-container *ngIf="!saving(); else svTpl">
              <i class="bi bi-save"></i> Guardar
            </ng-container>
            <ng-template #svTpl>Guardando...</ng-template>
          </button>
        </div>
      </div>
    </div>
  </section>
  `
})
export class CompetidoresComponent {
  private api = inject(ApiService);

  areas = signal<Area[]>([]);
  rows = signal<Row[]>([]);
  meta = signal<Meta>({ page: 1, per_page: 15, total: 0, total_pages: 0 });

  q = '';
  areaId = 0;
  nivel = '';
  estado = '';
  order: 'nombre' | 'area' | 'nivel' = 'nombre';
  dir: 'asc' | 'desc' = 'asc';

  saveOpen = signal(false);
  fecha = '';
  nombre = '';
  saving = signal(false);
  saveMsg = signal('');
  saveOk = signal(false);

  ngOnInit() {
    this.loadAreas();
    this.fetch();
  }

  loadAreas() {
    this.api
      .get<{ data: { id: number; nombre: string }[] }>('/responsable/areas')
      .subscribe({
        next: r => this.areas.set(r.data || []),
        error: () => this.areas.set([])
      });
  }

  params(): Record<string, string> {
    const m = this.meta();
    const p: any = {
      page: String(m.page),
      per_page: String(15),
      order: this.order,
      dir: this.dir
    };

    if (this.q.trim()) p.q = this.q.trim();
    if (this.areaId) p.area_id = String(this.areaId);
    if (this.nivel.trim()) p.nivel = this.nivel.trim();
    if (this.estado.trim()) p.estado = this.estado.trim();

    return p;
  }

  private fetch() {
    const qs = new URLSearchParams(this.params()).toString();
    this.api
      .get<{ data: Row[]; meta: Meta; ok?: boolean }>(
        `/responsable/competidores?${qs}`
      )
      .subscribe({
        next: r => {
          this.rows.set(r.data || []);
          this.meta.set(
            r.meta || { page: 1, per_page: 15, total: 0, total_pages: 0 }
          );
        },
        error: () => {
          this.rows.set([]);
          this.meta.set({ page: 1, per_page: 15, total: 0, total_pages: 0 });
        }
      });
  }

  applyFilters() {
    this.meta.set({ ...this.meta(), page: 1 });
    this.fetch();
  }

  clear() {
    this.q = '';
    this.areaId = 0;
    this.nivel = '';
    this.estado = '';
    this.order = 'nombre';
    this.dir = 'asc';
    this.meta.set({ ...this.meta(), page: 1 });
    this.fetch();
  }

  go(p: number) {
    const m = this.meta();
    if (p < 1 || p > m.total_pages) return;
    this.meta.set({ ...m, page: p });
    this.fetch();
  }

  export(format: 'csv' | 'pdf') {
    const qs = new URLSearchParams(this.params()).toString();
    const base = (window as any).environment?.apiUrl || '';
    window.open(
      `${base}/responsable/competidores/export?format=${format}&${qs}`,
      '_blank'
    );
  }

  openSave() {
    this.saveOpen.set(true);
    this.saveMsg.set('');
    this.saveOk.set(false);
  }

  closeSave() {
    this.saveOpen.set(false);
  }

  doSave() {
    if (!this.fecha) {
      this.saveMsg.set('Selecciona la fecha de competición.');
      this.saveOk.set(false);
      return;
    }

    this.saving.set(true);
    this.saveMsg.set('');

    const body = {
      fecha_competencia: this.fecha,
      nombre: this.nombre || null,
      area_id: this.areaId || null,
      nivel: this.nivel || null,
      filtros: this.params()
    };

    this.api
      .post<{
        ok: boolean;
        message?: string;
        lista_id?: number;
        total_items?: number;
      }>('/responsable/competidores/listas', body)
      .subscribe({
        next: res => {
          this.saveOk.set(!!res.ok);
          this.saveMsg.set(
            res.message || (res.ok ? 'Lista guardada.' : 'No se pudo guardar.')
          );
          if (res.ok) {
            setTimeout(() => this.closeSave(), 500);
          }
          this.saving.set(false);
        },
        error: err => {
          this.saveOk.set(false);
          this.saveMsg.set(
            (err as any)?.error?.message || 'Error al guardar.'
          );
          this.saving.set(false);
        }
      });
  }
}
