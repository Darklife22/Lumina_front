import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';

type Area = {
  id: number;
  nombre: string;
};

type EvaluadorRow = {
  id: number;
  usuario_id: number;
  nombre: string;
  email: string;
  telefono?: string | null;
  activo: boolean;
  areas: Area[];
};

type Meta = {
  page: number;
  per_page: number;
  total: number;
  total_pages: number;
};

type EvaluadorLite = {
  id: number;
  nombre: string;
  email: string;
  telefono?: string | null;
  activo: boolean;
  areas: Area[];
};

type UsuarioLite = {
  id: number;
  nombre: string;
  email: string;
  telefono?: string | null;
  evaluador: EvaluadorLite | null;
};

interface ListResponse {
  data: EvaluadorRow[];
  meta: Meta;
}

interface AreasResponse {
  data: Area[];
}

interface BuscarUsuariosResponse {
  data: UsuarioLite[];
}

interface SaveResponse {
  ok: boolean;
  message?: string;
  data?: EvaluadorRow;
}

interface OkResponse {
  ok: boolean;
  message?: string;
}

@Component({
  standalone: true,
  selector: 'app-evaluadores',
  imports: [CommonModule, FormsModule],
  template: `
  <section class="space-y-4">
    <!-- Header -->
    <div class="bg-white rounded-2xl border border-slate-200 p-4 flex items-center justify-between">
      <div>
        <div class="text-lg font-bold">Evaluadores</div>
        <div class="text-sm text-slate-500 -mt-0.5">
          Asignación de rol de Evaluador y vinculación a Áreas
        </div>
      </div>
      <div class="flex items-center gap-2">
        <button
          (click)="openForm()"
          class="rounded-lg bg-[#0f3f94] hover:bg-[#0d3580] text-white px-3 py-2 text-sm">
          <i class="bi bi-plus-lg"></i> Asignar evaluador
        </button>
      </div>
    </div>

    <!-- Filtros -->
    <div class="bg-white rounded-2xl border border-slate-200 p-4">
      <div class="grid gap-3 md:grid-cols-4">
        <div class="md:col-span-2">
          <label class="text-xs text-slate-500">Buscar</label>
          <input
            [(ngModel)]="q"
            (keyup.enter)="search()"
            placeholder="Nombre, email o teléfono"
            class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none
                   focus:ring-2 focus:ring-blue-200 focus:border-blue-300">
        </div>
        <div>
          <label class="text-xs text-slate-500">Área</label>
          <select
            [(ngModel)]="areaId"
            (ngModelChange)="onAreaFilterChange()"
            class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
            <option [ngValue]="0">Todas</option>
            <option *ngFor="let a of areas()" [ngValue]="a.id">
              {{ a.nombre }}
            </option>
          </select>
        </div>
        <div class="flex items-end gap-2">
          <button
            (click)="search()"
            class="rounded-lg bg-[#0f3f94] hover:bg-[#0d3580] text-white px-3 py-2 text-sm">
            <i class="bi bi-search"></i> Filtrar
          </button>
          <button
            (click)="clear()"
            class="rounded-lg bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50">
            Limpiar
          </button>
        </div>
      </div>
    </div>

    <!-- Tabla -->
    <div class="bg-white rounded-2xl border border-slate-200 p-0">
      <div class="flex items-center justify-between p-3">
        <div class="font-semibold">Listado de evaluadores ({{ meta().total }} reg.)</div>
      </div>

      <div class="overflow-auto">
        <table class="min-w-full text-sm">
          <thead class="bg-slate-50 sticky top-0">
            <tr class="text-left text-slate-600">
              <th class="py-2 px-3">Evaluador</th>
              <th class="py-2 px-3">Email</th>
              <th class="py-2 px-3">Teléfono</th>
              <th class="py-2 px-3">Áreas asignadas</th>
              <th class="py-2 px-3">Estado</th>
              <th class="py-2 px-3">Acciones</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngIf="rows().length === 0">
              <td colspan="6" class="py-4 text-center text-slate-400">
                No hay evaluadores registrados.
              </td>
            </tr>

            <tr *ngFor="let r of rows()" class="border-t border-slate-100">
              <td class="py-2 px-3">
                <div class="font-medium text-slate-800">{{ r.nombre }}</div>
              </td>
              <td class="py-2 px-3">
                <a
                  *ngIf="r.email"
                  class="text-blue-600 hover:underline"
                  [href]="'mailto:' + r.email">
                  {{ r.email }}
                </a>
                <span *ngIf="!r.email" class="text-slate-400">—</span>
              </td>
              <td class="py-2 px-3">
                <span *ngIf="r.telefono; else dashTpl">{{ r.telefono }}</span>
                <ng-template #dashTpl>—</ng-template>
              </td>
              <td class="py-2 px-3">
                <div class="flex flex-wrap gap-1">
                  <span
                    *ngFor="let a of r.areas"
                    class="inline-flex items-center rounded-full bg-emerald-50 text-emerald-700
                           px-2 py-0.5 text-[11px] border border-emerald-200">
                    {{ a.nombre }}
                  </span>
                  <span *ngIf="!r.areas?.length" class="text-xs text-slate-400">Sin áreas</span>
                </div>
              </td>
              <td class="py-2 px-3">
                <span
                  class="text-xs rounded-full px-2 py-1"
                  [class.bg-emerald-100]="r.activo"
                  [class.text-emerald-700]="r.activo"
                  [class.bg-red-100]="!r.activo"
                  [class.text-red-700]="!r.activo">
                  {{ r.activo ? 'Activo' : 'Inactivo' }}
                </span>
              </td>
              <td class="py-2 px-3">
                <div class="flex items-center gap-3 text-xs">
                  <button
                    class="text-blue-600 hover:underline"
                    (click)="edit(r)">
                    Editar
                  </button>
                  <button
                    class="text-red-600 hover:underline"
                    (click)="remove(r)">
                    Quitar rol
                  </button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Paginación -->
      <div class="flex items-center justify-between p-3 text-sm">
        <div class="text-slate-500">
          Página {{ meta().page }} de {{ meta().total_pages }} • {{ meta().total }} registros
        </div>
        <div class="flex items-center gap-2">
          <button
            (click)="goTo(meta().page - 1)"
            [disabled]="meta().page <= 1"
            class="rounded-lg bg-white border border-slate-200 px-3 py-1.5 disabled:opacity-50 hover:bg-slate-50">
            <i class="bi bi-chevron-left"></i>
          </button>
          <button
            (click)="goTo(meta().page + 1)"
            [disabled]="meta().page >= meta().total_pages"
            class="rounded-lg bg-white border border-slate-200 px-3 py-1.5 disabled:opacity-50 hover:bg-slate-50">
            <i class="bi bi-chevron-right"></i>
          </button>
        </div>
      </div>
    </div>

    <!-- Modal Asignar/Editar evaluador -->
    <div *ngIf="formOpen()" class="fixed inset-0 z-50 flex items-center justify-center">
      <div class="absolute inset-0 bg-black/50" (click)="closeForm()"></div>
      <div class="relative bg-white rounded-2xl shadow-xl w-full max-w-2xl">
        <div class="p-4 border-b border-slate-200 flex items-center justify-between">
          <div class="font-semibold">
            {{ editingId() ? 'Editar evaluador' : 'Asignar evaluador' }}
          </div>
          <button
            class="w-8 h-8 rounded-lg border border-slate-200 hover:bg-slate-50"
            (click)="closeForm()">
            <i class="bi bi-x"></i>
          </button>
        </div>

        <div class="p-4 space-y-4 max-h-[70vh] overflow-auto">
          <!-- Selección de usuario -->
          <div class="rounded-xl border border-slate-200 bg-slate-50/40 p-3 space-y-2">
            <div class="flex items-center justify-between gap-2">
              <div class="text-xs font-semibold text-slate-600">
                Seleccionar usuario registrado
              </div>
              <div class="text-[11px] text-slate-500" *ngIf="editingId()">
                Estás editando un evaluador ya existente.
              </div>
            </div>

            <div class="flex flex-col gap-2 md:flex-row md:items-center">
              <input
                [(ngModel)]="userSearchTerm"
                (keyup.enter)="buscarUsuarios()"
                placeholder="Buscar por nombre, apellido o correo..."
                class="flex-1 rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none
                       focus:ring-2 focus:ring-blue-200 focus:border-blue-300">
              <button
                (click)="buscarUsuarios()"
                [disabled]="userSearchLoading() || !userSearchTerm.trim()"
                class="rounded-lg bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50 disabled:opacity-50">
                <ng-container *ngIf="!userSearchLoading(); else loadingUsersTpl">
                  <i class="bi bi-search"></i> Buscar
                </ng-container>
                <ng-template #loadingUsersTpl>
                  <span class="inline-flex items-center gap-2 text-xs">
                    <span
                      class="inline-block h-3 w-3 border-2 border-slate-400/60 border-t-slate-500 rounded-full animate-spin"></span>
                    Buscando...
                  </span>
                </ng-template>
              </button>
            </div>

            <!-- Usuario seleccionado -->
            <div *ngIf="form.usuario_id" class="mt-2 text-xs flex items-center justify-between gap-2">
              <div class="flex flex-col">
                <span class="text-slate-600">
                  Usuario seleccionado:
                  <span class="font-semibold">{{ selectedUsuarioNombre() }}</span>
                </span>
                <span class="text-slate-500">
                  {{ selectedUsuarioEmail() }}
                  <span *ngIf="selectedUsuarioTelefono()"> · Tel: {{ selectedUsuarioTelefono() }}</span>
                </span>
              </div>
              <button
                class="text-[11px] rounded-md border border-slate-200 px-2 py-1 hover:bg-slate-100"
                (click)="desvincularUsuario()">
                Quitar selección
              </button>
            </div>

            <!-- Resultados en cards -->
            <div
              *ngIf="userResults().length"
              class="mt-3 space-y-2 max-h-56 overflow-auto">
              <div
                *ngFor="let u of userResults()"
                class="flex items-center justify-between gap-3 border border-slate-200 rounded-lg px-3 py-2 hover:bg-slate-50 transition">
                <div class="flex flex-col">
                  <span class="text-sm font-medium text-slate-800">
                    {{ u.nombre }}
                  </span>
                  <span class="text-xs text-slate-500">
                    {{ u.email }}
                    <span *ngIf="u.telefono"> · {{ u.telefono }}</span>
                  </span>
                  <span *ngIf="u.evaluador" class="text-[11px] text-emerald-700 mt-0.5">
                    Ya tiene rol de evaluador asignado
                  </span>
                </div>
                <button
                  class="text-[11px] rounded-md bg-[#0f3f94] text-white px-3 py-1.5 hover:bg-[#0d3580] whitespace-nowrap"
                  (click)="seleccionarUsuario(u)">
                  {{ u.evaluador ? 'Editar evaluador' : 'Usar usuario' }}
                </button>
              </div>
            </div>

            <div *ngIf="userSearchError()" class="mt-1 text-[11px] text-red-600">
              {{ userSearchError() }}
            </div>
          </div>

          <!-- Áreas -->
          <div>
            <div class="flex items-center justify-between gap-2 mb-1">
              <label class="text-xs text-slate-500">
                Áreas asignadas *
              </label>
              <div class="flex items-center gap-1 text-[11px]">
                <button
                  class="rounded-md border border-slate-200 px-2 py-0.5 hover:bg-slate-50"
                  (click)="toggleAllAreas(true)">
                  Todas visibles
                </button>
                <button
                  class="rounded-md border border-slate-200 px-2 py-0.5 hover:bg-slate-50"
                  (click)="toggleAllAreas(false)">
                  Ninguna nueva
                </button>
              </div>
            </div>

            <div class="text-[11px] text-slate-500 mb-1" *ngIf="editingId()">
              Las áreas ya asignadas se mantienen. Para quitarlas se usa la opción
              <strong>"Quitar áreas actuales"</strong> con motivo.
            </div>

            <input
              [(ngModel)]="areasFilter"
              placeholder="Filtrar áreas..."
              class="w-full rounded-lg border border-slate-300 px-2 py-1 text-sm mb-2">

            <div class="grid grid-cols-1 md:grid-cols-2 gap-2 max-h-60 overflow-auto pr-1">
              <label
                *ngFor="let a of filteredAreas()"
                class="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  [checked]="form.areas.includes(a.id)"
                  (change)="toggleArea(a.id, $event)">
                <span>
                  {{ a.nombre }}
                  <span
                    *ngIf="editingId() && originalAreas().includes(a.id)"
                    class="ml-1 text-[10px] text-amber-600">
                    ya asignada
                  </span>
                </span>
              </label>
            </div>

            <div class="mt-2 flex justify-end" *ngIf="editingId() && originalAreas().length">
              <button
                type="button"
                class="text-[11px] text-red-700 border border-red-200 rounded-md px-2 py-1 bg-red-50 hover:bg-red-100"
                (click)="openRemoveAreasModal()">
                <i class="bi bi-slash-circle me-1"></i> Quitar áreas actuales (con motivo)
              </button>
            </div>
          </div>

          <!-- Estado -->
          <div class="flex items-center justify-between gap-4">
            <label class="inline-flex items-center gap-2 text-sm">
              <input type="checkbox" [(ngModel)]="form.activo">
              <span>Evaluador activo</span>
            </label>
          </div>

          <!-- Mensajes -->
          <div
            *ngIf="errorMsg()"
            class="rounded-xl border border-red-200 bg-red-50 text-red-700 px-3 py-2 text-sm">
            {{ errorMsg() }}
          </div>
          <div
            *ngIf="successMsg()"
            class="rounded-xl border border-emerald-200 bg-emerald-50 text-emerald-700 px-3 py-2 text-sm">
            {{ successMsg() }}
          </div>
        </div>

        <div class="p-4 border-t border-slate-200 flex items-center justify-end gap-2">
          <button
            (click)="closeForm()"
            class="rounded-lg bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50">
            Cancelar
          </button>
          <button
            (click)="save()"
            [disabled]="saving()"
            class="rounded-lg bg-[#0f3f94] hover:bg-[#0d3580] text-white px-4 py-2 text-sm">
            <ng-container *ngIf="!saving(); else savingTpl">
              <i class="bi bi-save"></i> Guardar
            </ng-container>
            <ng-template #savingTpl>
              <span class="inline-flex items-center gap-2">
                <span
                  class="inline-block h-4 w-4 border-2 border-white/60 border-t-white rounded-full animate-spin"></span>
                Guardando...
              </span>
            </ng-template>
          </button>
        </div>
      </div>
    </div>

    <!-- Modal Quitar áreas actuales -->
    <div *ngIf="removeOpen()" class="fixed inset-0 z-50 flex items-center justify-center">
      <div class="absolute inset-0 bg-black/50" (click)="closeRemoveAreasModal()"></div>
      <div class="relative bg-white rounded-2xl shadow-xl w-full max-w-lg">
        <div class="p-4 border-b border-slate-200 flex items-center justify-between">
          <div class="font-semibold text-red-700 flex items-center gap-2">
            <i class="bi bi-slash-circle"></i>
            Quitar áreas del evaluador
          </div>
          <button
            class="w-8 h-8 rounded-lg border border-slate-200 hover:bg-slate-50"
            (click)="closeRemoveAreasModal()"
            [disabled]="removeSaving()">
            <i class="bi bi-x"></i>
          </button>
        </div>

        <div class="p-4 space-y-3 max-h-[70vh] overflow-auto">
          <div class="text-sm text-slate-600">
            Selecciona las áreas que deseas desvincular del evaluador
            <span class="font-semibold" *ngIf="selectedUsuarioNombre()">
              {{ selectedUsuarioNombre() }}
            </span>.
          </div>

          <div class="text-xs text-slate-500 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2">
            Esta acción requiere un motivo y respeta las restricciones del proceso
            (fase activa, notas pendientes, etc.). Las calificaciones ya registradas se mantienen
            para fines de historial.
          </div>

          <div class="max-h-52 overflow-auto border border-slate-200 rounded-lg px-3 py-2 space-y-1">
            <label
              *ngFor="let a of areasOriginalesDetalladas()"
              class="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                [checked]="removeSeleccion().includes(a.id)"
                (change)="toggleRemoveArea(a.id, $event)">
              <span>{{ a.nombre }}</span>
            </label>
            <div *ngIf="!areasOriginalesDetalladas().length" class="text-xs text-slate-400">
              El evaluador no tiene áreas actualmente asignadas desde la base de datos.
            </div>
          </div>

          <div>
            <label class="block text-xs font-medium text-slate-600 mb-1">
              Motivo de la desvinculación <span class="text-red-500">*</span>
            </label>
            <textarea
              rows="4"
              class="w-full rounded-lg border px-3 py-2 text-sm outline-none
                     focus:ring-2 focus:ring-red-200 focus:border-red-300 border-slate-300"
              [ngModel]="removeMotivo()"
              (ngModelChange)="removeMotivo.set($event)"
              [disabled]="removeSaving()"
              maxlength="500"
              placeholder="Describe brevemente por qué se quitan estas áreas al evaluador..."
            ></textarea>
            <div class="flex justify-between items-center mt-1">
              <span class="text-xs text-slate-500">
                Mínimo 5 caracteres. Máximo 500.
              </span>
              <span class="text-xs text-slate-400">
                {{ removeMotivo().length }}/500
              </span>
            </div>
          </div>

          <div *ngIf="removeError()" class="text-xs text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
            {{ removeError() }}
          </div>
        </div>

        <div class="p-4 border-t border-slate-200 flex items-center justify-end gap-2 bg-slate-50/50">
          <button
            type="button"
            class="rounded-lg px-3 py-1.5 text-sm border border-slate-200 hover:bg-white"
            (click)="closeRemoveAreasModal()"
            [disabled]="removeSaving()">
            Cancelar
          </button>
          <button
            type="button"
            class="rounded-lg px-4 py-1.5 text-sm text-white bg-red-600 hover:bg-red-700 disabled:opacity-60 disabled:cursor-not-allowed"
            (click)="submitRemoveAreas()"
            [disabled]="removeSaving() || !canSubmitRemove()">
            <ng-container *ngIf="!removeSaving(); else removeSavingTpl">
              Confirmar remoción
            </ng-container>
          </button>
        </div>

        <ng-template #removeSavingTpl>
          <span class="inline-flex items-center gap-2 text-xs text-white">
            <span class="inline-block h-3.5 w-3.5 border-2 border-white/60 border-t-white rounded-full animate-spin"></span>
            Procesando...
          </span>
        </ng-template>
      </div>
    </div>
  </section>
  `
})
export class EvaluadoresComponent {
  private api = inject(ApiService);

  // Filtros listado
  q = '';
  areaId = 0;

  rows = signal<EvaluadorRow[]>([]);
  meta = signal<Meta>({ page: 1, per_page: 15, total: 0, total_pages: 0 });

  areas = signal<Area[]>([]);

  // Modal principal
  formOpen = signal(false);
  saving = signal(false);
  editingId = signal<number | null>(null);
  errorMsg = signal('');
  successMsg = signal('');

  form: {
    usuario_id: number | null;
    areas: number[];
    activo: boolean;
  } = {
    usuario_id: null,
    areas: [],
    activo: true
  };

  areasFilter = '';
  originalAreas = signal<number[]>([]);

  // Búsqueda de usuarios
  userSearchTerm = '';
  userResults = signal<UsuarioLite[]>([]);
  userSearchLoading = signal(false);
  userSearchError = signal('');

  selectedUsuarioNombre = signal('');
  selectedUsuarioEmail = signal('');
  selectedUsuarioTelefono = signal('');

  // Modal quitar áreas
  removeOpen = signal(false);
  removeSeleccion = signal<number[]>([]);
  removeMotivo = signal<string>('');
  removeSaving = signal<boolean>(false);
  removeError = signal<string | null>(null);

  ngOnInit(): void {
    this.fetchAreas();
    this.search();
  }

  // ======================= Listado =======================

  params(): Record<string, string> {
    const p: Record<string, string> = {
      page: String(this.meta().page),
      per_page: String(15)
    };
    if (this.q.trim()) p['q'] = this.q.trim();
    if (this.areaId) p['area_id'] = String(this.areaId);
    return p;
  }

  search(): void {
    const qs = new URLSearchParams(this.params()).toString();
    this.api.get(`/admin/evaluadores?${qs}`).subscribe(
      value => {
        const res = value as ListResponse;
        this.rows.set(res?.data ?? []);
        this.meta.set(
          res?.meta ?? { page: 1, per_page: 15, total: 0, total_pages: 0 }
        );
      },
      () => {
        this.rows.set([]);
        this.meta.set({ page: 1, per_page: 15, total: 0, total_pages: 0 });
      }
    );
  }

  clear(): void {
    this.q = '';
    this.areaId = 0;
    this.meta.set({ ...this.meta(), page: 1 });
    this.search();
  }

  goTo(p: number): void {
    const m = this.meta();
    if (p < 1 || p > m.total_pages) return;
    this.meta.set({ ...m, page: p });
    this.search();
  }

  onAreaFilterChange(): void {
    this.meta.set({ ...this.meta(), page: 1 });
    this.search();
  }

  // ======================= Áreas =======================

  fetchAreas(): void {
    // 🔹 Reutilizamos el endpoint que ya funciona en Responsables
    this.api.get('/admin/responsables/areas').subscribe(
      value => {
        const res = value as AreasResponse;
        this.areas.set(res?.data ?? []);
      },
      () => this.areas.set([])
    );
  }

  filteredAreas(): Area[] {
    const f = this.areasFilter.trim().toLowerCase();
    if (!f) return this.areas();
    return this.areas().filter(a =>
      a.nombre.toLowerCase().includes(f)
    );
  }

  toggleAllAreas(mark: boolean): void {
    const visibles = this.filteredAreas().map(a => a.id);
    if (mark) {
      const set = new Set<number>([...this.form.areas, ...visibles]);
      this.form.areas = Array.from(set);
    } else {
      const visiblesSet = new Set(visibles);
      const originales = new Set(this.originalAreas());
      this.form.areas = this.form.areas.filter(id => {
        if (originales.has(id)) return true; // no tocamos las originales
        return !visiblesSet.has(id);
      });
    }
  }

  toggleArea(id: number, ev: Event): void {
    const checked = (ev.target as HTMLInputElement).checked;
    const esOriginal = this.originalAreas().includes(id);

    if (!checked && this.editingId() !== null && esOriginal) {
      if (!this.form.areas.includes(id)) {
        this.form.areas.push(id);
      }
      this.openRemoveAreasModal([id]);
      return;
    }

    if (checked && !this.form.areas.includes(id)) {
      this.form.areas.push(id);
    }
    if (!checked && !esOriginal) {
      this.form.areas = this.form.areas.filter(x => x !== id);
    }
  }

  areasOriginalesDetalladas(): Area[] {
    const set = new Set(this.originalAreas());
    return this.areas().filter(a => set.has(a.id));
  }

  // ======================= Modal principal =======================

  openForm(): void {
    this.editingId.set(null);
    this.form = {
      usuario_id: null,
      areas: [],
      activo: true
    };
    this.errorMsg.set('');
    this.successMsg.set('');
    this.userSearchTerm = '';
    this.userResults.set([]);
    this.userSearchError.set('');
    this.areasFilter = '';
    this.selectedUsuarioNombre.set('');
    this.selectedUsuarioEmail.set('');
    this.selectedUsuarioTelefono.set('');
    this.originalAreas.set([]);
    this.formOpen.set(true);
  }

  closeForm(): void {
    this.formOpen.set(false);
  }

  edit(r: EvaluadorRow): void {
    this.editingId.set(r.id);
    const areasIds = (r.areas || []).map(a => a.id);
    this.form = {
      usuario_id: r.usuario_id,
      areas: [...areasIds],
      activo: r.activo
    };
    this.originalAreas.set([...areasIds]);

    this.errorMsg.set('');
    this.successMsg.set('');
    this.userSearchTerm = '';
    this.userResults.set([]);
    this.userSearchError.set('');
    this.areasFilter = '';
    this.selectedUsuarioNombre.set(r.nombre);
    this.selectedUsuarioEmail.set(r.email);
    this.selectedUsuarioTelefono.set(r.telefono || '');
    this.formOpen.set(true);
  }

  // ======================= Búsqueda de usuario =======================

  buscarUsuarios(): void {
    const term = this.userSearchTerm.trim();
    if (!term) {
      this.userResults.set([]);
      this.userSearchError.set('');
      return;
    }

    this.userSearchLoading.set(true);
    this.userSearchError.set('');
    this.userResults.set([]);

    this.api
      .get(`/admin/evaluadores/usuarios-buscar?q=${encodeURIComponent(term)}`)
      .subscribe(
        value => {
          const res = value as BuscarUsuariosResponse;
          const data = res?.data ?? [];
          this.userResults.set(data);
          if (!data.length) {
            this.userSearchError.set('No se encontraron usuarios con ese criterio.');
          }
          this.userSearchLoading.set(false);
        },
        () => {
          this.userSearchError.set('No se pudo buscar usuarios. Intenta nuevamente.');
          this.userSearchLoading.set(false);
        }
      );
  }

  seleccionarUsuario(u: UsuarioLite): void {
    this.form.usuario_id = u.id;

    if (u.evaluador) {
      this.editingId.set(u.evaluador.id);
      const ids = (u.evaluador.areas || []).map(a => a.id);
      this.form.areas = [...ids];
      this.form.activo = u.evaluador.activo;
      this.originalAreas.set([...ids]);
      this.successMsg.set('Este usuario ya es evaluador. Estás editando sus áreas asignadas.');
    } else {
      this.editingId.set(null);
      this.form.areas = [];
      this.form.activo = true;
      this.originalAreas.set([]);
      this.successMsg.set('');
    }

    this.selectedUsuarioNombre.set(u.nombre);
    this.selectedUsuarioEmail.set(u.email);
    this.selectedUsuarioTelefono.set(u.telefono || '');

    this.userResults.set([]);
    this.userSearchError.set('');
  }

  desvincularUsuario(): void {
    this.form.usuario_id = null;
    this.selectedUsuarioNombre.set('');
    this.selectedUsuarioEmail.set('');
    this.selectedUsuarioTelefono.set('');
    this.originalAreas.set([]);
  }

  // ======================= Guardar =======================

  save(): void {
    if (!this.form.usuario_id) {
      this.errorMsg.set('Debes seleccionar un usuario.');
      return;
    }
    if (!this.form.areas.length) {
      this.errorMsg.set('Debes asignar al menos un área.');
      return;
    }

    this.saving.set(true);
    this.errorMsg.set('');
    this.successMsg.set('');

    if (this.editingId() === null) {
      // CREATE
      this.api.post('/admin/evaluadores', this.form).subscribe(
        value => {
          const res = value as SaveResponse;
          if (res && res.ok) {
            this.successMsg.set(res.message || 'Evaluador asignado correctamente.');
            this.search();
            setTimeout(() => this.closeForm(), 450);
          } else {
            this.errorMsg.set((res && res.message) || 'No se pudo guardar.');
          }
          this.saving.set(false);
        },
        err => {
          const msg =
            (err as { error?: { message?: string } })?.error?.message ||
            'Error al guardar.';
          this.errorMsg.set(msg);
          this.saving.set(false);
        }
      );
    } else {
      // UPDATE (solo agrega áreas nuevas; no quita las antiguas)
      const id = this.editingId() as number;
      this.api.put(`/admin/evaluadores/${id}`, this.form).subscribe(
        value => {
          const res = value as SaveResponse;
          if (res && res.ok) {
            this.successMsg.set(res.message || 'Evaluador actualizado.');
            this.search();
            const areasIds = this.form.areas.slice();
            this.originalAreas.set(areasIds);
            setTimeout(() => this.closeForm(), 450);
          } else {
            this.errorMsg.set((res && res.message) || 'No se pudo guardar.');
          }
          this.saving.set(false);
        },
        err => {
          const msg =
            (err as { error?: { message?: string } })?.error?.message ||
            'Error al guardar.';
          this.errorMsg.set(msg);
          this.saving.set(false);
        }
      );
    }
  }

  // ======================= Quitar rol =======================

  remove(r: EvaluadorRow): void {
    if (!confirm(`¿Quitar rol de evaluador a "${r.nombre}"?`)) return;

    this.api.delete(`/admin/evaluadores/${r.id}`).subscribe(
      value => {
        const res = value as OkResponse;
        if (res && res.ok) {
          this.search();
        } else if (res && res.message) {
          alert(res.message);
        }
      },
      err => {
        const msg =
          (err as { error?: { message?: string } })?.error?.message ||
          'No se pudo quitar el rol.';
        alert(msg);
      }
    );
  }

  // ======================= Modal remover áreas =======================

  openRemoveAreasModal(preselect?: number[]): void {
    if (!this.editingId()) return;
    const originales = this.originalAreas();
    if (!originales.length) return;

    const baseSeleccion = preselect && preselect.length
      ? originales.filter(id => preselect.includes(id))
      : [];

    this.removeSeleccion.set(baseSeleccion);
    this.removeMotivo.set('');
    this.removeError.set(null);
    this.removeOpen.set(true);
  }

  closeRemoveAreasModal(): void {
    if (this.removeSaving()) return;
    this.removeOpen.set(false);
    this.removeSeleccion.set([]);
    this.removeMotivo.set('');
    this.removeError.set(null);
  }

  toggleRemoveArea(id: number, ev: Event): void {
    const checked = (ev.target as HTMLInputElement).checked;
    const current = new Set(this.removeSeleccion());
    if (checked) current.add(id);
    else current.delete(id);
    this.removeSeleccion.set(Array.from(current));
  }

  canSubmitRemove(): boolean {
    if (!this.editingId()) return false;
    if (!this.removeSeleccion().length) return false;
    const motivo = (this.removeMotivo() || '').trim();
    if (motivo.length < 5) return false;
    return true;
  }

  submitRemoveAreas(): void {
    if (!this.canSubmitRemove() || this.removeSaving()) return;

    const id = this.editingId();
    if (!id) return;

    const payload = {
      areas_remover: this.removeSeleccion(),
      motivo: (this.removeMotivo() || '').trim(),
    };

    this.removeSaving.set(true);
    this.removeError.set(null);

    this.api.post(`/admin/evaluadores/${id}/remover-areas`, payload).subscribe({
      next: (value) => {
        const res = value as OkResponse;
        if (!res.ok) {
          this.removeError.set(res.message || 'No se pudieron quitar las áreas.');
          this.removeSaving.set(false);
          return;
        }

        const remover = new Set(this.removeSeleccion());
        this.form.areas = this.form.areas.filter(id2 => !remover.has(id2));
        this.originalAreas.set(this.originalAreas().filter(id2 => !remover.has(id2)));

        this.successMsg.set(res.message || 'Áreas desvinculadas correctamente.');
        this.search();
        this.removeSaving.set(false);
        this.closeRemoveAreasModal();
      },
      error: (err) => {
        const msg =
          (err as { error?: { message?: string } })?.error?.message ||
          'No se pudieron quitar las áreas.';
        this.removeError.set(msg);
        this.removeSaving.set(false);
      }
    });
  }
}
