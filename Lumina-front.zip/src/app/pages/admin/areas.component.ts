// src/app/pages/admin/areas.component.ts
import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';

type Edicion = { id: number; nombre: string; vigente?: boolean };

type AreaRow = {
  id: number;
  nombre: string;
  rango_min: number;
  rango_max: number;
  umbral_clasificacion: number;
  activo: boolean;
  ediciones?: Edicion[];
};

type Meta = { page: number; per_page: number; total: number; total_pages: number };

@Component({
  standalone: true,
  selector: 'app-areas',
  imports: [CommonModule, FormsModule],
  template: `
  <section class="space-y-4">
    <!-- Header -->
    <div class="bg-white rounded-2xl border border-slate-200 p-4 flex items-center justify-between">
      <div>
        <div class="text-lg font-bold">Áreas de la Olimpiada</div>
        <div class="text-sm text-slate-500 -mt-0.5">
          Crear, editar y asociar áreas a las diferentes ediciones.
        </div>
      </div>
      <div class="flex items-center gap-2">
        <button
          (click)="openForm()"
          class="rounded-lg bg-[#0f3f94] hover:bg-[#0d3580] text-white px-3 py-2 text-sm">
          <i class="bi bi-plus-lg"></i> Crear nueva área
        </button>
      </div>
    </div>

    <!-- Filtros -->
    <div class="bg-white rounded-2xl border border-slate-200 p-4">
      <div class="grid gap-3 md:grid-cols-4">
        <div class="md:col-span-2">
          <label class="text-xs text-slate-500">Buscar</label>
          <input
            [(ngModel)]="q"
            (keyup.enter)="search()"
            placeholder="Nombre de área"
            class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-200 focus:border-blue-300">
        </div>

        <div>
          <label class="text-xs text-slate-500">Estado</label>
          <select
            [(ngModel)]="estado"
            class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
            <option [ngValue]="''">Todos</option>
            <option [ngValue]="'1'">Activos</option>
            <option [ngValue]="'0'">Inactivos</option>
          </select>
        </div>

        <div class="flex items-end gap-2">
          <button
            (click)="search()"
            class="rounded-lg bg-[#0f3f94] hover:bg-[#0d3580] text-white px-3 py-2 text-sm">
            <i class="bi bi-search"></i> Filtrar
          </button>
          <button
            (click)="clear()"
            class="rounded-lg bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50">
            Limpiar
          </button>
        </div>
      </div>
    </div>

    <!-- Tabla -->
    <div class="bg-white rounded-2xl border border-slate-200 p-0">
      <div class="flex items-center justify-between p-3">
        <div class="font-semibold">Listado ({{ meta().total }} reg.)</div>
      </div>

      <div class="overflow-auto">
        <table class="min-w-full text-sm">
          <thead class="bg-slate-50 sticky top-0">
            <tr class="text-left text-slate-600">
              <th class="py-2 px-3">Área</th>
              <th class="py-2 px-3">Rango</th>
              <th class="py-2 px-3">Umbral</th>
              <th class="py-2 px-3">Ediciones</th>
              <th class="py-2 px-3">Estado</th>
              <th class="py-2 px-3">Acciones</th>
            </tr>
          </thead>
          <tbody>

            <tr *ngIf="rows().length === 0">
              <td colspan="6" class="text-center text-slate-400 py-4">
                No hay registros
              </td>
            </tr>

            <tr *ngFor="let r of rows()" class="border-t border-slate-100">
              <td class="py-2 px-3 font-medium">{{ r.nombre }}</td>
              <td class="py-2 px-3">{{ r.rango_min }} - {{ r.rango_max }}</td>
              <td class="py-2 px-3">{{ r.umbral_clasificacion }}</td>
              <td class="py-2 px-3">
                <div class="flex flex-wrap gap-1" *ngIf="r.ediciones?.length; else sinEd">
                  <span
                    *ngFor="let e of r.ediciones"
                    class="inline-flex items-center rounded-full bg-blue-50 text-blue-700 px-2 py-0.5 text-[11px] border border-blue-200">
                    {{ e.nombre }}
                  </span>
                </div>
                <ng-template #sinEd>
                  <span class="text-xs text-slate-400">—</span>
                </ng-template>
              </td>
              <td class="py-2 px-3">
                <span
                  class="text-xs rounded-full px-2 py-1"
                  [class.bg-emerald-100]="r.activo"
                  [class.text-emerald-700]="r.activo"
                  [class.bg-red-100]="!r.activo"
                  [class.text-red-700]="!r.activo">
                  {{ r.activo ? 'Activo' : 'Inactivo' }}
                </span>
              </td>
              <td class="py-2 px-3 text-xs">
                <button
                  class="text-blue-600 hover:underline mr-2"
                  (click)="edit(r)">
                  Editar
                </button>
                <button
                  class="text-red-600 hover:underline"
                  (click)="remove(r)">
                  Eliminar
                </button>
              </td>
            </tr>

          </tbody>
        </table>
      </div>

      <!-- Paginación -->
      <div class="flex items-center justify-between p-3 text-sm">
        <div class="text-slate-500">
          Página {{ meta().page }} de {{ meta().total_pages }} • {{ meta().total }} registros
        </div>

        <div class="flex items-center gap-2">
          <button
            (click)="goTo(meta().page - 1)"
            [disabled]="meta().page <= 1"
            class="rounded-lg bg-white border border-slate-200 px-3 py-1.5 disabled:opacity-50 hover:bg-slate-50">
            <i class="bi bi-chevron-left"></i>
          </button>
          <button
            (click)="goTo(meta().page + 1)"
            [disabled]="meta().page >= meta().total_pages"
            class="rounded-lg bg-white border border-slate-200 px-3 py-1.5 disabled:opacity-50 hover:bg-slate-50">
            <i class="bi bi-chevron-right"></i>
          </button>

          <select
            [(ngModel)]="perPage"
            (change)="search()"
            class="rounded-lg border border-slate-300 px-2 py-1">
            <option [value]="10">10</option>
            <option [value]="20">20</option>
            <option [value]="50">50</option>
            <option [value]="100">100</option>
          </select>
        </div>
      </div>
    </div>

    <!-- Modal Form -->
    <div *ngIf="formOpen()" class="fixed inset-0 z-50 flex items-center justify-center">
      <div class="absolute inset-0 bg-black/50" (click)="closeForm()"></div>

      <div class="relative bg-white rounded-2xl shadow-xl w-full max-w-2xl">
        <div class="p-4 border-b border-slate-200 flex items-center justify-between">
          <div class="font-semibold text-sm">
            {{ editingId() ? 'Editar área' : 'Crear nueva área' }}
          </div>
          <button
            class="w-8 h-8 rounded-lg border border-slate-200 hover:bg-slate-50"
            (click)="closeForm()">
            <i class="bi bi-x"></i>
          </button>
        </div>

        <div class="p-4 space-y-3 max-h-[70vh] overflow-auto">
          <div>
            <label class="text-xs text-slate-500">Nombre del área *</label>
            <input
              [(ngModel)]="form.nombre"
              class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
          </div>

          <div class="grid grid-cols-2 gap-3">
            <div>
              <label class="text-xs text-slate-500">Rango mínimo *</label>
              <input
                type="number"
                [(ngModel)]="form.rango_min"
                class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
            </div>
            <div>
              <label class="text-xs text-slate-500">Rango máximo *</label>
              <input
                type="number"
                [(ngModel)]="form.rango_max"
                class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
            </div>
          </div>

          <div>
            <label class="text-xs text-slate-500">Umbral de clasificación *</label>
            <input
              type="number"
              [(ngModel)]="form.umbral_clasificacion"
              class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
          </div>

          <div>
            <label class="text-xs text-slate-500">Asociar a ediciones</label>
            <div class="flex items-center gap-2 mt-1">
              <input
                [(ngModel)]="edicionFilter"
                placeholder="Filtrar ediciones..."
                class="flex-1 rounded-lg border border-slate-300 px-2 py-1 text-sm">
              <button
                (click)="toggleAllEdiciones(true)"
                type="button"
                class="text-xs rounded-md border border-slate-200 px-2 py-1 hover:bg-slate-50">
                Todas
              </button>
              <button
                (click)="toggleAllEdiciones(false)"
                type="button"
                class="text-xs rounded-md border border-slate-200 px-2 py-1 hover:bg-slate-50">
                Ninguna
              </button>
            </div>

            <div class="grid grid-cols-2 gap-2 mt-2 max-h-40 overflow-auto pr-1">
              <label
                *ngFor="let e of filteredEdiciones()"
                class="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  [checked]="form.ediciones_ids.includes(e.id)"
                  (change)="toggleEdicion(e.id, $event)">
                {{ e.nombre }}
              </label>
            </div>

            <div
              *ngIf="edicionesLoadError"
              class="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-md px-2 py-1 mt-2">
              No se pudo cargar el catálogo de ediciones (opcional). Puedes continuar sin asociarlas.
            </div>
          </div>

          <div *ngIf="editingId() !== null" class="flex items-center gap-2">
            <input type="checkbox" [(ngModel)]="form.activo" id="activo">
            <label for="activo" class="text-sm">Área activa</label>
          </div>

          <div
            *ngIf="errorMsg()"
            class="rounded-xl border border-red-200 bg-red-50 text-red-700 px-3 py-2 text-sm">
            {{ errorMsg() }}
          </div>
          <div
            *ngIf="successMsg()"
            class="rounded-xl border border-emerald-200 bg-emerald-50 text-emerald-700 px-3 py-2 text-sm">
            {{ successMsg() }}
          </div>
        </div>

        <div class="p-4 border-t border-slate-200 flex items-center justify-end gap-2">
          <button
            (click)="closeForm()"
            class="rounded-lg bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50">
            Cancelar
          </button>
          <button
            (click)="save()"
            [disabled]="saving()"
            class="rounded-lg bg-[#0f3f94] hover:bg-[#0d3580] text-white px-4 py-2 text-sm">
            <ng-container *ngIf="!saving(); else savingTpl">
              <i class="bi bi-save"></i> Guardar
            </ng-container>
            <ng-template #savingTpl>
              <span class="inline-flex items-center gap-2">
                <span class="inline-block h-4 w-4 border-2 border-white/60 border-t-white rounded-full animate-spin"></span>
                Guardando...
              </span>
            </ng-template>
          </button>
        </div>
      </div>
    </div>
  </section>
  `
})
export class AreasComponent {
  private api = inject(ApiService);

  // filtros
  q = '';
  estado: '' | '1' | '0' = '';
  page = 1;
  perPage = 20;

  rows = signal<AreaRow[]>([]);
  meta = signal<Meta>({ page: 1, per_page: 20, total: 0, total_pages: 0 });

  // form state
  formOpen = signal(false);
  saving = signal(false);
  editingId = signal<number | null>(null);
  errorMsg = signal('');
  successMsg = signal('');

  form: {
    nombre: string;
    rango_min: number | null;
    rango_max: number | null;
    umbral_clasificacion: number | null;
    activo: boolean;
    ediciones_ids: number[];
  } = {
    nombre: '',
    rango_min: null,
    rango_max: null,
    umbral_clasificacion: null,
    activo: true,
    ediciones_ids: []
  };

  // catálogo de ediciones
  ediciones: Edicion[] = [];
  edicionFilter = '';
  edicionesLoadError = false;

  ngOnInit() {
    this.loadEdiciones();
    this.search();
  }

  // =========================
  // Catálogo de ediciones
  // =========================
  private loadEdiciones() {
    this.api.get<{ ok?: boolean; data: any[] }>('/admin/ediciones').subscribe({
      next: (res) => {
        const data = res?.data || [];
        this.ediciones = data.map((e: any) => ({
          id: e.id,
          nombre: e.nombre_oficial ?? e.nombre ?? `${e.anio ?? ''} - ${e.slug ?? ''}`,
        }));
      },
      error: () => {
        this.ediciones = [];
        this.edicionesLoadError = true;
      }
    });
  }

  filteredEdiciones() {
    const f = this.edicionFilter.trim().toLowerCase();
    if (!f) return this.ediciones;
    return this.ediciones.filter(e => e.nombre.toLowerCase().includes(f));
  }

  toggleAllEdiciones(mark: boolean) {
    const visibles = this.filteredEdiciones().map(e => e.id);
    if (mark) {
      const set = new Set([...this.form.ediciones_ids, ...visibles]);
      this.form.ediciones_ids = Array.from(set);
    } else {
      const remove = new Set(visibles);
      this.form.ediciones_ids = this.form.ediciones_ids.filter(id => !remove.has(id));
    }
  }

  toggleEdicion(id: number, ev: Event) {
    const checked = (ev.target as HTMLInputElement).checked;
    if (checked && !this.form.ediciones_ids.includes(id)) {
      this.form.ediciones_ids.push(id);
    } else if (!checked) {
      this.form.ediciones_ids = this.form.ediciones_ids.filter(x => x !== id);
    }
  }

  // =========================
  // Listado / filtros
  // =========================
  params() {
    const p: any = { page: this.page, per_page: this.perPage };
    if (this.q) p['q'] = this.q;
    if (this.estado !== '') p['activo'] = this.estado;
    return p;
  }

  search() {
    const qs = new URLSearchParams(this.params()).toString();
    this.api.get<{ ok?: boolean; data: AreaRow[]; meta: Meta }>(`/admin/areas?${qs}`).subscribe({
      next: (res) => {
        this.rows.set(res.data || []);
        if (res.meta) this.meta.set(res.meta);
      },
      error: () => {
        this.rows.set([]);
        this.meta.set({ page: 1, per_page: this.perPage, total: 0, total_pages: 0 });
      }
    });
  }

  clear() {
    this.q = '';
    this.estado = '';
    this.page = 1;
    this.search();
  }

  goTo(p: number) {
    if (p < 1 || p > this.meta().total_pages) return;
    this.page = p;
    this.search();
  }

  // =========================
  // Form / CRUD
  // =========================
  openForm() {
    this.editingId.set(null);
    this.form = {
      nombre: '',
      rango_min: null,
      rango_max: null,
      umbral_clasificacion: null,
      activo: true,
      ediciones_ids: []
    };
    this.errorMsg.set('');
    this.successMsg.set('');
    this.formOpen.set(true);
  }

  closeForm() {
    this.formOpen.set(false);
  }

  edit(r: AreaRow) {
    this.editingId.set(r.id);
    this.form = {
      nombre: r.nombre,
      rango_min: r.rango_min,
      rango_max: r.rango_max,
      umbral_clasificacion: r.umbral_clasificacion,
      activo: r.activo,
      ediciones_ids: (r.ediciones || []).map(e => e.id),
    };
    this.errorMsg.set('');
    this.successMsg.set('');
    this.formOpen.set(true);
  }

  save() {
    if (!this.form.nombre.trim()) {
      this.errorMsg.set('El nombre del área es obligatorio.');
      return;
    }
    if (this.form.rango_min === null || this.form.rango_max === null) {
      this.errorMsg.set('El rango mínimo y máximo son obligatorios.');
      return;
    }
    if (this.form.umbral_clasificacion === null) {
      this.errorMsg.set('El umbral de clasificación es obligatorio.');
      return;
    }
    if (Number(this.form.rango_min) > Number(this.form.rango_max)) {
      this.errorMsg.set('El rango mínimo no puede ser mayor al máximo.');
      return;
    }
    if (
      Number(this.form.umbral_clasificacion) < Number(this.form.rango_min) ||
      Number(this.form.umbral_clasificacion) > Number(this.form.rango_max)
    ) {
      this.errorMsg.set('El umbral de clasificación debe estar dentro del rango.');
      return;
    }

    this.saving.set(true);
    this.errorMsg.set('');
    this.successMsg.set('');

    const payload = {
      nombre: this.form.nombre.trim(),
      rango_min: Number(this.form.rango_min),
      rango_max: Number(this.form.rango_max),
      umbral_clasificacion: Number(this.form.umbral_clasificacion),
      activo: !!this.form.activo,
      ediciones_ids: this.form.ediciones_ids,
    };

    const req$ = this.editingId() === null
      ? this.api.post<{ ok: boolean; message?: string; data?: AreaRow }>('/admin/areas', payload)
      : this.api.put<{ ok: boolean; message?: string; data?: AreaRow }>(`/admin/areas/${this.editingId()}`, payload);

    req$.subscribe({
      next: (res) => {
        if (res?.ok) {
          const msgBase = this.editingId() === null ? 'Área creada exitosamente.' : 'Área actualizada exitosamente.';
          this.successMsg.set(res.message || msgBase);
          this.search();
          setTimeout(() => this.closeForm(), 400);
        } else {
          this.errorMsg.set(res?.message || 'No se pudo guardar el área.');
        }
        this.saving.set(false);
      },
      error: (err) => {
        const msg = err?.error?.message || 'Error al guardar el área.';
        this.errorMsg.set(msg);
        this.saving.set(false);
      }
    });
  }

  remove(r: AreaRow) {
    if (!confirm(`¿Eliminar área "${r.nombre}"?`)) return;
    this.api.delete<{ ok: boolean; message?: string }>(`/admin/areas/${r.id}`).subscribe({
      next: (res) => {
        if (res?.ok) this.search();
      },
      error: () => {}
    });
  }
}
