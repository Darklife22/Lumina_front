// src/app/pages/admin/areas-crear.component.ts
import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';

type Edicion = { id: number; nombre: string; gestion?: string | null };

@Component({
  standalone: true,
  selector: 'app-areas-crear',
  imports: [CommonModule, FormsModule],
  template: `
  <section class="space-y-4 max-w-3xl mx-auto">
    <div class="flex items-center justify-between">
      <h2 class="text-xl font-bold">Crear Nueva Área</h2>
      <button
        (click)="clearForm()"
        class="text-sm rounded-lg border px-3 py-2 hover:bg-slate-50">
        Limpiar
      </button>
    </div>

    <div class="bg-white rounded-2xl border p-4 space-y-3">
      <div>
        <label class="text-xs text-slate-500">Nombre del área *</label>
        <input
          [(ngModel)]="form.nombre"
          class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
      </div>

      <div class="grid md:grid-cols-3 gap-3">
        <div>
          <label class="text-xs text-slate-500">Rango mínimo *</label>
          <input
            type="number"
            step="0.01"
            [(ngModel)]="form.rango_min"
            class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
        </div>
        <div>
          <label class="text-xs text-slate-500">Rango máximo *</label>
          <input
            type="number"
            step="0.01"
            [(ngModel)]="form.rango_max"
            class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
        </div>
        <div>
          <label class="text-xs text-slate-500">Umbral de clasificación *</label>
          <input
            type="number"
            step="0.01"
            [(ngModel)]="form.umbral_clasificacion"
            class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
        </div>
      </div>

      <div>
        <label class="text-xs text-slate-500">Asociar a ediciones</label>
        <div class="flex items-center gap-2 mb-2 mt-1">
          <input
            [(ngModel)]="edFilter"
            placeholder="Filtrar ediciones..."
            class="flex-1 rounded-lg border border-slate-300 px-2 py-1 text-sm">
          <button
            (click)="toggleAllEdiciones(true)"
            type="button"
            class="text-xs rounded-md border px-2 py-1 hover:bg-slate-50">
            Todas
          </button>
          <button
            (click)="toggleAllEdiciones(false)"
            type="button"
            class="text-xs rounded-md border px-2 py-1 hover:bg-slate-50">
            Ninguna
          </button>
        </div>

        <div class="grid md:grid-cols-2 gap-2 max-h-56 overflow-auto pr-1">
          <label
            *ngFor="let e of filteredEdiciones()"
            class="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              [checked]="form.ediciones_ids.includes(e.id)"
              (change)="toggleEdicion(e.id, $event)">
            {{ e.nombre }}
            <span class="text-slate-400" *ngIf="e.gestion">({{ e.gestion }})</span>
          </label>
        </div>
      </div>

      <div
        *ngIf="error()"
        class="rounded-xl border border-red-200 bg-red-50 text-red-700 px-3 py-2 text-sm">
        {{ error() }}
      </div>
      <div
        *ngIf="success()"
        class="rounded-xl border border-emerald-200 bg-emerald-50 text-emerald-700 px-3 py-2 text-sm">
        {{ success() }}
      </div>

      <div class="flex items-center justify-end gap-2 pt-2">
        <button
          (click)="save()"
          [disabled]="saving()"
          class="rounded-lg bg-[#0f3f94] hover:bg-[#0d3580] text-white px-4 py-2 text-sm">
          <ng-container *ngIf="!saving(); else sp">
            <i class="bi bi-plus-lg"></i> Crear Área
          </ng-container>
          <ng-template #sp>
            <span class="inline-flex items-center gap-2">
              <span class="inline-block h-4 w-4 border-2 border-white/60 border-t-white rounded-full animate-spin"></span>
              Guardando...
            </span>
          </ng-template>
        </button>
      </div>
    </div>
  </section>
  `
})
export class AreasCrearComponent {
  private api = inject(ApiService);

  ediciones = signal<Edicion[]>([]);
  edFilter = '';

  form = {
    nombre: '',
    rango_min: 0,
    rango_max: 100,
    umbral_clasificacion: 60,
    ediciones_ids: [] as number[],
  };

  saving = signal(false);
  error = signal('');
  success = signal('');

  ngOnInit() {
    this.api.get<{ ok?: boolean; data: any[] }>('/admin/ediciones').subscribe({
      next: (res) => {
        const data = res?.data || [];
        this.ediciones.set(
          data.map((e: any) => ({
            id: e.id,
            nombre: e.nombre_oficial ?? e.nombre ?? `${e.anio ?? ''} - ${e.slug ?? ''}`,
            gestion: e.gestion ?? null
          }))
        );
      },
      error: () => this.ediciones.set([]),
    });
  }

  filteredEdiciones() {
    const f = this.edFilter.trim().toLowerCase();
    if (!f) return this.ediciones();
    return this.ediciones().filter(e =>
      (e.nombre + ' ' + (e.gestion ?? '')).toLowerCase().includes(f)
    );
  }

  toggleAllEdiciones(mark: boolean) {
    if (mark) {
      this.form.ediciones_ids = this.filteredEdiciones().map(e => e.id);
    } else {
      const remove = new Set(this.filteredEdiciones().map(e => e.id));
      this.form.ediciones_ids = this.form.ediciones_ids.filter(id => !remove.has(id));
    }
  }

  toggleEdicion(id: number, ev: Event) {
    const checked = (ev.target as HTMLInputElement).checked;
    if (checked && !this.form.ediciones_ids.includes(id)) {
      this.form.ediciones_ids.push(id);
    } else if (!checked) {
      this.form.ediciones_ids = this.form.ediciones_ids.filter(x => x !== id);
    }
  }

  clearForm() {
    this.form = {
      nombre: '',
      rango_min: 0,
      rango_max: 100,
      umbral_clasificacion: 60,
      ediciones_ids: [],
    };
    this.error.set('');
    this.success.set('');
  }

  save() {
    // Validaciones alineadas con HU-43
    if (!this.form.nombre.trim()) {
      this.error.set('El nombre del área es obligatorio.');
      return;
    }
    if (this.form.rango_min > this.form.rango_max) {
      this.error.set('Rango inválido: el mínimo no puede ser mayor al máximo.');
      return;
    }
    if (
      this.form.umbral_clasificacion < this.form.rango_min ||
      this.form.umbral_clasificacion > this.form.rango_max
    ) {
      this.error.set('El umbral de clasificación debe estar dentro del rango.');
      return;
    }

    this.saving.set(true);
    this.error.set('');
    this.success.set('');

    const payload = {
      nombre: this.form.nombre.trim(),
      rango_min: Number(this.form.rango_min),
      rango_max: Number(this.form.rango_max),
      umbral_clasificacion: Number(this.form.umbral_clasificacion),
      activo: true,
      ediciones_ids: this.form.ediciones_ids,
    };

    this.api.post<{ ok: boolean; message?: string; data?: any }>('/admin/areas', payload).subscribe({
      next: (res) => {
        if (res?.ok) {
          this.success.set(res.message || `Área "${this.form.nombre}" creada exitosamente.`);
          this.error.set('');
          // si quieres reset completo:
          // this.clearForm();
        } else {
          this.error.set(res?.message || 'No se pudo crear el área.');
        }
        this.saving.set(false);
      },
      error: (err) => {
        const msg = err?.error?.message || 'Error al crear el área.';
        this.error.set(msg);
        this.saving.set(false);
      }
    });
  }
}
