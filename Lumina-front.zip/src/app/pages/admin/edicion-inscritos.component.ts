import { CommonModule } from '@angular/common';
import { Component, inject, signal, computed } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { ApiService } from '../../core/api.service';

type EstadoEdicion = 'borrador' | 'activa' | 'cerrada';

type Edicion = {
  id: number;
  nombre_oficial: string;
  estado: EstadoEdicion;
  fecha_inicio: string;
  fecha_fin: string;
};

type Inscrito = {
  id: number;
  ci?: string | null;
  nombres?: string | null;
  apellidos?: string | null;
  colegio?: string | null;
  area?: string | null;
  nivel?: string | null;
  estado?: string | null;
  created_at?: string | null;
};

type InscritosResponse = {
  items: Inscrito[];
  total: number;
};

const ENDPOINTS = {
  edicion: (id: number) => `/admin/ediciones/${id}`,
  inscritos: (id: number) => `/admin/ediciones/${id}/inscritos`, // GET ?q=&page=&page_size=
};

@Component({
  standalone: true,
  selector: 'app-edicion-inscritos',
  imports: [CommonModule, FormsModule, RouterModule],
  template: `
  <section class="space-y-4">

    <div class="bg-white border border-slate-200 rounded-2xl p-4 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3">
      <div class="min-w-0">
        <a class="text-xs text-slate-500 hover:text-slate-700 inline-flex items-center gap-1"
           [routerLink]="['/admin/ediciones', edicionId(), 'configuracion']">
          <i class="bi bi-arrow-left"></i> Volver a configuración
        </a>

        <h1 class="text-lg md:text-xl font-bold tracking-tight mt-1 truncate">
          Inscritos
        </h1>

        <div class="text-sm text-slate-500">
          {{ edicion()?.nombre_oficial || '—' }}
          <span class="text-slate-300">·</span>
          {{ edicion()?.fecha_inicio }} – {{ edicion()?.fecha_fin }}
        </div>
      </div>

      <div class="flex items-center gap-2">
        <button class="rounded-lg bg-white border border-slate-200 px-4 py-2 text-sm hover:bg-slate-50"
                (click)="reload()" [disabled]="loading()">
          <i class="bi bi-arrow-repeat"></i> Actualizar
        </button>
      </div>
    </div>

    <div *ngIf="error()" class="rounded-2xl border border-red-200 bg-red-50 p-4 text-red-700 text-sm">
      {{ error() }}
    </div>

    <div class="bg-white border border-slate-200 rounded-2xl p-4">
      <div class="grid md:grid-cols-12 gap-3 items-end">
        <div class="md:col-span-6">
          <label class="text-xs text-slate-500">Buscar</label>
          <input [(ngModel)]="q"
                 (keyup.enter)="apply()"
                 placeholder="CI, nombre, colegio, área, nivel..."
                 class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-200 focus:border-blue-300">
        </div>

        <div class="md:col-span-3">
          <label class="text-xs text-slate-500">Tamaño de página</label>
          <select [(ngModel)]="pageSize" (ngModelChange)="apply()"
                  class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
            <option [ngValue]="10">10</option>
            <option [ngValue]="20">20</option>
            <option [ngValue]="50">50</option>
          </select>
        </div>

        <div class="md:col-span-3 flex gap-2">
          <button (click)="apply()"
                  class="w-full rounded-lg bg-[#0f3f94] hover:bg-[#0d3580] text-white px-3 py-2 text-sm">
            <i class="bi bi-search"></i> Filtrar
          </button>
          <button (click)="clear()"
                  class="w-full rounded-lg bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50">
            Limpiar
          </button>
        </div>
      </div>
    </div>

    <div class="bg-white border border-slate-200 rounded-2xl overflow-hidden">
      <div class="p-4 border-b border-slate-200 flex items-center justify-between">
        <div class="font-semibold text-sm">Listado</div>
        <div class="text-xs text-slate-500">
          Total: {{ total() }} · Página {{ page() }} / {{ totalPages() }}
        </div>
      </div>

      <div *ngIf="loading()" class="py-10 text-center text-slate-400 text-sm">
        Cargando inscritos...
      </div>

      <div *ngIf="!loading() && items().length===0" class="py-10 text-center text-slate-400 text-sm">
        Sin resultados.
      </div>

      <div *ngIf="!loading() && items().length>0" class="overflow-x-auto">
        <table class="min-w-full text-sm">
          <thead class="bg-slate-50 text-slate-600">
            <tr class="text-left">
              <th class="py-2 px-3">CI</th>
              <th class="py-2 px-3">Participante</th>
              <th class="py-2 px-3">Colegio</th>
              <th class="py-2 px-3">Área</th>
              <th class="py-2 px-3">Nivel</th>
              <th class="py-2 px-3">Estado</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let it of items()" class="border-t border-slate-100">
              <td class="py-2 px-3 text-xs">{{ it.ci || '—' }}</td>
              <td class="py-2 px-3">
                <div class="font-semibold text-slate-800">
                  {{ (it.nombres || '') + ' ' + (it.apellidos || '') }}
                </div>
                <div class="text-[11px] text-slate-500">ID {{ it.id }}</div>
              </td>
              <td class="py-2 px-3 text-xs text-slate-700">{{ it.colegio || '—' }}</td>
              <td class="py-2 px-3 text-xs text-slate-700">{{ it.area || '—' }}</td>
              <td class="py-2 px-3 text-xs text-slate-700">{{ it.nivel || '—' }}</td>
              <td class="py-2 px-3 text-xs">
                <span class="px-2 py-0.5 rounded-full border text-xs"
                      [ngClass]="badge(it.estado)">
                  {{ it.estado || '—' }}
                </span>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div class="p-4 border-t border-slate-200 flex items-center justify-between">
        <button class="rounded-lg bg-white border border-slate-200 px-4 py-2 text-sm hover:bg-slate-50"
                (click)="prev()" [disabled]="page()<=1 || loading()">
          <i class="bi bi-chevron-left"></i> Anterior
        </button>

        <button class="rounded-lg bg-white border border-slate-200 px-4 py-2 text-sm hover:bg-slate-50"
                (click)="next()" [disabled]="page()>=totalPages() || loading()">
          Siguiente <i class="bi bi-chevron-right"></i>
        </button>
      </div>
    </div>

  </section>
  `,
})
export class EdicionInscritosComponent {
  private api = inject(ApiService);
  private route = inject(ActivatedRoute);

  edicionId = signal<number | null>(null);
  edicion = signal<Edicion | null>(null);

  loading = signal(false);
  error = signal<string | null>(null);

  q = '';
  page = signal(1);
  pageSize = 20;

  items = signal<Inscrito[]>([]);
  total = signal(0);

  totalPages = computed(() => {
    const t = this.total();
    const s = this.pageSize || 20;
    return Math.max(1, Math.ceil(t / s));
  });

  ngOnInit() {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    if (!id || Number.isNaN(id)) {
      this.error.set('ID de edición inválido.');
      return;
    }
    this.edicionId.set(id);
    this.reload();
  }

  reload() {
    const id = this.edicionId();
    if (!id) return;

    this.loading.set(true);
    this.error.set(null);

    this.api.get<{ ok: boolean; data: Edicion }>(ENDPOINTS.edicion(id)).subscribe({
      next: (r) => {
        if (!r?.ok) {
          this.edicion.set(null);
          this.error.set('No se pudo cargar la competencia.');
          this.loading.set(false);
          return;
        }
        this.edicion.set(r.data);
        this.fetch();
      },
      error: () => {
        this.loading.set(false);
        this.error.set('No se pudo cargar la competencia.');
      }
    });
  }

  apply() {
    this.page.set(1);
    this.fetch();
  }

  clear() {
    this.q = '';
    this.page.set(1);
    this.fetch();
  }

  prev() {
    this.page.set(Math.max(1, this.page() - 1));
    this.fetch();
  }

  next() {
    this.page.set(Math.min(this.totalPages(), this.page() + 1));
    this.fetch();
  }

  fetch() {
    const id = this.edicionId();
    if (!id) return;

    this.loading.set(true);
    this.error.set(null);

    const url = `${ENDPOINTS.inscritos(id)}?q=${encodeURIComponent(this.q || '')}&page=${this.page()}&page_size=${this.pageSize}`;

    this.api.get<{ ok: boolean; data: InscritosResponse }>(url).subscribe({
      next: (r) => {
        this.loading.set(false);
        if (!r?.ok) {
          this.items.set([]);
          this.total.set(0);
          this.error.set('No se pudo cargar inscritos.');
          return;
        }
        this.items.set(r.data?.items || []);
        this.total.set(r.data?.total || 0);
      },
      error: () => {
        this.loading.set(false);
        this.items.set([]);
        this.total.set(0);
        this.error.set('No se pudo cargar inscritos.');
      }
    });
  }

  badge(estado?: string | null) {
    const e = String(estado || '').toLowerCase();
    if (e.includes('aprob') || e.includes('activo')) return 'bg-emerald-50 text-emerald-700 border-emerald-100';
    if (e.includes('rech') || e.includes('baja')) return 'bg-red-50 text-red-700 border-red-100';
    return 'bg-slate-50 text-slate-700 border-slate-200';
  }
}
