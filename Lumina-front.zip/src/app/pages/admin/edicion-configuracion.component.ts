// src/app/pages/admin/ediciones-configuracion.component.ts
import { CommonModule } from '@angular/common';
import { Component, inject, signal, computed } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { ApiService } from '../../core/api.service';

/* ===================== TIPOS ===================== */

type EstadoEdicion = 'borrador' | 'activa' | 'cerrada';

type EtapaKey = 'fase1' | 'clasificados' | 'final' | 'medalleria';

type Etapa = {
  key: EtapaKey;
  nombre: string;
  orden: number;
  inicio?: string | null;
  fin?: string | null;
  habilitada: boolean;
};

type ReglaClasificacion = {
  tipo: 'umbral' | 'top_n' | 'mixta';
  umbral_min?: number | null;
  top_n?: number | null;
  nota_min_aprob?: number | null;
};

type Area = { id: number; nombre: string; codigo?: string | null };
type Nivel = { id: number; nombre: string; codigo?: string | null };

type ConfigEdicion = {
  area_ids: number[];

  /**
   * 🔑 NUEVO: niveles por área
   * key: areaId
   * value: [nivelId, nivelId, ...]
   */
  area_niveles: Record<number, number[]>;

  etapas: Etapa[];
  reglas_base: ReglaClasificacion;

  locks?: {
    estructura?: boolean;
    tiempos?: boolean;
    reglas?: boolean;
    etapas?: boolean;
  };

  deps?: {
    inscritos?: number;
    evaluaciones?: number;
    resultados?: number;
  };
};

type Edicion = {
  id: number;
  anio: number;
  nombre_oficial: string;
  fecha_inicio: string;
  fecha_fin: string;
  estado: EstadoEdicion;
};

type ApiOk<T> = { ok: true; data: T };
type ApiErr = { ok: false; message?: string; error?: any; errors?: any };

/**
 * Tu backend puede devolver distintas formas en show():
 * - { edicion, areas, niveles, stats, locked }
 * - o { ...edicionProps }
 * Este tipo intenta cubrir ambos sin romper.
 */
type ShowResponse =
  | ApiOk<Edicion>
  | ApiOk<{
      edicion: Edicion;
      areas?: Area[];
      niveles?: Nivel[];
      stats?: any;
      locked?: boolean;
    }>
  | ApiErr;

/* ===================== ENDPOINTS ===================== */

const ENDPOINTS = {
  edicion: (id: number) => `/admin/ediciones/${id}`,
  config: (id: number) => `/admin/ediciones/${id}/configuracion`,
  areasCatalogo: `/admin/areas`,
  nivelesCatalogo: `/admin/niveles`, // si no existe, hay fallback en loadCatalogos()
};

function cloneDeep<T>(obj: T): T {
  return JSON.parse(JSON.stringify(obj));
}

function stableStringify(obj: any): string {
  // stringify estable para dirty-check (orden consistente de keys)
  const allKeys: string[] = [];
  JSON.stringify(obj, (key, value) => {
    allKeys.push(key);
    return value;
  });
  allKeys.sort();
  return JSON.stringify(obj, allKeys);
}

@Component({
  standalone: true,
  selector: 'app-edicion-configuracion',
  imports: [CommonModule, FormsModule, RouterModule],
  template: `
  <section class="space-y-4">

    <!-- Top Bar -->
    <div class="bg-white border border-slate-200 rounded-2xl p-4 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3">
      <div class="min-w-0">
        <div class="flex items-center gap-2 flex-wrap">
          <a
            class="text-xs text-slate-500 hover:text-slate-700 inline-flex items-center gap-1"
            [routerLink]="['/admin/ediciones']">
            <i class="bi bi-arrow-left"></i> Volver
          </a>

          <span class="text-xs text-slate-300">/</span>

          <span class="text-xs text-slate-500">Competencia</span>
          <span class="text-xs text-slate-300">#{{ edicionId() ?? '—' }}</span>
        </div>

        <h1 class="text-lg md:text-xl font-bold tracking-tight mt-1 truncate">
          {{ edicion()?.nombre_oficial || 'Configuración de competencia' }}
        </h1>

        <div class="flex items-center gap-2 mt-1 flex-wrap">
          <span class="text-xs text-slate-500">
            {{ edicion()?.fecha_inicio }} – {{ edicion()?.fecha_fin }}
          </span>

          <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border"
                [ngClass]="estadoBadgeClass(edicion()?.estado)">
            <span class="w-1.5 h-1.5 rounded-full mr-1.5"
                  [ngClass]="estadoDotClass(edicion()?.estado)"></span>
            {{ labelEstado(edicion()?.estado) }}
          </span>

          <span *ngIf="config()?.deps" class="text-[11px] text-slate-500">
            Dependencias:
            <strong>{{ config()?.deps?.inscritos ?? 0 }}</strong> inscritos ·
            <strong>{{ config()?.deps?.evaluaciones ?? 0 }}</strong> evaluaciones ·
            <strong>{{ config()?.deps?.resultados ?? 0 }}</strong> resultados
          </span>
        </div>
      </div>

      <div class="flex items-center gap-2">
        <button
          class="rounded-lg bg-white border border-slate-200 px-4 py-2 text-sm hover:bg-slate-50"
          (click)="reload()"
          [disabled]="loading()">
          <i class="bi bi-arrow-repeat"></i> Actualizar
        </button>

        <button
          class="rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 text-sm font-semibold"
          (click)="guardar()"
          [disabled]="loading() || !dirty() || !canEditAny()">
          <span *ngIf="!saving(); else savingTpl">
            <i class="bi bi-check2-circle"></i> Guardar cambios
          </span>
        </button>

        <ng-template #savingTpl>
          <span class="inline-flex items-center gap-2">
            <span class="inline-block h-4 w-4 border-2 border-white/60 border-t-white rounded-full animate-spin"></span>
            Guardando...
          </span>
        </ng-template>
      </div>
    </div>

    <!-- Alerts -->
    <div *ngIf="error()" class="rounded-2xl border border-red-200 bg-red-50 p-4 text-red-700 text-sm">
      {{ error() }}
      <div class="text-[11px] text-red-600 mt-1" *ngIf="debugDetails()">
        {{ debugDetails() }}
      </div>
    </div>

    <div *ngIf="warning()" class="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-amber-800 text-sm">
      {{ warning() }}
    </div>

    <!-- Tabs -->
    <div class="bg-white border border-slate-200 rounded-2xl overflow-hidden">
      <div class="px-4 pt-4">
        <div class="flex flex-wrap gap-2">
          <button class="tab" [ngClass]="tab()==='estructura' ? 'tab-active' : 'tab-idle'" (click)="tab.set('estructura')">
            <i class="bi bi-diagram-3"></i> Estructura
          </button>
          <button class="tab" [ngClass]="tab()==='etapas' ? 'tab-active' : 'tab-idle'" (click)="tab.set('etapas')">
            <i class="bi bi-flag"></i> Etapas
          </button>
          <button class="tab" [ngClass]="tab()==='reglas' ? 'tab-active' : 'tab-idle'" (click)="tab.set('reglas')">
            <i class="bi bi-sliders"></i> Reglas base
          </button>
          <button class="tab" [ngClass]="tab()==='gobernanza' ? 'tab-active' : 'tab-idle'" (click)="tab.set('gobernanza')">
            <i class="bi bi-shield-lock"></i> Gobernanza
          </button>
        </div>
      </div>

      <div class="p-4 border-t border-slate-200">
        <!-- LOADING -->
        <div *ngIf="loading()" class="py-10 text-center text-slate-400 text-sm">
          Cargando configuración...
        </div>

        <!-- CONTENT -->
        <ng-container *ngIf="!loading() && config()">

          <!-- TAB: ESTRUCTURA -->
          <div *ngIf="tab()==='estructura'" class="space-y-4">
            <div class="flex items-start justify-between gap-3">
              <div>
                <div class="text-sm font-semibold">Áreas y niveles asociados</div>
                <div class="text-xs text-slate-500">
                  Ahora: cada <strong>área</strong> tiene sus <strong>niveles</strong> propios (configuración granular).
                </div>
              </div>

              <span class="inline-flex items-center px-2 py-1 rounded-full text-xs border"
                    [ngClass]="isLocked('estructura') ? 'bg-slate-50 text-slate-600 border-slate-200' : 'bg-emerald-50 text-emerald-700 border-emerald-200'">
                <i class="bi" [ngClass]="isLocked('estructura') ? 'bi-lock-fill' : 'bi-unlock'"></i>
                <span class="ml-1">{{ isLocked('estructura') ? 'Bloqueado' : 'Editable' }}</span>
              </span>
            </div>

            <div class="grid lg:grid-cols-2 gap-4">
              <!-- Áreas -->
              <div class="rounded-2xl border border-slate-200 p-4">
                <div class="flex items-center justify-between">
                  <div class="font-semibold text-sm">Áreas</div>
                  <div class="text-xs text-slate-500">{{ selectedAreas().length }} seleccionadas</div>
                </div>

                <div class="mt-3">
                  <input
                    [(ngModel)]="areaSearch"
                    placeholder="Buscar área..."
                    class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-200 focus:border-blue-300"
                    [disabled]="isLocked('estructura') || !canEditByEstado()">
                </div>

                <div class="mt-3 max-h-72 overflow-y-auto space-y-2">
                  <div *ngFor="let a of filteredAreas()"
                      class="flex items-center justify-between gap-3 rounded-xl border px-3 py-2"
                      [ngClass]="selectedAreaId()===a.id ? 'border-blue-200 bg-blue-50/40' : 'border-slate-200 bg-white'">

                    <button
                      type="button"
                      class="min-w-0 text-left flex-1"
                      (click)="selectArea(a.id)"
                      [disabled]="!isAreaSelected(a.id)">
                      <div class="text-sm font-medium text-slate-800 truncate">{{ a.nombre }}</div>
                      <div class="text-[11px] text-slate-500">
                        ID {{ a.id }}
                        <span *ngIf="a.codigo">· {{ a.codigo }}</span>
                        <span *ngIf="isAreaSelected(a.id)" class="ml-2 text-[11px] text-slate-500">
                          · Niveles: <strong>{{ countNivelesArea(a.id) }}</strong>
                        </span>
                      </div>
                    </button>

                    <div class="flex items-center gap-2">
                      <button
                        type="button"
                        class="rounded-lg border border-slate-200 px-2 py-1 text-xs hover:bg-slate-50"
                        (click)="selectArea(a.id)"
                        [disabled]="!isAreaSelected(a.id)">
                        Configurar
                      </button>

                      <label class="text-xs inline-flex items-center gap-2">
                        <input
                          type="checkbox"
                          [checked]="isAreaSelected(a.id)"
                          (change)="toggleArea(a.id)"
                          [disabled]="isLocked('estructura') || !canEditByEstado()">
                        Seleccionar
                      </label>
                    </div>
                  </div>

                  <div *ngIf="areas().length===0" class="text-xs text-slate-400 py-6 text-center">
                    No hay catálogo de áreas disponible.
                  </div>
                </div>

                <div *ngIf="isLocked('estructura')" class="mt-3 text-xs text-slate-500">
                  Estructura bloqueada por dependencias. Esto evita pérdida de datos.
                </div>
              </div>

              <!-- Niveles por Área -->
              <div class="rounded-2xl border border-slate-200 p-4">
                <div class="flex items-center justify-between">
                  <div class="font-semibold text-sm">Niveles por área</div>
                  <div class="text-xs text-slate-500">
                    <ng-container *ngIf="selectedAreaObj(); else pickAreaTpl">
                      Área: <strong>{{ selectedAreaObj()?.nombre }}</strong>
                    </ng-container>
                    <ng-template #pickAreaTpl>
                      Selecciona un área para asignar niveles
                    </ng-template>
                  </div>
                </div>

                <div class="mt-3">
                  <input
                    [(ngModel)]="nivelSearch"
                    placeholder="Buscar nivel..."
                    class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-200 focus:border-blue-300"
                    [disabled]="isLocked('estructura') || !canEditByEstado() || !selectedAreaId()">
                </div>

                <div class="mt-3 max-h-72 overflow-y-auto space-y-2">
                  <div *ngIf="!selectedAreaId()" class="text-xs text-slate-400 py-10 text-center">
                    Haz click en “Configurar” o en el nombre de un área seleccionada.
                  </div>

                  <div *ngIf="selectedAreaId()">
                    <div *ngFor="let n of filteredNiveles()"
                        class="flex items-center justify-between gap-3 rounded-xl border border-slate-200 px-3 py-2">
                      <div class="min-w-0">
                        <div class="text-sm font-medium text-slate-800 truncate">{{ n.nombre }}</div>
                        <div class="text-[11px] text-slate-500">
                          ID {{ n.id }} <span *ngIf="n.codigo">· {{ n.codigo }}</span>
                        </div>
                      </div>

                      <label class="text-xs inline-flex items-center gap-2">
                        <input
                          type="checkbox"
                          [checked]="isNivelSelectedForSelectedArea(n.id)"
                          (change)="toggleNivelForSelectedArea(n.id)"
                          [disabled]="isLocked('estructura') || !canEditByEstado()">
                        Asignar
                      </label>
                    </div>

                    <div *ngIf="niveles().length===0" class="text-xs text-slate-400 py-6 text-center">
                      No hay catálogo de niveles disponible.
                    </div>
                  </div>
                </div>

                <div *ngIf="selectedAreaId() && isLocked('estructura')" class="mt-3 text-xs text-slate-500">
                  Estructura bloqueada por dependencias. Para cambios, la práctica recomendada es crear una nueva edición.
                </div>
              </div>
            </div>
          </div>

          <!-- TAB: ETAPAS -->
          <div *ngIf="tab()==='etapas'" class="space-y-4">
            <div class="flex items-start justify-between gap-3">
              <div>
                <div class="text-sm font-semibold">Etapas competitivas</div>
                <div class="text-xs text-slate-500">
                  Define el journey oficial. Las fechas se bloquean si ya existen evaluaciones/resultados.
                </div>
              </div>

              <span class="inline-flex items-center px-2 py-1 rounded-full text-xs border"
                    [ngClass]="isLocked('etapas') ? 'bg-slate-50 text-slate-600 border-slate-200' : 'bg-emerald-50 text-emerald-700 border-emerald-200'">
                <i class="bi" [ngClass]="isLocked('etapas') ? 'bi-lock-fill' : 'bi-unlock'"></i>
                <span class="ml-1">{{ isLocked('etapas') ? 'Bloqueado' : 'Editable' }}</span>
              </span>
            </div>

            <div class="grid md:grid-cols-2 gap-3">
              <div *ngFor="let et of config()!.etapas" class="rounded-2xl border border-slate-200 p-4">
                <div class="flex items-start justify-between gap-3">
                  <div>
                    <div class="text-sm font-semibold text-slate-900">{{ et.nombre }}</div>
                    <div class="text-[11px] text-slate-500">Key: {{ et.key }} · Orden: {{ et.orden }}</div>
                  </div>

                  <label class="text-xs inline-flex items-center gap-2">
                    <input
                      type="checkbox"
                      [(ngModel)]="et.habilitada"
                      (ngModelChange)="onMutate()"
                      [disabled]="isLocked('etapas') || !canEditByEstado()">
                    Habilitada
                  </label>
                </div>

                <div class="grid grid-cols-2 gap-2 mt-3">
                  <div>
                    <label class="text-[11px] text-slate-500">Inicio</label>
                    <input
                      type="date"
                      [(ngModel)]="et.inicio"
                      (ngModelChange)="onMutate()"
                      class="w-full rounded-lg border border-slate-300 px-2 py-2 text-sm"
                      [disabled]="isLocked('tiempos') || !canEditByEstado()">
                  </div>
                  <div>
                    <label class="text-[11px] text-slate-500">Fin</label>
                    <input
                      type="date"
                      [(ngModel)]="et.fin"
                      (ngModelChange)="onMutate()"
                      class="w-full rounded-lg border border-slate-300 px-2 py-2 text-sm"
                      [disabled]="isLocked('tiempos') || !canEditByEstado()">
                  </div>
                </div>

                <div *ngIf="isLocked('tiempos')" class="mt-2 text-[11px] text-slate-500">
                  Fechas bloqueadas por dependencias operativas.
                </div>
              </div>
            </div>
          </div>

          <!-- TAB: REGLAS -->
          <div *ngIf="tab()==='reglas'" class="space-y-4">
            <div class="flex items-start justify-between gap-3">
              <div>
                <div class="text-sm font-semibold">Reglas base de clasificación</div>
                <div class="text-xs text-slate-500">
                  Regla default. La parametrización real es por área + nivel + etapa (módulo dedicado).
                </div>
              </div>

              <span class="inline-flex items-center px-2 py-1 rounded-full text-xs border"
                    [ngClass]="isLocked('reglas') ? 'bg-slate-50 text-slate-600 border-slate-200' : 'bg-emerald-50 text-emerald-700 border-emerald-200'">
                <i class="bi" [ngClass]="isLocked('reglas') ? 'bi-lock-fill' : 'bi-unlock'"></i>
                <span class="ml-1">{{ isLocked('reglas') ? 'Bloqueado' : 'Editable' }}</span>
              </span>
            </div>

            <div class="rounded-2xl border border-slate-200 p-4">
              <div class="grid md:grid-cols-4 gap-3">
                <div class="md:col-span-2">
                  <label class="text-xs text-slate-500">Tipo</label>
                  <select
                    [(ngModel)]="config()!.reglas_base.tipo"
                    (ngModelChange)="onMutate()"
                    class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                    [disabled]="isLocked('reglas') || !canEditByEstado()">
                    <option [ngValue]="'umbral'">Umbral</option>
                    <option [ngValue]="'top_n'">Top N</option>
                    <option [ngValue]="'mixta'">Mixta</option>
                  </select>
                </div>

                <div>
                  <label class="text-xs text-slate-500">Umbral mínimo</label>
                  <input
                    type="number"
                    [(ngModel)]="config()!.reglas_base.umbral_min"
                    (ngModelChange)="onMutate()"
                    class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                    [disabled]="isLocked('reglas') || !canEditByEstado()">
                </div>

                <div>
                  <label class="text-xs text-slate-500">Top N</label>
                  <input
                    type="number"
                    [(ngModel)]="config()!.reglas_base.top_n"
                    (ngModelChange)="onMutate()"
                    class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                    [disabled]="isLocked('reglas') || !canEditByEstado()">
                </div>

                <div class="md:col-span-2">
                  <label class="text-xs text-slate-500">Nota mínima de aprobación</label>
                  <input
                    type="number"
                    [(ngModel)]="config()!.reglas_base.nota_min_aprob"
                    (ngModelChange)="onMutate()"
                    class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                    [disabled]="isLocked('reglas') || !canEditByEstado()">
                </div>
              </div>

              <div *ngIf="isLocked('reglas')" class="mt-3 text-xs text-slate-500">
                Reglas bloqueadas por dependencias operativas. Recomendación: manejar cambios como “versionado” sin romper histórico.
              </div>
            </div>
          </div>

          <!-- TAB: GOBERNANZA -->
          <div *ngIf="tab()==='gobernanza'" class="space-y-4">
            <div class="rounded-2xl border border-slate-200 p-4">
              <div class="text-sm font-semibold">Política de edición</div>
              <div class="text-xs text-slate-500 mt-1">
                La edición tiene “zonas críticas” (estructura, tiempos, reglas, etapas). El backend es la fuente de verdad.
              </div>

              <div class="grid md:grid-cols-2 gap-3 mt-4">
                <div class="rounded-2xl border border-slate-200 p-4">
                  <div class="font-semibold text-sm">Estado y editabilidad</div>
                  <div class="text-xs text-slate-500 mt-1">
                    Por estándar, solo <strong>borrador</strong> permite cambios estructurales.
                    “Activa” y “Cerrada” operan en modo operación/archivo.
                  </div>

                  <div class="mt-3 text-xs">
                    <span class="px-2 py-1 rounded-full border"
                          [ngClass]="canEditByEstado() ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-slate-50 text-slate-600 border-slate-200'">
                      {{ canEditByEstado() ? 'Editable por estado' : 'No editable por estado' }}
                    </span>
                  </div>
                </div>

                <div class="rounded-2xl border border-slate-200 p-4">
                  <div class="font-semibold text-sm">Locks efectivos</div>
                  <div class="text-xs text-slate-500 mt-1">
                    Locks por integridad y dependencias.
                  </div>

                  <div class="mt-3 space-y-2 text-xs text-slate-700">
                    <div class="flex items-center justify-between">
                      <span>Estructura</span>
                      <span [ngClass]="isLocked('estructura') ? 'text-slate-600' : 'text-emerald-700'">
                        {{ isLocked('estructura') ? 'Bloqueado' : 'Editable' }}
                      </span>
                    </div>
                    <div class="flex items-center justify-between">
                      <span>Tiempos</span>
                      <span [ngClass]="isLocked('tiempos') ? 'text-slate-600' : 'text-emerald-700'">
                        {{ isLocked('tiempos') ? 'Bloqueado' : 'Editable' }}
                      </span>
                    </div>
                    <div class="flex items-center justify-between">
                      <span>Etapas</span>
                      <span [ngClass]="isLocked('etapas') ? 'text-slate-600' : 'text-emerald-700'">
                        {{ isLocked('etapas') ? 'Bloqueado' : 'Editable' }}
                      </span>
                    </div>
                    <div class="flex items-center justify-between">
                      <span>Reglas</span>
                      <span [ngClass]="isLocked('reglas') ? 'text-slate-600' : 'text-emerald-700'">
                        {{ isLocked('reglas') ? 'Bloqueado' : 'Editable' }}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div class="mt-4 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-amber-800 text-sm">
                Si necesitas cambios críticos con dependencias, la ruta enterprise es:
                <strong>nueva edición</strong> o <strong>migración controlada</strong> (feature administrado).
              </div>
            </div>
          </div>

        </ng-container>
      </div>
    </div>

  </section>
  `,
  styles: [`
    .tab { @apply inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs border; }
    .tab-idle { @apply bg-white border-slate-200 text-slate-600 hover:bg-slate-50; }
    .tab-active { @apply bg-blue-50 border-blue-200 text-blue-700; }
  `],
})
export class EdicionConfiguracionComponent {
  private api = inject(ApiService);
  private route = inject(ActivatedRoute);

  edicionId = signal<number | null>(null);

  loading = signal(false);
  saving = signal(false);
  error = signal<string | null>(null);
  warning = signal<string | null>(null);
  debugDetails = signal<string | null>(null);

  edicion = signal<Edicion | null>(null);
  config = signal<ConfigEdicion | null>(null);

  areas = signal<Area[]>([]);
  niveles = signal<Nivel[]>([]);

  areaSearch = '';
  nivelSearch = '';

  tab = signal<'estructura' | 'etapas' | 'reglas' | 'gobernanza'>('estructura');

  // Área actualmente configurada (para asignar niveles)
  selectedAreaId = signal<number | null>(null);

  private baselineHash = signal<string>(''); // para dirty-check robusto
  dirty = computed(() => {
    const cfg = this.config();
    if (!cfg) return false;
    return stableStringify(cfg) !== this.baselineHash();
  });

  selectedAreas = computed(() => (this.config()?.area_ids ?? []));

  // unión (solo para métricas/UI si la necesitas)
  selectedNivelesUnion = computed(() => {
    const cfg = this.config();
    if (!cfg) return [];
    const all = new Set<number>();
    Object.values(cfg.area_niveles || {}).forEach(arr => (arr || []).forEach(id => all.add(id)));
    return Array.from(all);
  });

  filteredAreas = computed(() => {
    const q = this.areaSearch.trim().toLowerCase();
    const all = this.areas() || [];
    if (!q) return all;
    return all.filter(a =>
      `${a.id} ${a.nombre} ${(a.codigo ?? '')}`.toLowerCase().includes(q)
    );
  });

  filteredNiveles = computed(() => {
    const q = this.nivelSearch.trim().toLowerCase();
    const all = this.niveles() || [];
    if (!q) return all;
    return all.filter(n =>
      `${n.id} ${n.nombre} ${(n.codigo ?? '')}`.toLowerCase().includes(q)
    );
  });

  selectedAreaObj = computed(() => {
    const id = this.selectedAreaId();
    if (!id) return null;
    return (this.areas() || []).find(a => a.id === id) || null;
  });

  ngOnInit() {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    if (!id || Number.isNaN(id)) {
      this.error.set('ID de edición inválido.');
      return;
    }
    this.edicionId.set(id);
    this.reload();
  }

  reload() {
    const id = this.edicionId();
    if (!id) return;

    this.loading.set(true);
    this.saving.set(false);
    this.error.set(null);
    this.warning.set(null);
    this.debugDetails.set(null);

    // 1) Cargar edición (o show())
    this.api.get<ShowResponse>(ENDPOINTS.edicion(id)).subscribe({
      next: (res) => {
        if (!res || (res as any).ok !== true) {
          this.edicion.set(null);
          this.config.set(null);
          this.loading.set(false);
          this.error.set('No se pudo cargar la edición.');
          this.debugDetails.set('Endpoint: ' + ENDPOINTS.edicion(id));
          return;
        }

        const data: any = (res as any).data;

        // puede ser {edicion, areas, niveles} o Edicion directo
        const ed: Edicion = data?.edicion ? data.edicion : data;
        this.edicion.set(ed);

        // si show trae niveles/areas, los tomamos como fallback
        const nivelesFromShow: Nivel[] = Array.isArray(data?.niveles) ? data.niveles : [];
        const areasFromShow: Area[] = Array.isArray(data?.areas) ? data.areas : [];

        // 2) Config
        this.api.get<ApiOk<any> | ApiErr>(ENDPOINTS.config(id)).subscribe({
          next: (r2) => {
            if (!r2 || (r2 as any).ok !== true) {
              this.config.set(null);
              this.loading.set(false);
              this.error.set('No se pudo cargar la configuración.');
              this.debugDetails.set('Endpoint: ' + ENDPOINTS.config(id));
              return;
            }

            const cfg = this.normalizeConfig((r2 as any).data);

            // set + baseline
            this.config.set(cfg);
            this.baselineHash.set(stableStringify(cfg));

            // seleccionar un área por defecto para operar
            const firstSelected = (cfg.area_ids || [])[0] ?? null;
            this.selectedAreaId.set(firstSelected);

            // 3) Catálogos (con fallback)
            this.loadCatalogos({ areasFromShow, nivelesFromShow });

            // warning por estado
            if (!this.canEditByEstado()) {
              this.warning.set('Esta competencia no está en borrador. El sistema opera en modo solo lectura para proteger integridad.');
            }

            this.loading.set(false);
          },
          error: (err) => {
            this.config.set(null);
            this.loading.set(false);
            this.error.set('No se pudo cargar la configuración.');
            this.debugDetails.set(this.httpDebug(err, ENDPOINTS.config(id)));
          },
        });
      },
      error: (err) => {
        this.edicion.set(null);
        this.loading.set(false);
        this.error.set('No se pudo cargar la edición.');
        this.debugDetails.set(this.httpDebug(err, ENDPOINTS.edicion(id)));
      },
    });
  }

  private normalizeConfig(raw: any): ConfigEdicion {
    const area_ids: number[] = Array.isArray(raw?.area_ids)
      ? raw.area_ids.map((x: any) => Number(x)).filter((x: any) => Number.isFinite(x))
      : [];

    // 🔁 backward compatibility:
    // - nuevo: raw.area_niveles
    // - legacy: raw.nivel_ids (se replica para todas las áreas seleccionadas como baseline)
    const legacyNivelIds: number[] = Array.isArray(raw?.nivel_ids)
      ? raw.nivel_ids.map((x: any) => Number(x)).filter((x: any) => Number.isFinite(x))
      : [];

    const area_niveles: Record<number, number[]> = {};

    if (raw?.area_niveles && typeof raw.area_niveles === 'object') {
      for (const [k, v] of Object.entries(raw.area_niveles)) {
        const areaId = Number(k);
        if (!Number.isFinite(areaId)) continue;
        area_niveles[areaId] = Array.isArray(v) ? v.map((x: any) => Number(x)).filter((x: any) => Number.isFinite(x)) : [];
      }
    }

    // asegurar keys para cada área seleccionada
    for (const aid of area_ids) {
      if (!Array.isArray(area_niveles[aid])) {
        // si venimos de legacy, usamos el mismo set para arrancar
        area_niveles[aid] = legacyNivelIds.length ? [...legacyNivelIds] : [];
      }
    }

    const cfg: ConfigEdicion = {
      area_ids,
      area_niveles,
      etapas: Array.isArray(raw?.etapas) ? raw.etapas : [],
      reglas_base: raw?.reglas_base || { tipo: 'mixta', umbral_min: 60, top_n: 10, nota_min_aprob: 51 },
      locks: raw?.locks || {},
      deps: raw?.deps || { inscritos: 0, evaluaciones: 0, resultados: 0 },
    };

    // Normalización de etapas
    cfg.etapas = (cfg.etapas || []).map((e: any) => ({
      key: e.key as EtapaKey,
      nombre: String(e.nombre ?? ''),
      orden: Number(e.orden ?? 0),
      inicio: e.inicio ?? null,
      fin: e.fin ?? null,
      habilitada: !!e.habilitada,
    }))
    .sort((a, b) => (a.orden ?? 0) - (b.orden ?? 0));

    // Locks automáticos si backend no manda
    const deps = cfg.deps || {};
    const hasDeps = (deps.inscritos ?? 0) > 0 || (deps.evaluaciones ?? 0) > 0 || (deps.resultados ?? 0) > 0;

    cfg.locks = cfg.locks || {};
    cfg.locks.estructura = cfg.locks.estructura ?? hasDeps;
    cfg.locks.tiempos = cfg.locks.tiempos ?? ((deps.evaluaciones ?? 0) > 0 || (deps.resultados ?? 0) > 0);
    cfg.locks.etapas = cfg.locks.etapas ?? ((deps.evaluaciones ?? 0) > 0 || (deps.resultados ?? 0) > 0);
    cfg.locks.reglas = cfg.locks.reglas ?? ((deps.evaluaciones ?? 0) > 0 || (deps.resultados ?? 0) > 0);

    // Normalización reglas
    cfg.reglas_base = cfg.reglas_base || { tipo: 'mixta', umbral_min: 60, top_n: 10, nota_min_aprob: 51 };
    if (!cfg.reglas_base.tipo) cfg.reglas_base.tipo = 'mixta';

    return cfg;
  }

  private loadCatalogos(fallback?: { areasFromShow?: Area[]; nivelesFromShow?: Nivel[] }) {
    // Áreas
    this.api.get<ApiOk<Area[]> | ApiErr>(ENDPOINTS.areasCatalogo).subscribe({
      next: (r) => {
        const data = (r as any)?.ok ? ((r as any).data || []) : [];
        this.areas.set(Array.isArray(data) ? data : (fallback?.areasFromShow || []));
      },
      error: () => {
        this.areas.set(fallback?.areasFromShow || []);
      },
    });

    // Niveles: primero intentamos catálogo; si 404, fallback a show()
    this.api.get<ApiOk<Nivel[]> | ApiErr>(ENDPOINTS.nivelesCatalogo).subscribe({
      next: (r) => {
        const data = (r as any)?.ok ? ((r as any).data || []) : [];
        this.niveles.set(Array.isArray(data) ? data : (fallback?.nivelesFromShow || []));
      },
      error: () => {
        this.niveles.set(fallback?.nivelesFromShow || []);
      },
    });
  }

  onMutate() {
    const cfg = this.config();
    if (!cfg) return;
    this.config.set(cloneDeep(cfg));
  }

  canEditByEstado(): boolean {
    return this.edicion()?.estado === 'borrador';
  }

  canEditAny(): boolean {
    if (!this.canEditByEstado()) return false;
    const locks = this.config()?.locks || {};
    const allLocked = !!locks.estructura && !!locks.tiempos && !!locks.etapas && !!locks.reglas;
    return !allLocked;
  }

  isLocked(zone: keyof NonNullable<ConfigEdicion['locks']>): boolean {
    return !!(this.config()?.locks || {})[zone];
  }

  isAreaSelected(id: number): boolean {
    return (this.config()?.area_ids || []).includes(id);
  }

  selectArea(id: number) {
    // solo permitimos seleccionar un área ya seleccionada
    if (!this.isAreaSelected(id)) return;
    this.selectedAreaId.set(id);
  }

  countNivelesArea(areaId: number): number {
    const cfg = this.config();
    if (!cfg) return 0;
    return (cfg.area_niveles?.[areaId] || []).length;
  }

  isNivelSelectedForSelectedArea(nivelId: number): boolean {
    const cfg = this.config();
    const aid = this.selectedAreaId();
    if (!cfg || !aid) return false;
    return (cfg.area_niveles?.[aid] || []).includes(nivelId);
  }

  toggleArea(id: number) {
    if (this.isLocked('estructura') || !this.canEditByEstado()) return;
    const cfg = this.config();
    if (!cfg) return;

    const next = cloneDeep(cfg);

    const set = new Set(next.area_ids || []);
    if (set.has(id)) {
      set.delete(id);
      delete next.area_niveles[id];
      if (this.selectedAreaId() === id) {
        const first = Array.from(set)[0] ?? null;
        this.selectedAreaId.set(first);
      }
    } else {
      set.add(id);
      next.area_niveles[id] = next.area_niveles[id] || [];
      this.selectedAreaId.set(id);
    }

    next.area_ids = Array.from(set);
    this.config.set(next);
  }

  toggleNivelForSelectedArea(nivelId: number) {
    if (this.isLocked('estructura') || !this.canEditByEstado()) return;
    const cfg = this.config();
    const aid = this.selectedAreaId();
    if (!cfg || !aid) return;

    const next = cloneDeep(cfg);
    const arr = Array.isArray(next.area_niveles[aid]) ? next.area_niveles[aid] : [];
    const set = new Set<number>(arr);

    set.has(nivelId) ? set.delete(nivelId) : set.add(nivelId);
    next.area_niveles[aid] = Array.from(set);

    this.config.set(next);
  }

  guardar() {
    const id = this.edicionId();
    const cfg = this.config();
    if (!id || !cfg) return;

    if (!this.canEditAny()) {
      this.warning.set('No se permiten cambios en el estado actual o por locks de integridad.');
      return;
    }

    // Validación mínima: al menos una etapa habilitada
    const enabled = (cfg.etapas || []).filter(x => x.habilitada);
    if (!enabled.length) {
      this.error.set('Debes habilitar al menos una etapa.');
      return;
    }

    // Validación mínima: áreas seleccionadas deben existir en area_niveles
    for (const aid of cfg.area_ids || []) {
      if (!Array.isArray(cfg.area_niveles?.[aid])) {
        this.error.set(`Configuración inválida: faltan niveles para el área ID ${aid}.`);
        return;
      }
    }

    this.saving.set(true);
    this.error.set(null);
    this.warning.set(null);
    this.debugDetails.set(null);

    const payload = {
      area_ids: cfg.area_ids || [],
      area_niveles: cfg.area_niveles || {},

      etapas: (cfg.etapas || []).map(e => ({
        key: e.key,
        nombre: e.nombre,
        orden: e.orden,
        inicio: e.inicio ?? null,
        fin: e.fin ?? null,
        habilitada: !!e.habilitada,
      })),
      reglas_base: {
        tipo: cfg.reglas_base?.tipo,
        umbral_min: cfg.reglas_base?.umbral_min ?? null,
        top_n: cfg.reglas_base?.top_n ?? null,
        nota_min_aprob: cfg.reglas_base?.nota_min_aprob ?? null,
      },
    };

    this.api.put<ApiOk<any> | ApiErr>(ENDPOINTS.config(id), payload).subscribe({
      next: (res) => {
        this.saving.set(false);

        if (!res || (res as any).ok !== true) {
          this.error.set((res as any)?.message || 'No se pudo guardar la configuración.');
          this.debugDetails.set('Endpoint: PUT ' + ENDPOINTS.config(id));
          return;
        }

        const newCfg = this.normalizeConfig((res as any).data);
        this.config.set(newCfg);
        this.baselineHash.set(stableStringify(newCfg));

        // mantener selectedAreaId estable
        const current = this.selectedAreaId();
        if (current && newCfg.area_ids.includes(current)) {
          // ok
        } else {
          this.selectedAreaId.set((newCfg.area_ids || [])[0] ?? null);
        }

        this.warning.set('Cambios guardados correctamente.');
        setTimeout(() => this.warning.set(null), 1500);
      },
      error: (err) => {
        this.saving.set(false);
        this.error.set(err?.error?.message || 'No se pudo guardar la configuración.');
        this.debugDetails.set(this.httpDebug(err, 'PUT ' + ENDPOINTS.config(id)));
      },
    });
  }

  // ====================== UI HELPERS ======================
  labelEstado(estado?: EstadoEdicion | null) {
    if (estado === 'activa') return 'Activa';
    if (estado === 'cerrada') return 'Cerrada';
    return 'Borrador';
  }

  estadoBadgeClass(estado?: EstadoEdicion | null) {
    if (estado === 'activa') return 'bg-emerald-50 text-emerald-700 border-emerald-100';
    if (estado === 'cerrada') return 'bg-slate-50 text-slate-600 border-slate-200';
    return 'bg-amber-50 text-amber-700 border-amber-100';
  }

  estadoDotClass(estado?: EstadoEdicion | null) {
    if (estado === 'activa') return 'bg-emerald-500';
    if (estado === 'cerrada') return 'bg-slate-400';
    return 'bg-amber-500';
  }

  private httpDebug(err: any, endpoint: string): string {
    const status = err?.status;
    const msg = err?.error?.message || err?.message || 'HTTP error';
    return `(${status ?? '—'}) ${endpoint} → ${msg}`;
  }
}
