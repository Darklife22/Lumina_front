import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';

interface MateriaOption {
  id: number;
  nombre: string;
}

interface NivelOption {
  id: number | string;
  nombre: string;
}

interface EstadoContextoUmbral {
  edicion_id: number | null;
  edicion_nombre: string | null;
  notas_completas: boolean;
  umbrales_definidos: boolean;
}

interface ResultadoUmbralRaw {
  participante_id: number;
  nombre_completo: string;
  puntaje_final: number;
  umbral_requerido: number;
  estado_final?: string;
}

interface ResultadoUmbralVista {
  participante_id: number;
  nombre_completo: string;
  puntaje_final: number;
  umbral_requerido: number;
  estado_por_umbral: 'Clasificado' | 'No Clasificado';
}

@Component({
  standalone: true,
  selector: 'app-filtro-umbral',
  imports: [CommonModule, FormsModule],
  template: `
    <div class="space-y-6">

      <!-- Resumen de contexto de umbrales -->
      <section
        class="bg-white rounded-2xl shadow-sm border border-slate-200/70 p-4 md:p-5 flex flex-col gap-4"
      >
        <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
          <div>
            <h2 class="text-lg font-semibold text-slate-800">
              Filtro de Clasificación por Umbral
            </h2>
            <p class="text-sm text-slate-500">
              Vista analítica de la Edición actual, en función de los umbrales por área y nivel.
            </p>
          </div>

          <div class="flex flex-wrap items-center gap-2 text-xs">
            <div class="px-3 py-1 rounded-full border border-slate-200 bg-slate-50">
              <span class="font-medium text-slate-600">Edición:</span>
              <span class="ml-1 text-slate-800">
                {{ contexto.edicion_nombre || 'No asignada' }}
              </span>
            </div>

            <div
              class="px-3 py-1 rounded-full border flex items-center gap-1"
              [ngClass]="contexto.notas_completas
                ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
                : 'border-amber-200 bg-amber-50 text-amber-700'"
            >
              <span class="inline-flex h-2 w-2 rounded-full"
                    [ngClass]="contexto.notas_completas ? 'bg-emerald-500' : 'bg-amber-500'"></span>
              <span class="font-medium">
                Notas finales:
              </span>
              <span class="ml-1">
                {{ contexto.notas_completas ? 'Completas' : 'Pendientes' }}
              </span>
            </div>

            <div
              class="px-3 py-1 rounded-full border flex items-center gap-1"
              [ngClass]="contexto.umbrales_definidos
                ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
                : 'border-amber-200 bg-amber-50 text-amber-700'"
            >
              <span class="inline-flex h-2 w-2 rounded-full"
                    [ngClass]="contexto.umbrales_definidos ? 'bg-emerald-500' : 'bg-amber-500'"></span>
              <span class="font-medium">
                Umbrales:
              </span>
              <span class="ml-1">
                {{ contexto.umbrales_definidos ? 'Definidos' : 'No definidos' }}
              </span>
            </div>
          </div>
        </div>

        <!-- Filtros -->
        <div class="grid grid-cols-1 md:grid-cols-[2fr_1fr_1fr_auto] gap-3 md:gap-4 items-end pt-1">
          <!-- Materia -->
          <div>
            <label class="block text-xs font-medium text-slate-500 mb-1.5">
              Materia / Área
            </label>
            <select
              class="w-full rounded-xl border-slate-200 text-sm px-3 py-2 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500/60 focus:border-sky-500"
              [(ngModel)]="materiaSeleccionadaId"
            >
              <option [ngValue]="null">Selecciona una materia</option>
              <option *ngFor="let m of materias" [ngValue]="m.id">
                {{ m.nombre }}
              </option>
            </select>
          </div>

          <!-- Nivel -->
          <div>
            <label class="block text-xs font-medium text-slate-500 mb-1.5">
              Nivel de competición
            </label>
            <select
              class="w-full rounded-xl border-slate-200 text-sm px-3 py-2 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500/60 focus:border-sky-500"
              [(ngModel)]="nivelSeleccionadoId"
            >
              <option [ngValue]="null">Selecciona un nivel</option>
              <option *ngFor="let n of niveles" [ngValue]="n.id">
                {{ n.nombre }}
              </option>
            </select>
          </div>

          <!-- Estado de aplicación -->
          <div class="flex flex-col gap-1 text-xs text-slate-500">
            <span class="font-medium text-slate-600">
              Condiciones para aplicar filtro:
            </span>
            <ul class="list-disc list-inside space-y-0.5">
              <li [ngClass]="contexto.notas_completas ? 'text-emerald-600' : 'text-slate-500'">
                Notas finales cargadas
              </li>
              <li [ngClass]="contexto.umbrales_definidos ? 'text-emerald-600' : 'text-slate-500'">
                Umbrales configurados por área y nivel
              </li>
              <li
                [ngClass]="
                  materiaSeleccionadaId && nivelSeleccionadoId
                    ? 'text-emerald-600'
                    : 'text-slate-500'
                "
              >
                Materia y nivel seleccionados
              </li>
            </ul>
          </div>

          <!-- Botones -->
          <div class="flex flex-row md:flex-col gap-2 justify-end">
            <button
              type="button"
              (click)="aplicarFiltro()"
              class="inline-flex items-center justify-center px-4 py-2 rounded-xl text-sm font-medium
                     bg-sky-600 text-white shadow-sm hover:bg-sky-700 disabled:opacity-60 disabled:cursor-not-allowed"
              [disabled]="!puedeAplicarFiltro() || cargando"
            >
              <i class="bi bi-funnel me-1.5"></i>
              <span>
                Filtrar Clasificación por Umbral
              </span>
            </button>

            <button
              type="button"
              (click)="limpiarResultados()"
              class="inline-flex items-center justify-center px-3 py-2 rounded-xl text-xs font-medium
                     border border-slate-200 text-slate-600 bg-white hover:bg-slate-50"
            >
              <i class="bi bi-arrow-counterclockwise me-1"></i>
              Limpiar
            </button>
          </div>
        </div>

        <!-- Mensajes de estado -->
        <div *ngIf="mensaje" class="pt-2 text-xs text-slate-500 flex items-center gap-1.5">
          <i class="bi bi-info-circle"></i>
          <span>{{ mensaje }}</span>
        </div>
      </section>

      <!-- Resultados del filtro -->
      <section
        class="bg-white rounded-2xl shadow-sm border border-slate-200/70 p-4 md:p-5"
      >
        <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-4">
          <div>
            <h3 class="text-base font-semibold text-slate-800">
              Resultados filtrados
            </h3>
            <p class="text-xs text-slate-500">
              Solo se muestran participantes no descalificados, clasificados o no clasificados según su puntuación vs. umbral.
            </p>
          </div>

          <div class="flex items-center gap-2 text-xs text-slate-500">
            <div class="inline-flex items-center gap-1.5">
              <span class="inline-flex h-2 w-2 rounded-full bg-emerald-500"></span>
              <span>Clasificado (≥ Umbral)</span>
            </div>
            <div class="inline-flex items-center gap-1.5">
              <span class="inline-flex h-2 w-2 rounded-full bg-rose-500"></span>
              <span>No Clasificado (&lt; Umbral)</span>
            </div>
          </div>
        </div>

        <!-- Loader -->
        <div *ngIf="cargando" class="py-8 flex flex-col items-center justify-center gap-2">
          <div class="h-8 w-8 border-2 border-sky-500 border-t-transparent rounded-full animate-spin"></div>
          <p class="text-xs text-slate-500">Procesando filtro por umbral…</p>
        </div>

        <!-- Sin resultados -->
        <div
          *ngIf="!cargando && resultados.length === 0"
          class="py-8 text-center text-sm text-slate-500"
        >
          No hay datos para mostrar. Aplica un filtro con una materia y nivel válidos.
        </div>

        <!-- Tabla de resultados -->
        <div *ngIf="!cargando && resultados.length > 0" class="overflow-x-auto">
          <table class="min-w-full text-sm border-t border-slate-200">
            <thead class="bg-slate-50/80 text-xs text-slate-500 uppercase">
              <tr>
                <th class="text-left px-3 py-2.5 border-b border-slate-200">#</th>
                <th class="text-left px-3 py-2.5 border-b border-slate-200">
                  Nombre completo
                </th>
                <th class="text-right px-3 py-2.5 border-b border-slate-200">
                  Puntuación final
                </th>
                <th class="text-right px-3 py-2.5 border-b border-slate-200">
                  Umbral requerido
                </th>
                <th class="text-left px-3 py-2.5 border-b border-slate-200">
                  Estado (por Umbral)
                </th>
              </tr>
            </thead>
            <tbody>
              <tr
                *ngFor="let r of resultados; let i = index"
                class="border-b last:border-b-0 border-slate-100 hover:bg-slate-50/60"
              >
                <td class="px-3 py-2.5 text-xs text-slate-500">
                  {{ i + 1 }}
                </td>
                <td class="px-3 py-2.5 text-slate-800">
                  {{ r.nombre_completo }}
                </td>
                <td class="px-3 py-2.5 text-right tabular-nums text-slate-700">
                  {{ r.puntaje_final | number : '1.2-2' }}
                </td>
                <td class="px-3 py-2.5 text-right tabular-nums text-slate-700">
                  {{ r.umbral_requerido | number : '1.2-2' }}
                </td>
                <td class="px-3 py-2.5">
                  <span
                    class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium"
                    [ngClass]="
                      r.estado_por_umbral === 'Clasificado'
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : 'bg-rose-50 text-rose-700 border border-rose-200'
                    "
                  >
                    <span
                      class="inline-flex h-1.5 w-1.5 rounded-full mr-1.5"
                      [ngClass]="
                        r.estado_por_umbral === 'Clasificado'
                          ? 'bg-emerald-500'
                          : 'bg-rose-500'
                      "
                    ></span>
                    {{ r.estado_por_umbral }}
                  </span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>
    </div>
  `,
})
export class FiltroUmbralComponent {
  private api = inject(ApiService);

  contexto: EstadoContextoUmbral = {
    edicion_id: null,
    edicion_nombre: null,
    notas_completas: false,
    umbrales_definidos: false,
  };

  materias: MateriaOption[] = [];
  niveles: NivelOption[] = [];

  materiaSeleccionadaId: number | null = null;
  nivelSeleccionadoId: number | string | null = null;

  resultados: ResultadoUmbralVista[] = [];
  cargando = false;
  mensaje: string | null = null;

  constructor() {
    this.cargarContextoYFiltros();
  }

  private cargarContextoYFiltros() {
    this.mensaje = 'Cargando contexto de la Edición actual…';

    this.api.get('/admin/filtro-umbral/opciones').subscribe(
      (data: any) => {
        this.contexto = {
          edicion_id: data?.edicion?.id ?? null,
          edicion_nombre: data?.edicion?.nombre ?? null,
          notas_completas: !!data?.notas_completas,
          umbrales_definidos: !!data?.umbrales_definidos,
        };

        this.materias = data?.materias || [];
        this.niveles = data?.niveles || [];

        this.mensaje = null;
      },
      () => {
        this.mensaje =
          'No se pudo cargar el contexto de la Edición actual. Verifica el backend del filtro de umbrales.';
      }
    );
  }

  puedeAplicarFiltro(): boolean {
    const ctx = this.contexto;
    return (
      !!ctx.edicion_id &&
      ctx.notas_completas &&
      ctx.umbrales_definidos &&
      !!this.materiaSeleccionadaId &&
      !!this.nivelSeleccionadoId
    );
  }

  aplicarFiltro() {
    if (!this.puedeAplicarFiltro()) {
      this.mensaje =
        'Para aplicar el filtro, asegúrate de tener notas finales cargadas, umbrales definidos y haber seleccionado materia y nivel.';
      return;
    }

    this.cargando = true;
    this.mensaje = 'Aplicando filtro por umbral sobre la Edición actual…';
    this.resultados = [];

    this.api
      .get('/admin/filtro-umbral/resultados', {
        materia_id: String(this.materiaSeleccionadaId),
        nivel_id: String(this.nivelSeleccionadoId),
      })
      .subscribe(
        (data: any) => {
          const raw: ResultadoUmbralRaw[] = data || [];

          const filtrados = raw.filter(
            (r) =>
              !r.estado_final ||
              r.estado_final.toLowerCase() !== 'descalificado'
          );

          this.resultados = filtrados.map((r) => {
            const estado_por_umbral: 'Clasificado' | 'No Clasificado' =
              r.puntaje_final >= r.umbral_requerido
                ? 'Clasificado'
                : 'No Clasificado';

            return {
              participante_id: r.participante_id,
              nombre_completo: r.nombre_completo,
              puntaje_final: r.puntaje_final,
              umbral_requerido: r.umbral_requerido,
              estado_por_umbral,
            };
          });

          this.cargando = false;

          if (this.resultados.length === 0) {
            this.mensaje =
              'No se encontraron participantes para la combinación seleccionada o todos fueron descalificados.';
          } else {
            this.mensaje =
              'Filtro aplicado. La clasificación mostrada es solo de vista y no modifica el estado real de los participantes.';
          }
        },
        () => {
          this.cargando = false;
          this.mensaje =
            'Ocurrió un error al aplicar el filtro por umbral. Revisa el endpoint de resultados en el backend.';
        }
      );
  }

  limpiarResultados() {
    this.resultados = [];
    this.materiaSeleccionadaId = null;
    this.nivelSeleccionadoId = null;
    this.mensaje = 'Filtros y tabla reiniciados.';
  }
}
