import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  standalone: true,
  selector: 'app-admin-dashboard',
  imports: [CommonModule],
  template: `
    <!-- Métricas -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
      <div class="bg-white rounded-2xl border border-slate-200 p-4">
        <div class="text-slate-500 text-sm flex items-center gap-2"><i class="bi bi-people"></i> Inscritos</div>
        <div class="text-4xl font-bold mt-1">2,140</div>
      </div>
      <div class="bg-white rounded-2xl border border-slate-200 p-4">
        <div class="text-slate-500 text-sm flex items-center gap-2"><i class="bi bi-grid-3x3-gap"></i> Evaluaciones</div>
        <div class="text-4xl font-bold mt-1">1,860</div>
      </div>
      <div class="bg-white rounded-2xl border border-slate-200 p-4">
        <div class="text-slate-500 text-sm flex items-center gap-2"><i class="bi bi-trophy"></i> Clasificados</div>
        <div class="text-4xl font-bold mt-1">640</div>
      </div>
      <div class="bg-white rounded-2xl border border-slate-200 p-4">
        <div class="text-slate-500 text-sm flex items-center gap-2"><i class="bi bi-award"></i> Finalistas</div>
        <div class="text-4xl font-bold mt-1">120</div>
      </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
      <!-- Estado del proceso -->
      <div class="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-4">
        <div class="flex items-center justify-between mb-3">
          <div class="font-semibold">Estado del proceso</div>
          <div class="text-xs text-slate-500">Actualizado hoy</div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div class="rounded-xl border border-slate-200 p-3 flex items-start justify-between">
            <div>
              <div class="font-medium">Importación de inscritos</div>
              <div class="text-xs text-slate-500">CSV validado y listo</div>
            </div>
            <span class="inline-flex items-center gap-1 text-xs rounded-full px-2 py-1 bg-emerald-100 text-emerald-700">
              <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> Listo
            </span>
          </div>

          <div class="rounded-xl border border-slate-200 p-3 flex items-start justify-between">
            <div>
              <div class="font-medium">Evaluación (Clasificación)</div>
              <div class="text-xs text-slate-500">Notas en tiempo real</div>
            </div>
            <span class="inline-flex items-center gap-1 text-xs rounded-full px-2 py-1 bg-blue-100 text-blue-700">
              <span class="w-1.5 h-1.5 rounded-full bg-blue-500"></span> En curso
            </span>
          </div>

          <div class="rounded-xl border border-slate-200 p-3 flex items-start justify-between">
            <div>
              <div class="font-medium">Evaluación (Final)</div>
              <div class="text-xs text-slate-500">Pendiente de apertura</div>
            </div>
            <span class="inline-flex items-center gap-1 text-xs rounded-full px-2 py-1 bg-slate-100 text-slate-700">
              <span class="w-1.5 h-1.5 rounded-full bg-slate-400"></span> Pendiente
            </span>
          </div>

          <div class="rounded-xl border border-slate-200 p-3 flex items-start justify-between">
            <div>
              <div class="font-medium">Reportes & Certificados</div>
              <div class="text-xs text-slate-500">Listas por área y nivel</div>
            </div>
            <span class="inline-flex items-center gap-1 text-xs rounded-full px-2 py-1 bg-slate-100 text-slate-700">
              <span class="w-1.5 h-1.5 rounded-full bg-slate-400"></span> Pendiente
            </span>
          </div>
        </div>

        <div class="mt-4">
          <div class="text-xs text-slate-600 mb-1">Avance total</div>
          <div class="h-2 bg-slate-200 rounded-full overflow-hidden">
            <div class="h-full bg-[#1a55a9] rounded-full" [style.width.%]="progreso()"></div>
          </div>
        </div>
      </div>

      <!-- Actividad reciente -->
      <div class="bg-white rounded-2xl border border-slate-200 p-4">
        <div class="font-semibold mb-3">Actividad reciente</div>
        <ul class="space-y-3">
          <li *ngFor="let a of actividad()"
              class="flex items-start justify-between">
            <div>
              <div class="font-medium">{{ a.titulo }}</div>
              <div class="text-xs text-slate-500">
                {{ a.actor }} • {{ a.hace }}
              </div>
            </div>
            <div class="text-xs text-slate-600 bg-slate-100 rounded-full px-2 py-1">
              {{ a.meta }}
            </div>
          </li>
        </ul>
      </div>
    </div>

    <!-- Acciones rápidas -->
    <div class="bg-white rounded-2xl border border-slate-200 p-4">
      <div class="font-semibold mb-3">Acciones rápidas</div>
      <div class="flex flex-wrap gap-2">
        <a routerLink="/admin/importaciones" class="inline-flex items-center gap-2 rounded-xl bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50">
          <i class="bi bi-file-earmark-arrow-up"></i> Importar CSV
        </a>
        <button class="inline-flex items-center gap-2 rounded-xl bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50">
          <i class="bi bi-pencil-square"></i> Ingresar notas
        </button>
        <button class="inline-flex items-center gap-2 rounded-xl bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50">
          <i class="bi bi-file-earmark-bar-graph"></i> Generar reportes
        </button>
        <a routerLink="/admin/areas/nueva"
          class="inline-flex items-center gap-2 rounded-lg bg-[#0f3f94] hover:bg-[#0d3580] text-white px-3 py-2 text-sm">
          <i class="bi bi-plus-lg"></i> Crear Nueva Área
        </a>

        <button class="inline-flex items-center gap-2 rounded-xl bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50">
          <i class="bi bi-gear"></i> Configuración
        </button>
      </div>
    </div>
  `
})
export class AdminDashboardComponent {
  progreso = signal(62);
  actividad = signal<Array<{ titulo: string; actor: string; hace: string; meta: string }>>([
    { titulo: 'Notas actualizadas – Física', actor: 'Resp. Área', hace: 'hace 12 min', meta: '+45' },
    { titulo: 'CSV importado – Robótica', actor: 'Sistema', hace: 'hoy 09:41', meta: '1,120' },
    { titulo: 'Revisión de clasificados – Química', actor: 'Comité', hace: 'ayer', meta: 'OK' },
  ]);
}
