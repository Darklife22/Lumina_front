import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';

type Area = { id: number; nombre: string };

type Row = {
  id: number;
  usuario_id?: number | null;
  nombre: string;
  email: string;
  telefono: string;
  activo: boolean;
  areas: Area[];
};

type Meta = {
  page: number;
  per_page: number;
  total: number;
  total_pages: number;
};

type ResponsableLite = {
  id: number;
  nombre: string;
  email: string;
  telefono: string | null;
  activo: boolean;
  areas: Area[];
};

type UsuarioLite = {
  id: number;
  nombre: string;
  email: string;
  telefono?: string | null;
  responsable: ResponsableLite | null;
};

interface AreasResponse { data: Area[] }
interface ListResponse { data: Row[]; meta: Meta }
interface SaveResponse { ok: boolean; message?: string; data?: Row; password_temporal?: string }
interface OkResponse { ok: boolean; message?: string }

interface BuscarUsuariosResponse { data: UsuarioLite[] }

@Component({
  standalone: true,
  selector: 'app-responsables-academicos',
  imports: [CommonModule, FormsModule],
  template: `
  <section class="space-y-4">
    <!-- Header -->
    <div class="bg-white rounded-2xl border border-slate-200 p-4 flex items-center justify-between">
      <div>
        <div class="text-lg font-bold">Responsables académicos</div>
        <div class="text-sm text-slate-500 -mt-0.5">
          Asignación de rol de Responsable de Área y vinculación a Áreas de competencia
        </div>
      </div>
      <div class="flex items-center gap-2">
        <button
          (click)="export('pdf')"
          class="rounded-lg bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50">
          <i class="bi bi-file-pdf"></i> Exportar PDF
        </button>
        <button
          (click)="export('csv')"
          class="rounded-lg bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50">
          <i class="bi bi-filetype-csv"></i> Exportar CSV
        </button>
        <button
          (click)="openForm()"
          class="rounded-lg bg-[#0f3f94] hover:bg-[#0d3580] text-white px-3 py-2 text-sm">
          <i class="bi bi-plus-lg"></i> Asignar responsable
        </button>
      </div>
    </div>

    <!-- Banner de contraseña temporal (global) -->
    <div *ngIf="tempPassword()" class="rounded-xl border border-amber-200 bg-amber-50 text-amber-800 px-4 py-3">
      <div class="flex items-center justify-between gap-3">
        <div class="text-sm">
          <span class="font-semibold">Contraseña temporal generada:</span>
          <span class="font-mono bg-white/60 rounded px-2 py-0.5 ml-1">{{ tempPassword() }}</span>
          <span class="text-xs text-amber-700 ml-2">
            Compártela con el responsable; deberá cambiarla en su primer inicio.
          </span>
        </div>
        <div class="flex items-center gap-2">
          <button
            (click)="copyTempPassword()"
            class="rounded-lg bg-white border border-amber-300 px-3 py-1.5 text-sm hover:bg-amber-100">
            <i class="bi bi-clipboard"></i> Copiar
          </button>
          <button
            (click)="clearTempPassword()"
            class="rounded-lg bg-white border border-amber-300 px-3 py-1.5 text-sm hover:bg-amber-100">
            Ocultar
          </button>
        </div>
      </div>
    </div>

    <!-- Filtros -->
    <div class="bg-white rounded-2xl border border-slate-200 p-4">
      <div class="grid gap-3 md:grid-cols-4">
        <div class="md:col-span-2">
          <label class="text-xs text-slate-500">Buscar</label>
          <input
            [(ngModel)]="q"
            (keyup.enter)="search()"
            placeholder="Nombre, email o teléfono"
            class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-200 focus:border-blue-300">
        </div>
        <div>
          <label class="text-xs text-slate-500">Área</label>
          <select
            [(ngModel)]="areaId"
            (ngModelChange)="onAreaFilterChange()"
            class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
            <option [ngValue]="0">Todas</option>
            <option *ngFor="let a of areas()" [ngValue]="a.id">{{ a.nombre }}</option>
          </select>
        </div>
        <div class="flex items-end gap-2">
          <button
            (click)="search()"
            class="rounded-lg bg-[#0f3f94] hover:bg-[#0d3580] text-white px-3 py-2 text-sm">
            <i class="bi bi-search"></i> Filtrar
          </button>
          <button
            (click)="clear()"
            class="rounded-lg bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50">
            Limpiar
          </button>
        </div>
      </div>
    </div>

    <!-- Tabla -->
    <div class="bg-white rounded-2xl border border-slate-200 p-0">
      <div class="flex items-center justify-between p-3">
        <div class="font-semibold">Listado ({{ meta().total }} reg.)</div>
      </div>
      <div class="overflow-auto">
        <table class="min-w-full text-sm">
          <thead class="bg-slate-50 sticky top-0">
            <tr class="text-left text-slate-600">
              <th class="py-2 px-3">Nombre</th>
              <th class="py-2 px-3">Email</th>
              <th class="py-2 px-3">Teléfono</th>
              <th class="py-2 px-3">Áreas</th>
              <th class="py-2 px-3">Estado</th>
              <th class="py-2 px-3">Acciones</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngIf="rows().length === 0">
              <td colspan="6" class="text-center text-slate-400 py-4">No hay registros</td>
            </tr>
            <tr *ngFor="let r of rows()" class="border-t border-slate-100">
              <td class="py-2 px-3">{{ r.nombre }}</td>
              <td class="py-2 px-3">
                <a *ngIf="r.email" class="text-blue-600 hover:underline" [href]="'mailto:' + r.email">
                  {{ r.email }}
                </a>
                <span *ngIf="!r.email" class="text-slate-400">—</span>
              </td>
              <td class="py-2 px-3">
                <span *ngIf="r.telefono; else dashTpl">{{ r.telefono }}</span>
                <ng-template #dashTpl>—</ng-template>
              </td>
              <td class="py-2 px-3">
                <div class="flex flex-wrap gap-1">
                  <span
                    *ngFor="let a of r.areas"
                    class="inline-flex items-center rounded-full bg-blue-50 text-blue-700 px-2 py-0.5 text-[11px] border border-blue-200">
                    {{ a.nombre }}
                  </span>
                  <span *ngIf="!r.areas?.length" class="text-xs text-slate-400">Sin áreas</span>
                </div>
              </td>
              <td class="py-2 px-3">
                <span
                  class="text-xs rounded-full px-2 py-1"
                  [class.bg-emerald-100]="r.activo" [class.text-emerald-700]="r.activo"
                  [class.bg-red-100]="!r.activo" [class.text-red-700]="!r.activo">
                  {{ r.activo ? 'Activo' : 'Inactivo' }}
                </span>
              </td>
              <td class="py-2 px-3">
                <div class="flex items-center gap-3 text-xs">
                  <button class="text-blue-600 hover:underline" (click)="edit(r)">Editar</button>
                  <button class="text-red-600 hover:underline" (click)="remove(r)">Quitar rol</button>
                  <button
                    class="text-amber-600 hover:underline"
                    title="Regenerar contraseña temporal"
                    (click)="resetPassword(r.id)">
                    Reset pass
                  </button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Paginación -->
      <div class="flex items-center justify-between p-3 text-sm">
        <div class="text-slate-500">
          Página {{ meta().page }} de {{ meta().total_pages }} • {{ meta().total }} registros
        </div>
        <div class="flex items-center gap-2">
          <button
            (click)="goTo(meta().page - 1)"
            [disabled]="meta().page <= 1"
            class="rounded-lg bg-white border border-slate-200 px-3 py-1.5 disabled:opacity-50 hover:bg-slate-50">
            <i class="bi bi-chevron-left"></i>
          </button>
          <button
            (click)="goTo(meta().page + 1)"
            [disabled]="meta().page >= meta().total_pages"
            class="rounded-lg bg-white border border-slate-200 px-3 py-1.5 disabled:opacity-50 hover:bg-slate-50">
            <i class="bi bi-chevron-right"></i>
          </button>
          <select
            [(ngModel)]="perPage"
            (change)="search()"
            class="rounded-lg border border-slate-300 px-2 py-1">
            <option [value]="10">10</option>
            <option [value]="20">20</option>
            <option [value]="50">50</option>
            <option [value]="100">100</option>
          </select>
        </div>
      </div>
    </div>

    <!-- Modal Form (Nuevo / Editar) -->
    <div *ngIf="formOpen()" class="fixed inset-0 z-50 flex items-center justify-center">
      <div class="absolute inset-0 bg-black/50" (click)="closeForm()"></div>
      <div class="relative bg-white rounded-2xl shadow-xl w-full max-w-2xl">
        <div class="p-4 border-b border-slate-200 flex items-center justify-between">
          <div class="font-semibold">
            {{ editingId() ? 'Editar responsable académico' : 'Asignar responsable académico' }}
          </div>
          <button
            class="w-8 h-8 rounded-lg border border-slate-200 hover:bg-slate-50"
            (click)="closeForm()">
            <i class="bi bi-x"></i>
          </button>
        </div>

        <div class="p-4 space-y-4 max-h-[70vh] overflow-auto">

          <!-- Info si se está editando por selección de usuario -->
          <div *ngIf="editingId() && selectedUsuarioNombre()"
               class="rounded-xl border border-blue-100 bg-blue-50 text-[11px] text-blue-800 px-3 py-2 flex items-start gap-2">
            <i class="bi bi-info-circle mt-0.5"></i>
            <div>
              Estás editando el responsable ya asociado al usuario
              <span class="font-semibold">{{ selectedUsuarioNombre() }}</span>.
            </div>
          </div>

          <!-- Bloque: seleccionar usuario ya registrado -->
          <div class="rounded-xl border border-slate-200 bg-slate-50/40 p-3 space-y-2">
            <div class="flex items-center justify-between gap-2">
              <div class="text-xs font-semibold text-slate-600">
                Seleccionar usuario registrado (opcional)
              </div>
              <div class="text-[11px] text-slate-500" *ngIf="editingId()">
                Modo edición activo.
              </div>
            </div>
            <div class="flex flex-col gap-2 md:flex-row md:items-center">
              <input
                [(ngModel)]="userSearchTerm"
                (keyup.enter)="buscarUsuarios()"
                placeholder="Buscar por nombre, apellido o correo..."
                class="flex-1 rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none
                       focus:ring-2 focus:ring-blue-200 focus:border-blue-300">
              <button
                (click)="buscarUsuarios()"
                [disabled]="userSearchLoading() || !userSearchTerm.trim()"
                class="rounded-lg bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50 disabled:opacity-50">
                <ng-container *ngIf="!userSearchLoading(); else loadingUsersTpl">
                  <i class="bi bi-search"></i> Buscar usuario
                </ng-container>
                <ng-template #loadingUsersTpl>
                  <span class="inline-flex items-center gap-2 text-xs">
                    <span
                      class="inline-block h-3 w-3 border-2 border-slate-400/60 border-t-slate-500 rounded-full animate-spin"></span>
                    Buscando...
                  </span>
                </ng-template>
              </button>
            </div>

            <!-- Usuario vinculado -->
            <div *ngIf="form.usuario_id" class="flex items-center justify-between mt-2 text-xs">
              <div class="flex flex-col">
                <span class="text-slate-600">
                  Usuario vinculado:
                  <span class="font-semibold">{{ selectedUsuarioNombre() }}</span>
                </span>
                <span class="text-slate-500">
                  {{ selectedUsuarioEmail() }}
                  <span *ngIf="selectedUsuarioTelefono()"> · Tel: {{ selectedUsuarioTelefono() }}</span>
                </span>
              </div>
              <button
                class="text-[11px] rounded-md border border-slate-200 px-2 py-1 hover:bg-slate-100"
                (click)="desvincularUsuario()">
                Quitar vínculo
              </button>
            </div>

            <!-- Resultados búsqueda usuarios -->
            <div
              *ngIf="userResults().length"
              class="mt-2 rounded-lg border border-slate-200 bg-white max-h-60 overflow-auto">
              <table class="min-w-full text-xs">
                <thead class="bg-slate-50">
                  <tr class="text-left text-slate-600">
                    <th class="py-1 px-2">Usuario</th>
                    <th class="py-1 px-2">Email</th>
                    <th class="py-1 px-2">Teléfono</th>
                    <th class="py-1 px-2 text-right">Acción</th>
                  </tr>
                </thead>
                <tbody>
                  <tr *ngFor="let u of userResults()" class="border-t border-slate-100">
                    <td class="py-1 px-2">
                      <div class="flex flex-col">
                        <span class="font-medium">{{ u.nombre }}</span>
                        <span *ngIf="u.responsable" class="text-[10px] text-emerald-700">
                          Ya es responsable ({{ areasLabel(u.responsable) }})
                        </span>
                      </div>
                    </td>
                    <td class="py-1 px-2">{{ u.email }}</td>
                    <td class="py-1 px-2">{{ u.telefono || '—' }}</td>
                    <td class="py-1 px-2 text-right">
                      <button
                        class="text-[11px] rounded-md bg-[#0f3f94] text-white px-2 py-1 hover:bg-[#0d3580]"
                        (click)="seleccionarUsuario(u)">
                        {{ u.responsable ? 'Editar responsable' : 'Usar usuario' }}
                      </button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            <div *ngIf="userSearchError()" class="mt-1 text-[11px] text-red-600">
              {{ userSearchError() }}
            </div>
          </div>

          <!-- Datos básicos -->
          <div>
            <label class="text-xs text-slate-500">Nombre completo *</label>
            <input
              [(ngModel)]="form.nombre"
              class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
          </div>
          <div>
            <label class="text-xs text-slate-500">Correo electrónico *</label>
            <input
              [(ngModel)]="form.email"
              type="email"
              class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
          </div>
          <div>
            <label class="text-xs text-slate-500">Teléfono *</label>
            <input
              [(ngModel)]="form.telefono"
              class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              placeholder="Sólo dígitos">
          </div>

          <!-- Áreas -->
          <div>
            <div class="flex items-center justify-between gap-2 mb-1">
              <label class="text-xs text-slate-500">Áreas asignadas *</label>
              <div class="flex items-center gap-1 text-[11px]">
                <button
                  class="rounded-md border border-slate-200 px-2 py-0.5 hover:bg-slate-50"
                  (click)="toggleAllAreas(true)">
                  Todas visibles
                </button>
                <button
                  class="rounded-md border border-slate-200 px-2 py-0.5 hover:bg-slate-50"
                  (click)="toggleAllAreas(false)">
                  Ninguna nueva
                </button>
              </div>
            </div>

            <div class="text-[11px] text-slate-500 mb-1" *ngIf="editingId()">
              Las áreas ya asignadas se mantienen. Para quitarlas se usa la opción
              <strong>"Quitar áreas actuales"</strong> con motivo.
            </div>

            <div class="flex items-center gap-2 mt-1">
              <input
                [(ngModel)]="areaFilter"
                placeholder="Filtrar áreas..."
                class="flex-1 rounded-lg border border-slate-300 px-2 py-1 text-sm">
            </div>

            <div class="grid grid-cols-2 gap-2 mt-2 max-h-56 overflow-auto pr-1">
              <label *ngFor="let a of filteredAreas()" class="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  [checked]="form.areas.includes(a.id)"
                  (change)="toggleArea(a.id, $event)">
                <span>
                  {{ a.nombre }}
                  <span
                    *ngIf="editingId() && originalAreas().includes(a.id)"
                    class="ml-1 text-[10px] text-amber-600">
                    ya asignada
                  </span>
                </span>
              </label>
            </div>

            <div class="mt-2 flex justify-end" *ngIf="editingId() && originalAreas().length">
              <button
                type="button"
                class="text-[11px] text-red-700 border border-red-200 rounded-md px-2 py-1 bg-red-50 hover:bg-red-100"
                (click)="openRemoveAreasModal()">
                <i class="bi bi-slash-circle me-1"></i> Quitar áreas actuales (con motivo)
              </button>
            </div>
          </div>

          <!-- Estado + Acceso -->
          <div class="flex items-center justify-between gap-4">
            <label class="inline-flex items-center gap-2">
              <input type="checkbox" [(ngModel)]="form.activo">
              <span class="text-sm">Responsable activo</span>
            </label>
          </div>

          <!-- Password temporal en modal -->
          <div
            *ngIf="tempPasswordModal()"
            class="rounded-xl border border-amber-200 bg-amber-50 text-amber-800 px-3 py-2 text-sm">
            Nueva contraseña temporal:
            <span class="font-mono bg-white/60 rounded px-2 py-0.5">{{ tempPasswordModal() }}</span>
            <button class="ml-2 text-xs underline" (click)="copyText(tempPasswordModal())">
              Copiar
            </button>
          </div>

          <!-- Mensajes de error / éxito -->
          <div
            *ngIf="errorMsg()"
            class="rounded-xl border border-red-200 bg-red-50 text-red-700 px-3 py-2 text-sm">
            {{ errorMsg() }}
          </div>
          <div
            *ngIf="successMsg()"
            class="rounded-xl border border-emerald-200 bg-emerald-50 text-emerald-700 px-3 py-2 text-sm">
            {{ successMsg() }}
          </div>
        </div>

        <div class="p-4 border-t border-slate-200 flex items-center justify-end gap-2">
          <button
            (click)="closeForm()"
            class="rounded-lg bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50">
            Cancelar
          </button>
          <button
            (click)="save()"
            [disabled]="saving()"
            class="rounded-lg bg-[#0f3f94] hover:bg-[#0d3580] text-white px-4 py-2 text-sm">
            <ng-container *ngIf="!saving(); else savingTpl">
              <i class="bi bi-save"></i> Guardar
            </ng-container>
            <ng-template #savingTpl>
              <span class="inline-flex items-center gap-2">
                <span
                  class="inline-block h-4 w-4 border-2 border-white/60 border-t-white rounded-full animate-spin"></span>
                Guardando...
              </span>
            </ng-template>
          </button>
        </div>
      </div>
    </div>

    <!-- Modal Quitar áreas actuales -->
    <div *ngIf="removeOpen()" class="fixed inset-0 z-50 flex items-center justify-center">
      <div class="absolute inset-0 bg-black/50" (click)="closeRemoveAreasModal()"></div>
      <div class="relative bg-white rounded-2xl shadow-xl w-full max-w-lg">
        <div class="p-4 border-b border-slate-200 flex items-center justify-between">
          <div class="font-semibold text-red-700 flex items-center gap-2">
            <i class="bi bi-slash-circle"></i>
            Quitar áreas del responsable
          </div>
          <button
            class="w-8 h-8 rounded-lg border border-slate-200 hover:bg-slate-50"
            (click)="closeRemoveAreasModal()"
            [disabled]="removeSaving()">
            <i class="bi bi-x"></i>
          </button>
        </div>

        <div class="p-4 space-y-3 max-h-[70vh] overflow-auto">
          <div class="text-sm text-slate-600">
            Selecciona las áreas que deseas desvincular del responsable
            <span class="font-semibold" *ngIf="selectedUsuarioNombre()">
              {{ selectedUsuarioNombre() }}
            </span>.
          </div>

          <div class="text-xs text-slate-500 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2">
            Esta acción requiere un motivo y respeta las restricciones del proceso
            (calificaciones, edición activa, etc.). Las calificaciones ya registradas se mantienen
            para fines de historial.
          </div>

          <div class="max-h-52 overflow-auto border border-slate-200 rounded-lg px-3 py-2 space-y-1">
            <label
              *ngFor="let a of areasOriginalesDetalladas()"
              class="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                [checked]="removeSeleccion().includes(a.id)"
                (change)="toggleRemoveArea(a.id, $event)">
              <span>{{ a.nombre }}</span>
            </label>
            <div *ngIf="!areasOriginalesDetalladas().length" class="text-xs text-slate-400">
              El responsable no tiene áreas actualmente asignadas desde la base de datos.
            </div>
          </div>

          <div>
            <label class="block text-xs font-medium text-slate-600 mb-1">
              Motivo de la desvinculación <span class="text-red-500">*</span>
            </label>
            <textarea
              rows="4"
              class="w-full rounded-lg border px-3 py-2 text-sm outline-none
                     focus:ring-2 focus:ring-red-200 focus:border-red-300 border-slate-300"
              [ngModel]="removeMotivo()"
              (ngModelChange)="removeMotivo.set($event)"
              [disabled]="removeSaving()"
              maxlength="500"
              placeholder="Describe brevemente por qué se quitan estas áreas al responsable..."
            ></textarea>
            <div class="flex justify-between items-center mt-1">
              <span class="text-xs text-slate-500">
                Mínimo 5 caracteres. Máximo 500.
              </span>
              <span class="text-xs text-slate-400">
                {{ removeMotivo().length }}/500
              </span>
            </div>
          </div>

          <div *ngIf="removeError()" class="text-xs text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
            {{ removeError() }}
          </div>
        </div>

        <div class="p-4 border-t border-slate-200 flex items-center justify-end gap-2 bg-slate-50/50">
          <button
            type="button"
            class="rounded-lg px-3 py-1.5 text-sm border border-slate-200 hover:bg-white"
            (click)="closeRemoveAreasModal()"
            [disabled]="removeSaving()">
            Cancelar
          </button>
          <button
            type="button"
            class="rounded-lg px-4 py-1.5 text-sm text-white bg-red-600 hover:bg-red-700 disabled:opacity-60 disabled:cursor-not-allowed"
            (click)="submitRemoveAreas()"
            [disabled]="removeSaving() || !canSubmitRemove()">
            <ng-container *ngIf="!removeSaving(); else removeSavingTpl">
              Confirmar remoción
            </ng-container>
          </button>
        </div>

        <ng-template #removeSavingTpl>
          <span class="inline-flex items-center gap-2 text-xs text-white">
            <span class="inline-block h-3.5 w-3.5 border-2 border-white/60 border-t-white rounded-full animate-spin"></span>
            Procesando...
          </span>
        </ng-template>
      </div>
    </div>
  </section>
  `
})
export class ResponsablesAcademicosComponent {
  private api = inject(ApiService);

  // Filtros
  q = '';
  areaId = 0;
  page = 1;
  perPage = 20;

  areas = signal<Area[]>([]);
  rows = signal<Row[]>([]);
  meta = signal<Meta>({ page: 1, per_page: 20, total: 0, total_pages: 0 });

  // Modal principal
  formOpen = signal(false);
  saving = signal(false);
  editingId = signal<number | null>(null);
  errorMsg = signal('');
  successMsg = signal('');

  form: {
    usuario_id: number | null;
    nombre: string;
    email: string;
    telefono: string;
    areas: number[];
    activo: boolean;
  } = {
    usuario_id: null,
    nombre: '',
    email: '',
    telefono: '',
    areas: [],
    activo: true,
  };

  areaFilter = '';

  tempPassword = signal<string>('');      // banner superior
  tempPasswordModal = signal<string>(''); // dentro del modal

  // Buscador usuarios
  userSearchTerm = '';
  userResults = signal<UsuarioLite[]>([]);
  userSearchLoading = signal(false);
  userSearchError = signal('');

  selectedUsuarioNombre = signal<string>('');
  selectedUsuarioEmail = signal<string>('');
  selectedUsuarioTelefono = signal<string>('');

  // Control de áreas originales (no se pueden quitar sin motivo)
  originalAreas = signal<number[]>([]);

  // Modal quitar áreas
  removeOpen = signal(false);
  removeSeleccion = signal<number[]>([]);
  removeMotivo = signal<string>('');
  removeSaving = signal<boolean>(false);
  removeError = signal<string | null>(null);

  ngOnInit(): void {
    this.fetchAreas();
    this.search();
  }

  // Helper label
  areasLabel(r: ResponsableLite | null | undefined): string {
    if (!r || !r.areas || !r.areas.length) return 'sin áreas';
    return r.areas.map(a => a.nombre).join(', ');
  }

  // ======================= Data base =======================

  fetchAreas(): void {
    this.api.get('/admin/responsables/areas').subscribe(
      (value: unknown) => {
        const res = value as AreasResponse;
        this.areas.set(res?.data ?? []);
      },
      () => this.areas.set([])
    );
  }

  params(): Record<string, string> {
    const p: Record<string, string> = {
      page: String(this.page),
      per_page: String(this.perPage)
    };
    if (this.q.trim()) p['q'] = this.q.trim();
    if (this.areaId) p['area_id'] = String(this.areaId);
    return p;
  }

  search(): void {
    const qs = new URLSearchParams(this.params()).toString();
    this.api.get(`/admin/responsables?${qs}`).subscribe(
      (value: unknown) => {
        const res = value as ListResponse;
        this.rows.set(res?.data ?? []);
        this.meta.set(
          res?.meta ?? { page: 1, per_page: this.perPage, total: 0, total_pages: 0 }
        );
      },
      () => {
        this.rows.set([]);
        this.meta.set({ page: 1, per_page: this.perPage, total: 0, total_pages: 0 });
      }
    );
  }

  clear(): void {
    this.q = '';
    this.areaId = 0;
    this.page = 1;
    this.search();
  }

  goTo(p: number): void {
    const m = this.meta();
    if (p < 1 || p > m.total_pages) return;
    this.page = p;
    this.search();
  }

  onAreaFilterChange(): void {
    this.page = 1;
    this.search();
  }

  export(format: 'pdf' | 'csv'): void {
    const base = (window as any).environment?.apiUrl || '';
    const qs = new URLSearchParams(this.params()).toString();
    window.open(`${base}/admin/responsables/export?format=${format}&${qs}`, '_blank');
  }

  // ======================= Modal =======================

  openForm(): void {
    this.editingId.set(null);
    this.form = {
      usuario_id: null,
      nombre: '',
      email: '',
      telefono: '',
      areas: [],
      activo: true
    };
    this.areaFilter = '';
    this.errorMsg.set('');
    this.successMsg.set('');
    this.tempPasswordModal.set('');
    this.userSearchTerm = '';
    this.userResults.set([]);
    this.userSearchError.set('');
    this.selectedUsuarioNombre.set('');
    this.selectedUsuarioEmail.set('');
    this.selectedUsuarioTelefono.set('');
    this.originalAreas.set([]);
    this.formOpen.set(true);
  }

  closeForm(): void {
    this.formOpen.set(false);
  }

  filteredAreas(): Area[] {
    const f = this.areaFilter.trim().toLowerCase();
    if (!f) return this.areas();
    return this.areas().filter((a: Area) => a.nombre.toLowerCase().includes(f));
  }

  toggleAllAreas(mark: boolean): void {
    const visibles = this.filteredAreas().map((a: Area) => a.id);
    if (mark) {
      const set = new Set<number>([...this.form.areas, ...visibles]);
      this.form.areas = Array.from(set);
    } else {
      // No quitamos las originales
      const visiblesSet = new Set(visibles);
      const originales = new Set(this.originalAreas());
      this.form.areas = this.form.areas.filter(id => {
        if (originales.has(id)) return true;
        return !visiblesSet.has(id);
      });
    }
  }

  toggleArea(id: number, ev: Event): void {
    const checked = (ev.target as HTMLInputElement).checked;
    const esOriginal = this.originalAreas().includes(id);

    // Si es un área original y estamos en edición, no dejamos desmarcar directo
    if (!checked && this.editingId() !== null && esOriginal) {
      if (!this.form.areas.includes(id)) {
        this.form.areas.push(id);
      }
      this.openRemoveAreasModal([id]);
      return;
    }

    if (checked && !this.form.areas.includes(id)) {
      this.form.areas.push(id);
    }
    if (!checked && !esOriginal) {
      this.form.areas = this.form.areas.filter((x: number) => x !== id);
    }
  }

  edit(r: Row): void {
    this.editingId.set(r.id);
    const areasIds = r.areas.map((a: Area) => a.id);
    this.form = {
      usuario_id: r.usuario_id ?? null,
      nombre: r.nombre,
      email: r.email,
      telefono: r.telefono,
      areas: [...areasIds],
      activo: r.activo
    };
    this.originalAreas.set([...areasIds]);
    this.areaFilter = '';
    this.errorMsg.set('');
    this.successMsg.set('');
    this.tempPasswordModal.set('');
    this.userSearchTerm = '';
    this.userResults.set([]);
    this.userSearchError.set('');

    this.selectedUsuarioNombre.set(r.nombre);
    this.selectedUsuarioEmail.set(r.email);
    this.selectedUsuarioTelefono.set(r.telefono);

    this.formOpen.set(true);
  }

  // ======================= Búsqueda y selección de usuario =======================

  buscarUsuarios(): void {
    const term = this.userSearchTerm.trim();
    if (!term) {
      this.userResults.set([]);
      this.userSearchError.set('');
      return;
    }

    this.userSearchLoading.set(true);
    this.userSearchError.set('');
    this.userResults.set([]);

    this.api
      .get(`/admin/responsables/usuarios-buscar?q=${encodeURIComponent(term)}`)
      .subscribe(
        (value: unknown) => {
          const res = value as BuscarUsuariosResponse;
          const data = res?.data ?? [];
          this.userResults.set(data);
          if (!data.length) {
            this.userSearchError.set('No se encontraron usuarios con ese criterio.');
          }
          this.userSearchLoading.set(false);
        },
        () => {
          this.userSearchError.set('No se pudo buscar usuarios. Intenta nuevamente.');
          this.userSearchLoading.set(false);
        }
      );
  }

  seleccionarUsuario(u: UsuarioLite): void {
    this.form.usuario_id = u.id;

    if (u.responsable) {
      // MODO EDICIÓN AUTOMÁTICO
      this.editingId.set(u.responsable.id);
      const ids = (u.responsable.areas || []).map(a => a.id);
      this.form.nombre = u.responsable.nombre;
      this.form.email = u.responsable.email;
      this.form.telefono = u.responsable.telefono || '';
      this.form.areas = [...ids];
      this.form.activo = u.responsable.activo;
      this.originalAreas.set([...ids]);

      this.successMsg.set('Este usuario ya es responsable. Estás editando sus áreas asignadas.');
    } else {
      // Nuevo responsable asociado a este usuario
      this.editingId.set(null);
      this.form.nombre = u.nombre;
      this.form.email = u.email;
      this.form.telefono = u.telefono || '';
      this.form.areas = [];
      this.form.activo = true;
      this.originalAreas.set([]);
      this.successMsg.set('');
    }

    this.selectedUsuarioNombre.set(u.nombre);
    this.selectedUsuarioEmail.set(u.email);
    this.selectedUsuarioTelefono.set(u.telefono || '');

    this.userResults.set([]);
    this.userSearchError.set('');
  }

  desvincularUsuario(): void {
    this.form.usuario_id = null;
    this.selectedUsuarioNombre.set('');
    this.selectedUsuarioEmail.set('');
    this.selectedUsuarioTelefono.set('');
    // seguimos en modo edición de responsable, sólo sin vínculo
  }

  // ======================= Guardado =======================

  private buildPayload() {
    return {
      usuario_id: this.form.usuario_id,
      nombre: this.form.nombre.trim(),
      email: this.form.email.trim(),
      telefono: this.form.telefono.trim(),
      areas: this.form.areas.slice(),
      activo: this.form.activo,
    };
  }

  save(): void {
    if (!this.form.nombre.trim() || !this.form.email.trim() || !this.form.telefono.trim()) {
      this.errorMsg.set('Completa los campos obligatorios.');
      return;
    }
    if (!/^[0-9]+$/.test(this.form.telefono.trim())) {
      this.errorMsg.set('El teléfono debe contener sólo números.');
      return;
    }
    if (!this.form.areas.length) {
      this.errorMsg.set('Debe asignar al menos un área.');
      return;
    }

    this.saving.set(true);
    this.errorMsg.set('');
    this.successMsg.set('');

    const payload = this.buildPayload();

    if (this.editingId() === null) {
      // CREATE
      this.api.post('/admin/responsables', payload).subscribe(
        (value: unknown) => {
          const res = value as SaveResponse;
          if (res && res.ok) {
            this.successMsg.set(res.message || 'Responsable creado correctamente.');
            this.search();
            if (res.password_temporal) {
              this.tempPassword.set(res.password_temporal);
              this.tempPasswordModal.set(res.password_temporal);
            }
            setTimeout(() => this.closeForm(), 450);
          } else {
            this.errorMsg.set((res && res.message) || 'No se pudo guardar.');
          }
          this.saving.set(false);
        },
        (err: any) => {
          const msg = err?.error?.message || 'Error al guardar.';
          this.errorMsg.set(msg);
          this.saving.set(false);
        }
      );
    } else {
      // UPDATE
      const id = this.editingId() as number;
      this.api.put(`/admin/responsables/${id}`, payload).subscribe(
        (value: unknown) => {
          const res = value as SaveResponse;
          if (res && res.ok) {
            this.successMsg.set(res.message || 'Responsable actualizado.');
            this.search();
            const areasIds = this.form.areas.slice();
            this.originalAreas.set(areasIds);
            setTimeout(() => this.closeForm(), 450);
          } else {
            this.errorMsg.set((res && res.message) || 'No se pudo guardar.');
          }
          this.saving.set(false);
        },
        (err: any) => {
          const msg = err?.error?.message || 'Error al guardar.';
          this.errorMsg.set(msg);
          this.saving.set(false);
        }
      );
    }
  }

  remove(r: Row): void {
    if (!confirm(`¿Quitar rol de responsable a "${r.nombre}"?`)) return;
    this.api.delete(`/admin/responsables/${r.id}`).subscribe(
      (value: unknown) => {
        const res = value as OkResponse;
        if (res && res.ok) {
          this.search();
        } else if (res && res.message) {
          alert(res.message);
        }
      },
      (err: any) => {
        const msg = err?.error?.message || 'No se pudo quitar el rol.';
        alert(msg);
      }
    );
  }

  resetPassword(id: number): void {
    this.api.post(`/admin/responsables/${id}/reset-password`, {}).subscribe(
      (value: unknown) => {
        const res = value as { ok: boolean; message?: string; password_temporal?: string };
        if (res && res.ok && res.password_temporal) {
          this.tempPassword.set(res.password_temporal);
          this.tempPasswordModal.set(res.password_temporal);
        }
      },
      () => {}
    );
  }

  copyTempPassword(): void {
    const val = this.tempPassword();
    if (!val) return;
    this.copyText(val);
  }

  copyText(text: string): void {
    if (!text) return;
    if (navigator && 'clipboard' in navigator) {
      void navigator.clipboard.writeText(text);
    }
  }

  clearTempPassword(): void {
    this.tempPassword.set('');
  }

  // ======================= Modal remover áreas =======================

  areasOriginalesDetalladas(): Area[] {
    const set = new Set(this.originalAreas());
    return this.areas().filter(a => set.has(a.id));
  }

  openRemoveAreasModal(preselect?: number[]): void {
    if (!this.editingId()) return;
    const originales = this.originalAreas();
    if (!originales.length) return;

    const baseSeleccion = preselect && preselect.length
      ? originales.filter(id => preselect.includes(id))
      : [];

    this.removeSeleccion.set(baseSeleccion);
    this.removeMotivo.set('');
    this.removeError.set(null);
    this.removeOpen.set(true);
  }

  closeRemoveAreasModal(): void {
    if (this.removeSaving()) return;
    this.removeOpen.set(false);
    this.removeSeleccion.set([]);
    this.removeMotivo.set('');
    this.removeError.set(null);
  }

  toggleRemoveArea(id: number, ev: Event): void {
    const checked = (ev.target as HTMLInputElement).checked;
    const current = new Set(this.removeSeleccion());
    if (checked) current.add(id);
    else current.delete(id);
    this.removeSeleccion.set(Array.from(current));
  }

  canSubmitRemove(): boolean {
    if (!this.editingId()) return false;
    if (!this.removeSeleccion().length) return false;
    const motivo = (this.removeMotivo() || '').trim();
    if (motivo.length < 5) return false;
    return true;
  }

  submitRemoveAreas(): void {
    if (!this.canSubmitRemove() || this.removeSaving()) return;

    const id = this.editingId();
    if (!id) return;

    const payload = {
      areas_remover: this.removeSeleccion(),
      motivo: (this.removeMotivo() || '').trim(),
    };

    this.removeSaving.set(true);
    this.removeError.set(null);

    this.api.post(`/admin/responsables/${id}/remover-areas`, payload).subscribe({
      next: (value: unknown) => {
        const res = value as OkResponse;
        if (!res.ok) {
          this.removeError.set(res.message || 'No se pudieron quitar las áreas.');
          this.removeSaving.set(false);
          return;
        }

        const remover = new Set(this.removeSeleccion());
        this.form.areas = this.form.areas.filter(id2 => !remover.has(id2));
        this.originalAreas.set(this.originalAreas().filter(id2 => !remover.has(id2)));

        this.successMsg.set(res.message || 'Áreas desvinculadas correctamente.');
        this.search();
        this.removeSaving.set(false);
        this.closeRemoveAreasModal();
      },
      error: (err: any) => {
        const msg = err?.error?.message || 'No se pudieron quitar las áreas.';
        this.removeError.set(msg);
        this.removeSaving.set(false);
      }
    });
  }
}
