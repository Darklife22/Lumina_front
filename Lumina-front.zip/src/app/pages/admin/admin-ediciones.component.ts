// src/app/pages/admin/ediciones.component.ts
import { Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../../core/api.service';

type EstadoEdicion = 'borrador' | 'activa' | 'cerrada';

type Edicion = {
  id: number;
  anio: number;
  nombre_oficial: string;
  fecha_inicio: string; // YYYY-MM-DD
  fecha_fin: string; // YYYY-MM-DD
  estado: EstadoEdicion;
  created_at?: string;

  stats?: {
    areas?: number;
    niveles?: number;
    evaluadores?: number;
    responsables?: number;
    inscritos?: number;
  };

  locked?: boolean;
};

type Area = {
  id: number;
  nombre: string;
  codigo?: string | null;
  activa?: boolean;
};

type Nivel = {
  id: number;
  nombre: string;
  codigo?: string | null;
  activo?: boolean;
};

type EtapaKey = 'fase1' | 'clasificados' | 'final' | 'medalleria';

type Etapa = {
  key: EtapaKey;
  nombre: string;
  orden: number;
  inicio?: string;
  fin?: string;
  habilitada: boolean;
};

type ReglaClasificacion = {
  tipo: 'umbral' | 'top_n' | 'mixta';
  umbral_min?: number | null;
  top_n?: number | null;
  nota_min_aprob?: number | null;
};

type FormCompetencia = {
  anio: number;
  nombre_oficial: string;
  fecha_inicio: string;
  fecha_fin: string;
  estado: EstadoEdicion;

  heredarDeId: number | null;

  // áreas seleccionadas
  areasIds: number[];

  // 🔑 niveles por área: areaId -> nivelIds[]
  areaNivelIds: Record<number, number[]>;

  etapas: Etapa[];
  regla: ReglaClasificacion;
};

type EditForm = {
  id: number;
  anio: number;
  nombre_oficial: string;
  fecha_inicio: string;
  fecha_fin: string;
  estado: EstadoEdicion;
};

type ApiOk<T> = { ok: true; data: T };
type ApiErr = { ok: false; message?: string; errors?: any; error?: any };

@Component({
  standalone: true,
  selector: 'app-admin-ediciones',
  imports: [CommonModule, FormsModule],
  template: `
  <section class="space-y-4">

    <!-- Header -->
    <div class="bg-white border border-slate-200 rounded-2xl p-4 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
      <div class="min-w-0">
        <h2 class="text-lg font-bold truncate">Competencias / Ediciones</h2>
        <p class="text-sm text-slate-500 -mt-0.5">
          Gestión operativa: alta, configuración por edición, roles, inscritos y KPIs.
        </p>
      </div>

      <div class="flex items-center gap-2">
        <button
          (click)="openWizard()"
          class="inline-flex items-center gap-2 rounded-xl bg-[#0f3f94] hover:bg-[#0d3580] text-white px-4 py-2 text-sm font-semibold shadow-sm">
          <i class="bi bi-plus-circle"></i>
          <span>Nueva competencia</span>
        </button>

        <button
          (click)="cargarEdiciones()"
          class="inline-flex items-center gap-2 rounded-xl bg-white border border-slate-200 hover:bg-slate-50 px-4 py-2 text-sm font-semibold">
          <i class="bi bi-arrow-repeat"></i>
          <span>Actualizar</span>
        </button>
      </div>
    </div>

    <!-- Filtros -->
    <div class="bg-white border border-slate-200 rounded-2xl p-4">
      <div class="grid gap-3 md:grid-cols-4 items-end">
        <div class="md:col-span-2">
          <label class="text-xs font-semibold text-slate-500">Buscar</label>
          <input
            [(ngModel)]="q"
            (keyup.enter)="applyFilter()"
            placeholder="Año, nombre, estado..."
            class="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm outline-none
                   focus:ring-2 focus:ring-blue-200 focus:border-blue-300">
        </div>

        <div>
          <label class="text-xs font-semibold text-slate-500">Estado</label>
          <select
            [(ngModel)]="estadoFilter"
            (ngModelChange)="applyFilter()"
            class="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm">
            <option [ngValue]="''">Todos</option>
            <option [ngValue]="'borrador'">Borrador</option>
            <option [ngValue]="'activa'">Activa</option>
            <option [ngValue]="'cerrada'">Cerrada</option>
          </select>
        </div>

        <div class="flex gap-2">
          <button
            (click)="applyFilter()"
            class="rounded-xl bg-[#0f3f94] hover:bg-[#0d3580] text-white px-3 py-2 text-sm w-full font-semibold">
            <i class="bi bi-search"></i> Filtrar
          </button>
          <button
            (click)="clearFilter()"
            class="rounded-xl bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50 w-full font-semibold">
            Limpiar
          </button>
        </div>
      </div>
    </div>

    <!-- Lista -->
    <div class="bg-white border border-slate-200 rounded-2xl p-0 overflow-hidden">
      <div class="p-3 border-b border-slate-200 flex items-center justify-between">
        <div class="font-semibold">Ediciones registradas</div>
        <div class="text-xs text-slate-500">
          {{ filtered().length }} / {{ ediciones().length }} ediciones
        </div>
      </div>

      <div *ngIf="loadingLista()" class="py-10 text-center text-slate-400 text-sm">
        Cargando competencias...
      </div>

      <div *ngIf="!loadingLista() && filtered().length === 0" class="py-10 text-center text-slate-400 text-sm">
        No hay ediciones para mostrar.
      </div>

      <div *ngIf="!loadingLista() && filtered().length > 0" class="overflow-x-auto">
        <table class="min-w-full text-sm">
          <thead class="bg-slate-50">
            <tr class="text-left text-slate-600">
              <th class="py-2 px-3">Año</th>
              <th class="py-2 px-3">Competencia</th>
              <th class="py-2 px-3">Fechas</th>
              <th class="py-2 px-3">Estado</th>
              <th class="py-2 px-3">KPIs</th>
              <th class="py-2 px-3">Acciones</th>
            </tr>
          </thead>

          <tbody>
            <tr *ngFor="let e of filtered()" class="border-t border-slate-100 hover:bg-slate-50/60">
              <td class="py-2 px-3 font-semibold">{{ e.anio }}</td>

              <td class="py-2 px-3">
                <div class="font-medium text-slate-800 flex items-center gap-2">
                  <span class="truncate">{{ e.nombre_oficial }}</span>
                  <span *ngIf="isEditionHardLocked(e)"
                        class="text-[10px] px-2 py-0.5 rounded-full border bg-slate-50 text-slate-600 font-semibold">
                    Bloqueada
                  </span>
                </div>
                <div class="text-[11px] text-slate-500">
                  ID: {{ e.id }} • Creado: {{ e.created_at ? (e.created_at | date:'yyyy-MM-dd HH:mm') : '—' }}
                </div>
              </td>

              <td class="py-2 px-3 text-xs text-slate-700">
                <div>{{ e.fecha_inicio | date:'yyyy-MM-dd' }} – {{ e.fecha_fin | date:'yyyy-MM-dd' }}</div>
              </td>

              <td class="py-2 px-3">
                <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold border"
                      [ngClass]="estadoBadgeClass(e.estado)">
                  <span class="w-1.5 h-1.5 rounded-full mr-1.5"
                        [ngClass]="estadoDotClass(e.estado)"></span>
                  {{ labelEstado(e.estado) }}
                </span>
              </td>

              <td class="py-2 px-3 text-xs text-slate-600">
                <div class="flex flex-wrap gap-1">
                  <span class="px-2 py-0.5 rounded-full bg-slate-50 border border-slate-200">
                    Áreas: {{ e.stats?.areas ?? '—' }}
                  </span>
                  <span class="px-2 py-0.5 rounded-full bg-slate-50 border border-slate-200">
                    Niveles: {{ e.stats?.niveles ?? '—' }}
                  </span>
                  <span class="px-2 py-0.5 rounded-full bg-slate-50 border border-slate-200">
                    Inscritos: {{ e.stats?.inscritos ?? '—' }}
                  </span>
                </div>
              </td>

              <td class="py-2 px-3">
                <div class="flex flex-wrap gap-2 text-xs">
                  <button
                    (click)="goConfig(e)"
                    class="inline-flex items-center gap-1 px-2 py-1 rounded-xl border border-slate-200 hover:bg-slate-50 font-semibold">
                    <i class="bi bi-sliders"></i> Configurar
                  </button>

                  <button
                    (click)="openEdit(e)"
                    class="inline-flex items-center gap-1 px-2 py-1 rounded-xl border border-slate-200 hover:bg-slate-50 font-semibold">
                    <i class="bi bi-pencil-square"></i> Editar
                  </button>

                  <button
                    (click)="goRoles(e)"
                    class="inline-flex items-center gap-1 px-2 py-1 rounded-xl border border-slate-200 hover:bg-slate-50 font-semibold">
                    <i class="bi bi-people"></i> Roles
                  </button>

                  <button
                    (click)="goInscritos(e)"
                    class="inline-flex items-center gap-1 px-2 py-1 rounded-xl border border-slate-200 hover:bg-slate-50 font-semibold">
                    <i class="bi bi-person-lines-fill"></i> Inscritos
                  </button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- ===================== WIZARD CREACIÓN ===================== -->
    <div *ngIf="wizardOpen()" class="fixed inset-0 z-50 flex items-center justify-center">
      <div class="absolute inset-0 bg-black/50" (click)="closeWizard()"></div>

      <div class="relative bg-white rounded-2xl shadow-xl w-full max-w-5xl mx-4 overflow-hidden">
        <div class="p-4 border-b border-slate-200 flex items-start justify-between gap-3">
          <div class="min-w-0">
            <div class="text-sm font-semibold">Nueva competencia</div>
            <div class="text-xs text-slate-500">
              Alta controlada: estructura mínima + reglas base + etapas para empezar a operar.
            </div>
          </div>
          <button
            class="w-9 h-9 rounded-xl border border-slate-200 hover:bg-slate-50 flex-none"
            (click)="closeWizard()">
            <i class="bi bi-x"></i>
          </button>
        </div>

        <div class="px-4 pt-4">
          <div class="flex flex-wrap gap-2">
            <span class="px-2 py-1 rounded-full text-xs border font-semibold"
                  [ngClass]="step()===1 ? 'bg-blue-50 border-blue-200 text-blue-700' : 'bg-white border-slate-200 text-slate-600'">
              1) Datos base
            </span>
            <span class="px-2 py-1 rounded-full text-xs border font-semibold"
                  [ngClass]="step()===2 ? 'bg-blue-50 border-blue-200 text-blue-700' : 'bg-white border-slate-200 text-slate-600'">
              2) Estructura
            </span>
            <span class="px-2 py-1 rounded-full text-xs border font-semibold"
                  [ngClass]="step()===3 ? 'bg-blue-50 border-blue-200 text-blue-700' : 'bg-white border-slate-200 text-slate-600'">
              3) Etapas
            </span>
            <span class="px-2 py-1 rounded-full text-xs border font-semibold"
                  [ngClass]="step()===4 ? 'bg-blue-50 border-blue-200 text-blue-700' : 'bg-white border-slate-200 text-slate-600'">
              4) Reglas
            </span>
          </div>
        </div>

        <div class="p-4 max-h-[72dvh] overflow-y-auto">

          <!-- STEP 1 -->
          <div *ngIf="step()===1" class="space-y-3">
            <div class="grid md:grid-cols-4 gap-3">
              <div>
                <label class="text-xs font-semibold text-slate-500">Año *</label>
                <input type="number" min="2000" [(ngModel)]="form.anio"
                       class="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm">
              </div>
              <div class="md:col-span-2">
                <label class="text-xs font-semibold text-slate-500">Nombre oficial *</label>
                <input [(ngModel)]="form.nombre_oficial"
                       placeholder='Ej: "Olimpiada 2026 – Ciencia y Tecnología"'
                       class="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm">
              </div>
              <div>
                <label class="text-xs font-semibold text-slate-500">Estado inicial</label>
                <select [(ngModel)]="form.estado"
                        class="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm">
                  <option [ngValue]="'borrador'">borrador</option>
                  <option [ngValue]="'activa'">activa</option>
                  <option [ngValue]="'cerrada'">cerrada</option>
                </select>
              </div>
            </div>

            <div class="grid md:grid-cols-4 gap-3">
              <div class="md:col-span-2">
                <label class="text-xs font-semibold text-slate-500">Fecha inicio *</label>
                <input type="date" [(ngModel)]="form.fecha_inicio"
                       class="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm">
              </div>
              <div class="md:col-span-2">
                <label class="text-xs font-semibold text-slate-500">Fecha fin *</label>
                <input type="date" [(ngModel)]="form.fecha_fin"
                       class="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm">
              </div>
            </div>

            <div class="rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs text-slate-600">
              Gobernanza: inicia en <strong>borrador</strong>. Una vez que haya inscritos/operación, la estructura se bloquea para evitar inconsistencia.
            </div>
          </div>

          <!-- STEP 2 -->
          <div *ngIf="step()===2" class="space-y-3">

            <!-- Heredar -->
            <div class="rounded-2xl border border-slate-200 p-4 bg-white">
              <div class="text-sm font-semibold">Heredar estructura base</div>
              <div class="text-xs text-slate-500">
                Copia estructura desde una edición anterior (sin inscritos ni resultados).
              </div>

              <div class="mt-3">
                <select [(ngModel)]="form.heredarDeId"
                        (ngModelChange)="onChangeHeredar()"
                        class="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm">
                  <option [ngValue]="null">— Crear estructura nueva —</option>
                  <option *ngFor="let e of ediciones()" [ngValue]="e.id">
                    {{ e.anio }} — {{ e.nombre_oficial }}
                  </option>
                </select>

                <div class="text-[11px] text-slate-500 mt-2" *ngIf="form.heredarDeId">
                  Origen: <strong>{{ edicionOrigenLabel() }}</strong>
                </div>

                <div class="mt-3 rounded-xl border border-amber-200 bg-amber-50 p-3 text-xs text-amber-800">
                  Si heredas, la selección de áreas y niveles queda administrada por el origen.
                </div>
              </div>
            </div>

            <!-- Áreas + Niveles (lado a lado) -->
            <div class="grid lg:grid-cols-2 gap-4">

              <!-- Áreas -->
              <div class="rounded-2xl border border-slate-200 p-4 bg-white">
                <div class="flex items-center justify-between">
                  <div class="text-sm font-semibold">Áreas</div>
                  <div class="text-xs text-slate-500">{{ form.areasIds.length }} seleccionadas</div>
                </div>

                <div class="mt-3">
                  <input
                    [(ngModel)]="areaSearch"
                    [disabled]="!!form.heredarDeId"
                    placeholder="Buscar área..."
                    class="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm outline-none
                           focus:ring-2 focus:ring-blue-200 focus:border-blue-300
                           disabled:bg-slate-50 disabled:text-slate-400">
                </div>

                <div class="mt-3 max-h-80 overflow-y-auto space-y-2">
                  <div *ngIf="loadingAreas()" class="py-6 text-center text-sm text-slate-400">
                    Cargando áreas...
                  </div>

                  <div *ngIf="!loadingAreas() && filteredAreas().length===0" class="py-6 text-center text-sm text-slate-400">
                    No hay áreas disponibles.
                  </div>

                  <div *ngFor="let a of filteredAreas()"
                       class="rounded-2xl border border-slate-200 px-3 py-3 hover:bg-slate-50">
                    <div class="flex items-center justify-between gap-3">
                      <button
                        type="button"
                        class="min-w-0 text-left"
                        (click)="selectWizardArea(a.id)"
                        [disabled]="!!form.heredarDeId || !form.areasIds.includes(a.id)">
                        <div class="text-sm font-semibold text-slate-900 truncate">{{ a.nombre }}</div>
                        <div class="text-[11px] text-slate-500">
                          ID {{ a.id }}
                          <span *ngIf="a.codigo">· {{ a.codigo }}</span>
                          <span *ngIf="form.areasIds.includes(a.id)">· Niveles: <strong>{{ countAssignedLevels(a.id) }}</strong></span>
                        </div>
                      </button>

                      <div class="flex items-center gap-2 flex-none">
                        <button
                          type="button"
                          class="rounded-xl border border-slate-200 px-3 py-1.5 text-xs font-semibold hover:bg-white"
                          (click)="selectWizardArea(a.id)"
                          [disabled]="!!form.heredarDeId || !form.areasIds.includes(a.id)">
                          Configurar
                        </button>

                        <label class="text-xs inline-flex items-center gap-2 font-semibold text-slate-700">
                          <input
                            type="checkbox"
                            [disabled]="!!form.heredarDeId"
                            [checked]="form.areasIds.includes(a.id)"
                            (change)="toggleArea(a.id)">
                          Seleccionar
                        </label>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="mt-3 text-[11px] text-slate-500" *ngIf="!form.heredarDeId && form.areasIds.length===0">
                  Selecciona al menos 1 área para habilitar la asignación de niveles.
                </div>
              </div>

              <!-- Niveles por área -->
              <div class="rounded-2xl border border-slate-200 p-4 bg-white">
                <div class="flex items-center justify-between">
                  <div class="text-sm font-semibold">Niveles por área</div>
                  <div class="text-xs text-slate-500">
                    Área:
                    <strong>{{ wizardAreaSelectedLabel() || '—' }}</strong>
                  </div>
                </div>

                <div class="mt-3">
                  <input
                    [(ngModel)]="nivelSearch"
                    [disabled]="!!form.heredarDeId || !wizardAreaSelectedId()"
                    placeholder="Buscar nivel..."
                    class="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm outline-none
                           focus:ring-2 focus:ring-blue-200 focus:border-blue-300
                           disabled:bg-slate-50 disabled:text-slate-400">
                </div>

                <div class="mt-3 max-h-80 overflow-y-auto space-y-2">
                  <div *ngIf="loadingNiveles()" class="py-6 text-center text-sm text-slate-400">
                    Cargando niveles...
                  </div>

                  <div *ngIf="!loadingNiveles() && !wizardAreaSelectedId()" class="py-10 text-center text-sm text-slate-400">
                    Selecciona un área y luego presiona <strong>Configurar</strong>.
                  </div>

                  <div *ngIf="!loadingNiveles() && wizardAreaSelectedId() && filteredNiveles().length===0"
                       class="py-10 text-center text-sm text-slate-400">
                    No hay niveles para mostrar.
                  </div>

                  <div *ngFor="let n of filteredNiveles()"
                       class="rounded-2xl border border-slate-200 px-3 py-3 hover:bg-slate-50">
                    <div class="flex items-center justify-between gap-3">
                      <div class="min-w-0">
                        <div class="text-sm font-semibold text-slate-900 truncate">{{ n.nombre }}</div>
                        <div class="text-[11px] text-slate-500">
                          ID {{ n.id }} <span *ngIf="n.codigo">· {{ n.codigo }}</span>
                        </div>
                      </div>

                      <label class="text-xs inline-flex items-center gap-2 font-semibold text-slate-700 flex-none">
                        <input
                          type="checkbox"
                          [disabled]="!!form.heredarDeId || !wizardAreaSelectedId()"
                          [checked]="isNivelAssignedToSelectedArea(n.id)"
                          (change)="toggleNivelForSelectedArea(n.id)">
                        Asignar
                      </label>
                    </div>
                  </div>
                </div>

                <div class="mt-3 rounded-xl border border-slate-200 bg-slate-50 p-3 text-[11px] text-slate-600"
                     *ngIf="wizardAreaSelectedId()">
                  Asignados a <strong>{{ wizardAreaSelectedLabel() }}</strong>:
                  <strong>{{ countAssignedLevels(wizardAreaSelectedId()!) }}</strong> niveles.
                </div>
              </div>

            </div>

          </div>

          <!-- STEP 3 -->
          <div *ngIf="step()===3" class="space-y-3">
            <div class="rounded-xl border border-slate-200 p-4">
              <div class="text-sm font-semibold">Etapas del flujo competitivo</div>
              <div class="text-xs text-slate-500">
                Journey estándar: fase 1 → clasificados → final → medallería.
              </div>

              <div class="mt-3 grid md:grid-cols-2 gap-3">
                <div *ngFor="let et of form.etapas" class="rounded-xl border border-slate-200 p-3">
                  <div class="flex items-center justify-between">
                    <div class="font-semibold text-sm">{{ et.nombre }}</div>
                    <label class="text-xs flex items-center gap-2 font-semibold text-slate-600">
                      <input type="checkbox" [(ngModel)]="et.habilitada">
                      Habilitada
                    </label>
                  </div>

                  <div class="grid grid-cols-2 gap-2 mt-2">
                    <div>
                      <label class="text-[11px] font-semibold text-slate-500">Inicio (opcional)</label>
                      <input type="date" [(ngModel)]="et.inicio"
                             class="w-full rounded-xl border border-slate-300 px-2 py-1.5 text-xs">
                    </div>
                    <div>
                      <label class="text-[11px] font-semibold text-slate-500">Fin (opcional)</label>
                      <input type="date" [(ngModel)]="et.fin"
                             class="w-full rounded-xl border border-slate-300 px-2 py-1.5 text-xs">
                    </div>
                  </div>

                  <div class="text-[11px] text-slate-500 mt-2">
                    Orden: {{ et.orden }} • Key: {{ et.key }}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- STEP 4 -->
          <div *ngIf="step()===4" class="space-y-3">
            <div class="rounded-xl border border-slate-200 p-4">
              <div class="text-sm font-semibold">Reglas de clasificación (base)</div>
              <div class="text-xs text-slate-500">
                Regla por defecto. Luego se parametriza por área y nivel.
              </div>

              <div class="grid md:grid-cols-4 gap-3 mt-3">
                <div class="md:col-span-2">
                  <label class="text-xs font-semibold text-slate-500">Tipo de regla</label>
                  <select [(ngModel)]="form.regla.tipo"
                          class="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm">
                    <option [ngValue]="'umbral'">Umbral (mínimo de puntaje)</option>
                    <option [ngValue]="'top_n'">Top N (ranking)</option>
                    <option [ngValue]="'mixta'">Mixta (umbral + top N)</option>
                  </select>
                </div>

                <div>
                  <label class="text-xs font-semibold text-slate-500">Umbral mínimo</label>
                  <input type="number" [(ngModel)]="form.regla.umbral_min"
                         class="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm"
                         placeholder="Ej: 60">
                </div>

                <div>
                  <label class="text-xs font-semibold text-slate-500">Top N</label>
                  <input type="number" [(ngModel)]="form.regla.top_n"
                         class="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm"
                         placeholder="Ej: 10">
                </div>

                <div class="md:col-span-2">
                  <label class="text-xs font-semibold text-slate-500">Nota mínima de aprobación</label>
                  <input type="number" [(ngModel)]="form.regla.nota_min_aprob"
                         class="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm"
                         placeholder="Ej: 51">
                </div>
              </div>
            </div>

            <div *ngIf="wizardError()" class="rounded-xl border border-red-200 bg-red-50 text-red-700 px-3 py-2 text-sm font-semibold">
              {{ wizardError() }}
            </div>

            <div *ngIf="wizardOk()" class="rounded-xl border border-emerald-200 bg-emerald-50 text-emerald-700 px-3 py-2 text-sm font-semibold">
              Competencia creada. Redireccionando...
            </div>
          </div>

        </div>

        <div class="p-4 border-t border-slate-200 flex items-center justify-between">
          <button
            class="rounded-xl bg-white border border-slate-200 px-4 py-2 text-sm hover:bg-slate-50 font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
            (click)="prevStep()"
            [disabled]="step()===1 || creating()">
            <i class="bi bi-chevron-left"></i> Atrás
          </button>

          <div class="flex items-center gap-2">
            <button
              class="rounded-xl bg-white border border-slate-200 px-4 py-2 text-sm hover:bg-slate-50 font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
              (click)="closeWizard()"
              [disabled]="creating()">
              Cancelar
            </button>

            <button
              *ngIf="step() < 4"
              class="rounded-xl bg-[#0f3f94] hover:bg-[#0d3580] text-white px-4 py-2 text-sm font-semibold disabled:opacity-60 disabled:cursor-not-allowed"
              (click)="nextStep()"
              [disabled]="creating()">
              Siguiente <i class="bi bi-chevron-right"></i>
            </button>

            <button
              *ngIf="step() === 4"
              class="rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 text-sm font-semibold disabled:opacity-60 disabled:cursor-not-allowed"
              (click)="crearCompetencia()"
              [disabled]="creating()">
              <ng-container *ngIf="!creating(); else creatingTpl">
                <i class="bi bi-check2-circle"></i> Crear competencia
              </ng-container>
            </button>

            <ng-template #creatingTpl>
              <span class="inline-flex items-center gap-2 font-semibold">
                <span class="inline-block h-4 w-4 border-2 border-white/60 border-t-white rounded-full animate-spin"></span>
                Creando...
              </span>
            </ng-template>
          </div>
        </div>
      </div>
    </div>

    <!-- ===================== MODAL EDITAR (CONTROLADO) ===================== -->
    <div *ngIf="editOpen()" class="fixed inset-0 z-50 flex items-center justify-center">
      <div class="absolute inset-0 bg-black/50" (click)="closeEdit()"></div>

      <div class="relative bg-white rounded-2xl shadow-xl w-full max-w-2xl mx-4 overflow-hidden">
        <div class="p-4 border-b border-slate-200 flex items-start justify-between gap-3">
          <div class="min-w-0">
            <div class="text-sm font-semibold">Editar competencia</div>
            <div class="text-xs text-slate-500">
              Edición controlada para mantener consistencia. La estructura se bloquea cuando hay dependencias.
            </div>
          </div>
          <button
            class="w-9 h-9 rounded-xl border border-slate-200 hover:bg-slate-50 flex-none"
            (click)="closeEdit()">
            <i class="bi bi-x"></i>
          </button>
        </div>

        <div class="p-4 space-y-4">
          <div *ngIf="editError()" class="rounded-xl border border-red-200 bg-red-50 text-red-700 px-3 py-2 text-sm font-semibold">
            {{ editError() }}
          </div>

          <div class="grid md:grid-cols-4 gap-3">
            <div>
              <label class="text-xs font-semibold text-slate-500">Año</label>
              <input type="number" [(ngModel)]="editForm.anio"
                     [disabled]="true"
                     class="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm bg-slate-50 text-slate-500">
            </div>
            <div class="md:col-span-3">
              <label class="text-xs font-semibold text-slate-500">Nombre oficial *</label>
              <input [(ngModel)]="editForm.nombre_oficial"
                     class="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm">
            </div>
          </div>

          <div class="grid md:grid-cols-3 gap-3">
            <div>
              <label class="text-xs font-semibold text-slate-500">Estado</label>
              <select [(ngModel)]="editForm.estado"
                      class="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm">
                <option [ngValue]="'borrador'">borrador</option>
                <option [ngValue]="'activa'">activa</option>
                <option [ngValue]="'cerrada'">cerrada</option>
              </select>
            </div>

            <div>
              <label class="text-xs font-semibold text-slate-500">Fecha inicio</label>
              <input type="date" [(ngModel)]="editForm.fecha_inicio"
                     [disabled]="editLocks.fecha"
                     class="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm"
                     [class.bg-slate-50]="editLocks.fecha"
                     [class.text-slate-500]="editLocks.fecha">
              <div *ngIf="editLocks.fecha" class="text-[11px] text-slate-500 mt-1">
                Bloqueado por gobernanza (estado/data dependiente).
              </div>
            </div>

            <div>
              <label class="text-xs font-semibold text-slate-500">Fecha fin</label>
              <input type="date" [(ngModel)]="editForm.fecha_fin"
                     [disabled]="editLocks.fecha"
                     class="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm"
                     [class.bg-slate-50]="editLocks.fecha"
                     [class.text-slate-500]="editLocks.fecha">
            </div>
          </div>

          <div class="rounded-xl border border-amber-200 bg-amber-50 p-3 text-xs text-amber-800">
            <strong>Nota:</strong> la edición de <strong>Áreas</strong>, <strong>Niveles</strong> y reglas detalladas se gestiona en
            <strong>Configurar</strong> (pantalla scoped por edición), y se bloqueará automáticamente cuando existan datos dependientes.
          </div>
        </div>

        <div class="p-4 border-t border-slate-200 flex items-center justify-end gap-2">
          <button
            class="rounded-xl bg-white border border-slate-200 px-4 py-2 text-sm hover:bg-slate-50 font-semibold"
            (click)="closeEdit()">
            Cancelar
          </button>

          <button
            class="rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 text-sm font-semibold disabled:opacity-60 disabled:cursor-not-allowed"
            (click)="saveEdit()"
            [disabled]="savingEdit()">
            <ng-container *ngIf="!savingEdit(); else savingEditTpl">
              Guardar cambios
            </ng-container>
          </button>

          <ng-template #savingEditTpl>
            <span class="inline-flex items-center gap-2 font-semibold">
              <span class="inline-block h-4 w-4 border-2 border-white/60 border-t-white rounded-full animate-spin"></span>
              Guardando...
            </span>
          </ng-template>
        </div>
      </div>
    </div>

  </section>
  `,
})
export class AdminEdicionesComponent {
  private api = inject(ApiService);
  private router = inject(Router);

  ediciones = signal<Edicion[]>([]);
  loadingLista = signal(false);

  // catálogos
  areas = signal<Area[]>([]);
  niveles = signal<Nivel[]>([]);
  loadingAreas = signal(false);
  loadingNiveles = signal(false);

  areaSearch = '';
  nivelSearch = '';

  filteredAreas = computed(() => {
    const q = (this.areaSearch || '').trim().toLowerCase();
    const all = this.areas() || [];
    if (!q) return all;
    return all.filter(a =>
      (a.nombre || '').toLowerCase().includes(q) ||
      (a.codigo || '').toLowerCase().includes(q)
    );
  });

  filteredNiveles = computed(() => {
    const q = (this.nivelSearch || '').trim().toLowerCase();
    const all = this.niveles() || [];
    if (!q) return all;
    return all.filter(n =>
      `${n.id} ${n.nombre} ${n.codigo ?? ''}`.toLowerCase().includes(q)
    );
  });

  // filtros
  q = '';
  estadoFilter: '' | EstadoEdicion = '';

  filtered = computed(() => {
    const all = this.ediciones() || [];
    const q = this.q.trim().toLowerCase();
    const ef = (this.estadoFilter || '').toLowerCase();

    return all.filter((e) => {
      const okEstado = !ef || String(e.estado || '').toLowerCase() === ef;
      if (!q) return okEstado;

      const hay =
        String(e.anio).includes(q) ||
        (e.nombre_oficial || '').toLowerCase().includes(q) ||
        (e.estado || '').toLowerCase().includes(q);

      return okEstado && hay;
    });
  });

  // wizard
  wizardOpen = signal(false);
  step = signal<1 | 2 | 3 | 4>(1);
  creating = signal(false);
  wizardError = signal<string | null>(null);
  wizardOk = signal(false);

  // área seleccionada para asignar niveles
  wizardAreaSelectedId = signal<number | null>(null);

  form: FormCompetencia = this.defaultForm();

  // edición (modal editar)
  editOpen = signal(false);
  savingEdit = signal(false);
  editError = signal<string | null>(null);
  editTarget = signal<Edicion | null>(null);

  editLocks = { fecha: false };

  editForm: EditForm = {
    id: 0,
    anio: new Date().getFullYear(),
    nombre_oficial: '',
    fecha_inicio: new Date().toISOString().slice(0, 10),
    fecha_fin: new Date().toISOString().slice(0, 10),
    estado: 'borrador',
  };

  ngOnInit() {
    this.cargarEdiciones();
    this.cargarAreas();
    this.cargarNiveles();
  }

  defaultForm(): FormCompetencia {
    const y = new Date().getFullYear();
    const today = new Date().toISOString().slice(0, 10);

    const etapas: Etapa[] = [
      { key: 'fase1', nombre: '1ra Fase', orden: 1, habilitada: true },
      { key: 'clasificados', nombre: 'Clasificados', orden: 2, habilitada: true },
      { key: 'final', nombre: 'Final', orden: 3, habilitada: true },
      { key: 'medalleria', nombre: 'Medallería (Oro/Plata/Bronce)', orden: 4, habilitada: true },
    ];

    return {
      anio: y,
      nombre_oficial: '',
      fecha_inicio: today,
      fecha_fin: today,
      estado: 'borrador',

      heredarDeId: null,

      areasIds: [],
      areaNivelIds: {},

      etapas,
      regla: {
        tipo: 'mixta',
        umbral_min: 60,
        top_n: 10,
        nota_min_aprob: 51,
      },
    };
  }

  // ====================== DATA ======================
  cargarEdiciones() {
    this.loadingLista.set(true);
    this.api.get<{ ok: boolean; data: Edicion[] }>('/admin/ediciones').subscribe({
      next: (res) => {
        this.ediciones.set(res?.ok ? (res.data || []) : []);
        this.loadingLista.set(false);
      },
      error: () => {
        this.ediciones.set([]);
        this.loadingLista.set(false);
      },
    });
  }

  cargarAreas() {
    this.loadingAreas.set(true);
    this.api.get<ApiOk<Area[]> | ApiErr>('/admin/areas').subscribe({
      next: (res: any) => {
        this.areas.set(res?.ok ? (res.data || []) : []);
        this.loadingAreas.set(false);
      },
      error: () => {
        this.areas.set([]);
        this.loadingAreas.set(false);
      },
    });
  }

  cargarNiveles() {
    this.loadingNiveles.set(true);
    this.api.get<ApiOk<Nivel[]> | ApiErr>('/admin/niveles').subscribe({
      next: (res: any) => {
        this.niveles.set(res?.ok ? (res.data || []) : []);
        this.loadingNiveles.set(false);
      },
      error: () => {
        // si aún no tienes endpoint, quedará vacío (pero la UI no se rompe)
        this.niveles.set([]);
        this.loadingNiveles.set(false);
      },
    });
  }

  applyFilter() {}
  clearFilter() {
    this.q = '';
    this.estadoFilter = '';
  }

  // ====================== GOBERNANZA (LOCKS) ======================
  isEditionHardLocked(e: Edicion): boolean {
    if (e.locked === true) return true;
    if (e.estado === 'cerrada') return true;
    return false;
  }

  hasDependencies(e: Edicion): boolean {
    const inscritos = Number(e.stats?.inscritos ?? 0);
    return inscritos > 0;
  }

  canEditDates(e: Edicion): boolean {
    if (this.isEditionHardLocked(e)) return false;
    if (e.estado !== 'borrador') return false;
    if (this.hasDependencies(e)) return false;
    return true;
  }

  // ====================== WIZARD: ÁREAS + NIVELES ======================
  onChangeHeredar() {
    if (this.form.heredarDeId) {
      // se desactiva la edición local de estructura
      this.wizardAreaSelectedId.set(null);
      this.nivelSearch = '';
    }
  }

  toggleArea(areaId: number) {
    if (this.form.heredarDeId) return;

    const set = new Set(this.form.areasIds);
    if (set.has(areaId)) {
      set.delete(areaId);

      // limpieza de asignaciones
      delete this.form.areaNivelIds[areaId];

      if (this.wizardAreaSelectedId() === areaId) {
        const next = Array.from(set)[0] ?? null;
        this.wizardAreaSelectedId.set(next);
      }
    } else {
      set.add(areaId);
      // inicializamos estructura
      if (!Array.isArray(this.form.areaNivelIds[areaId])) this.form.areaNivelIds[areaId] = [];
      this.wizardAreaSelectedId.set(areaId);
    }

    this.form.areasIds = Array.from(set);
  }

  selectWizardArea(areaId: number) {
    if (this.form.heredarDeId) return;
    if (!this.form.areasIds.includes(areaId)) return;
    this.wizardAreaSelectedId.set(areaId);
    if (!Array.isArray(this.form.areaNivelIds[areaId])) this.form.areaNivelIds[areaId] = [];
  }

  wizardAreaSelectedLabel(): string {
    const id = this.wizardAreaSelectedId();
    if (!id) return '';
    const a = (this.areas() || []).find(x => x.id === id);
    return a ? a.nombre : `Área ${id}`;
  }

  isNivelAssignedToSelectedArea(nivelId: number): boolean {
    const aid = this.wizardAreaSelectedId();
    if (!aid) return false;
    const arr = this.form.areaNivelIds[aid] || [];
    return arr.includes(nivelId);
  }

  toggleNivelForSelectedArea(nivelId: number) {
    if (this.form.heredarDeId) return;
    const aid = this.wizardAreaSelectedId();
    if (!aid) return;

    const current = new Set(this.form.areaNivelIds[aid] || []);
    if (current.has(nivelId)) current.delete(nivelId);
    else current.add(nivelId);

    this.form.areaNivelIds[aid] = Array.from(current);
  }

  countAssignedLevels(areaId: number): number {
    return (this.form.areaNivelIds[areaId] || []).length;
  }

  // ====================== WIZARD FLOW ======================
  openWizard() {
    this.form = this.defaultForm();
    this.areaSearch = '';
    this.nivelSearch = '';
    this.step.set(1);
    this.wizardError.set(null);
    this.wizardOk.set(false);
    this.wizardAreaSelectedId.set(null);
    this.wizardOpen.set(true);

    // refrescar catálogos para consistencia operativa
    this.cargarAreas();
    this.cargarNiveles();
  }

  closeWizard() {
    if (this.creating()) return;
    this.wizardOpen.set(false);
  }

  prevStep() {
    this.wizardError.set(null);
    this.step.set(Math.max(1, (this.step() - 1)) as 1 | 2 | 3 | 4);
  }

  nextStep() {
    this.wizardError.set(null);

    const s = this.step();
    if (s === 1) {
      const err = this.validateStep1();
      if (err) return this.wizardError.set(err);
    }
    if (s === 2) {
      const err = this.validateStep2();
      if (err) return this.wizardError.set(err);
    }
    if (s === 3) {
      const err = this.validateStep3();
      if (err) return this.wizardError.set(err);
    }

    this.step.set(Math.min(4, (s + 1)) as 1 | 2 | 3 | 4);
  }

  validateStep1(): string | null {
    if (!this.form.anio || this.form.anio < 2000) return 'Año inválido.';
    if (!this.form.nombre_oficial.trim()) return 'El nombre oficial es obligatorio.';
    if (!this.form.fecha_inicio) return 'Fecha inicio es obligatoria.';
    if (!this.form.fecha_fin) return 'Fecha fin es obligatoria.';
    if (this.form.fecha_fin < this.form.fecha_inicio) return 'La fecha fin no puede ser menor que la fecha inicio.';
    return null;
  }

  validateStep2(): string | null {
    if (this.form.heredarDeId) return null;

    if (this.form.areasIds.length === 0) return 'Selecciona al menos 1 área (o elige “heredar”).';

    // Regla operativa: cada área seleccionada debe tener >= 1 nivel
    for (const aid of this.form.areasIds) {
      const assigned = this.form.areaNivelIds[aid] || [];
      if (!assigned.length) {
        const areaName = (this.areas() || []).find(x => x.id === aid)?.nombre ?? `Área ${aid}`;
        return `Asigna al menos 1 nivel para: ${areaName}.`;
      }
    }

    return null;
  }

  validateStep3(): string | null {
    const enabled = this.form.etapas.filter((e) => e.habilitada);
    if (enabled.length === 0) return 'Debes habilitar al menos 1 etapa.';
    return null;
  }

  edicionOrigenLabel(): string {
    if (!this.form.heredarDeId) return '';
    const e = this.ediciones().find((x) => x.id === this.form.heredarDeId);
    return e ? `${e.anio} — ${e.nombre_oficial}` : '';
  }

  crearCompetencia() {
    const v1 = this.validateStep1();
    if (v1) { this.step.set(1); this.wizardError.set(v1); return; }
    const v2 = this.validateStep2();
    if (v2) { this.step.set(2); this.wizardError.set(v2); return; }
    const v3 = this.validateStep3();
    if (v3) { this.step.set(3); this.wizardError.set(v3); return; }

    this.creating.set(true);
    this.wizardError.set(null);
    this.wizardOk.set(false);

    const estructuraBase = this.form.heredarDeId
      ? null
      : {
          areas_ids: this.form.areasIds,
          // 🔑 clave propuesta para backend:
          area_nivel_ids: this.form.areaNivelIds,
        };

    const payload: any = {
      anio: this.form.anio,
      nombre_oficial: this.form.nombre_oficial.trim(),
      fecha_inicio: this.form.fecha_inicio,
      fecha_fin: this.form.fecha_fin,
      estado: this.form.estado,

      heredar_de: this.form.heredarDeId || null,
      estructura_base: estructuraBase,

      etapas: (this.form.etapas || []).map((e) => ({
        key: e.key,
        nombre: e.nombre,
        orden: e.orden,
        inicio: e.inicio || null,
        fin: e.fin || null,
        habilitada: !!e.habilitada,
      })),

      reglas_base: {
        tipo: this.form.regla.tipo,
        umbral_min: this.form.regla.umbral_min ?? null,
        top_n: this.form.regla.top_n ?? null,
        nota_min_aprob: this.form.regla.nota_min_aprob ?? null,
      },
    };

    this.api.post<{ ok: boolean; data?: Edicion; message?: string }>(
      '/admin/ediciones',
      payload
    ).subscribe({
      next: (res) => {
        this.creating.set(false);
        if (!res?.ok) {
          this.wizardError.set(res?.message || 'No se pudo crear la competencia.');
          return;
        }

        this.wizardOk.set(true);

        if (res.data) {
          this.ediciones.set([res.data, ...this.ediciones()]);
          this.router.navigateByUrl(`/admin/ediciones/${res.data.id}/configuracion`);
        } else {
          this.cargarEdiciones();
          this.router.navigateByUrl('/admin/ediciones');
        }

        setTimeout(() => this.wizardOpen.set(false), 350);
      },
      error: (err) => {
        this.creating.set(false);
        const msg =
          err?.error?.message ||
          (err?.status === 422
            ? 'Datos inválidos (422). Revisa el formulario.'
            : 'No se pudo crear la competencia.');
        this.wizardError.set(msg);
      },
    });
  }

  // ====================== EDITAR (CONTROLADO) ======================
  openEdit(e: Edicion) {
    this.editTarget.set(e);
    this.editError.set(null);

    this.editForm = {
      id: e.id,
      anio: e.anio,
      nombre_oficial: e.nombre_oficial,
      fecha_inicio: e.fecha_inicio,
      fecha_fin: e.fecha_fin,
      estado: e.estado,
    };

    this.editLocks = {
      fecha: !this.canEditDates(e),
    };

    this.editOpen.set(true);
  }

  closeEdit() {
    if (this.savingEdit()) return;
    this.editOpen.set(false);
  }

  saveEdit() {
    const target = this.editTarget();
    if (!target) return;

    const nombre = (this.editForm.nombre_oficial || '').trim();
    if (!nombre) {
      this.editError.set('El nombre oficial es obligatorio.');
      return;
    }

    if (!this.editLocks.fecha) {
      if (!this.editForm.fecha_inicio || !this.editForm.fecha_fin) {
        this.editError.set('Fecha inicio y fin son obligatorias.');
        return;
      }
      if (this.editForm.fecha_fin < this.editForm.fecha_inicio) {
        this.editError.set('La fecha fin no puede ser menor que la fecha inicio.');
        return;
      }
    }

    this.savingEdit.set(true);
    this.editError.set(null);

    const payload: any = {
      nombre_oficial: nombre,
      estado: this.editForm.estado,
    };

    if (!this.editLocks.fecha) {
      payload.fecha_inicio = this.editForm.fecha_inicio;
      payload.fecha_fin = this.editForm.fecha_fin;
    }

    this.api.put<{ ok: boolean; data?: Edicion; message?: string }>(
      `/admin/ediciones/${target.id}`,
      payload
    ).subscribe({
      next: (res) => {
        this.savingEdit.set(false);
        if (!res?.ok) {
          this.editError.set(res?.message || 'No se pudo guardar cambios.');
          return;
        }
        if (res.data) {
          const updated = res.data;
          this.ediciones.set(this.ediciones().map(x => x.id === updated.id ? updated : x));
        } else {
          this.cargarEdiciones();
        }
        this.editOpen.set(false);
      },
      error: (err) => {
        this.savingEdit.set(false);
        const msg =
          err?.error?.message ||
          (err?.status === 422 ? 'Datos inválidos (422).' : 'No se pudo guardar cambios.');
        this.editError.set(msg);
      },
    });
  }

  // ====================== NAV ======================
  goConfig(e: Edicion) {
    this.router.navigateByUrl(`/admin/ediciones/${e.id}/configuracion`);
  }

  goRoles(e: Edicion) {
    this.router.navigateByUrl(`/admin/ediciones/${e.id}/roles`);
  }

  goInscritos(e: Edicion) {
    this.router.navigateByUrl(`/admin/ediciones/${e.id}/inscritos`);
  }

  // ====================== UI HELPERS ======================
  labelEstado(estado: string) {
    const e = (estado || '').toLowerCase();
    if (e === 'activa') return 'Activa';
    if (e === 'cerrada') return 'Cerrada';
    return 'Borrador';
  }

  estadoBadgeClass(estado: string) {
    const e = (estado || '').toLowerCase();
    if (e === 'activa') return 'bg-emerald-50 text-emerald-700 border-emerald-100';
    if (e === 'cerrada') return 'bg-slate-50 text-slate-600 border-slate-200';
    return 'bg-amber-50 text-amber-700 border-amber-100';
  }

  estadoDotClass(estado: string) {
    const e = (estado || '').toLowerCase();
    if (e === 'activa') return 'bg-emerald-500';
    if (e === 'cerrada') return 'bg-slate-400';
    return 'bg-amber-500';
  }
}
