// src/app/pages/admin/admin-usuarios.component.ts
import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';

type Rol = 'admin' | 'responsable_area' | 'evaluador' | 'consulta' | 'usuario';

type UsuarioRow = {
  id: number;
  nombre: string;
  email: string;
  telefono?: string | null;
  ci?: string | null;

  // rol "legacy" (role_id)
  rol?: Rol | string | null;

  // ✅ roles reales (derivados por tablas evaluadores/responsables_academicos)
  roles?: (Rol | string)[];

  activo: boolean;
};

type Meta = {
  page: number;
  per_page: number;
  total: number;
  total_pages: number;
};

interface ListResponse {
  data: UsuarioRow[];
  meta: Meta;
}

interface SaveResponse {
  ok: boolean;
  message?: string;
  data?: UsuarioRow;
}

interface OkResponse {
  ok: boolean;
  message?: string;
}

@Component({
  standalone: true,
  selector: 'app-admin-usuarios',
  imports: [CommonModule, FormsModule],
  template: `
  <section class="space-y-4">
    <!-- Header -->
    <div class="bg-white rounded-2xl border border-slate-200 p-4 flex items-center justify-between">
      <div>
        <div class="text-lg font-bold">Usuarios</div>
        <div class="text-sm text-slate-500 -mt-0.5">
          Registro base de identidades (previo a asignar roles como Evaluador/Responsable)
        </div>
      </div>
      <div class="flex items-center gap-2">
        <button
          (click)="openForm()"
          class="rounded-lg bg-[#0f3f94] hover:bg-[#0d3580] text-white px-3 py-2 text-sm">
          <i class="bi bi-plus-lg"></i> Nuevo usuario
        </button>
      </div>
    </div>

    <!-- Filtros -->
    <div class="bg-white rounded-2xl border border-slate-200 p-4">
      <div class="grid gap-3 md:grid-cols-4">
        <div class="md:col-span-2">
          <label class="text-xs text-slate-500">Buscar</label>
          <input
            [(ngModel)]="q"
            (keyup.enter)="search()"
            placeholder="Nombre, email, CI o teléfono"
            class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none
                   focus:ring-2 focus:ring-blue-200 focus:border-blue-300">
        </div>

        <div>
          <label class="text-xs text-slate-500">Estado</label>
          <select
            [(ngModel)]="activoFilter"
            (ngModelChange)="onFilterChange()"
            class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
            <option [ngValue]="0">Todos</option>
            <option [ngValue]="1">Activos</option>
            <option [ngValue]="2">Inactivos</option>
          </select>
        </div>

        <div class="flex items-end gap-2">
          <button
            (click)="search()"
            class="rounded-lg bg-[#0f3f94] hover:bg-[#0d3580] text-white px-3 py-2 text-sm">
            <i class="bi bi-search"></i> Filtrar
          </button>
          <button
            (click)="clear()"
            class="rounded-lg bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50">
            Limpiar
          </button>
        </div>
      </div>
    </div>

    <!-- Tabla -->
    <div class="bg-white rounded-2xl border border-slate-200 p-0">
      <div class="flex items-center justify-between p-3">
        <div class="font-semibold">Listado de usuarios ({{ meta().total }} reg.)</div>
      </div>

      <div class="overflow-auto">
        <table class="min-w-full text-sm">
          <thead class="bg-slate-50 sticky top-0">
            <tr class="text-left text-slate-600">
              <th class="py-2 px-3">Usuario</th>
              <th class="py-2 px-3">Email</th>
              <th class="py-2 px-3">CI</th>
              <th class="py-2 px-3">Teléfono</th>
              <th class="py-2 px-3">Roles</th>
              <th class="py-2 px-3">Estado</th>
              <th class="py-2 px-3">Acciones</th>
            </tr>
          </thead>

          <tbody>
            <tr *ngIf="rows().length === 0">
              <td colspan="7" class="py-4 text-center text-slate-400">
                No hay usuarios registrados.
              </td>
            </tr>

            <tr *ngFor="let r of rows()" class="border-t border-slate-100">
              <td class="py-2 px-3">
                <div class="font-medium text-slate-800">{{ r.nombre }}</div>
                <div class="text-xs text-slate-500">ID: {{ r.id }}</div>
              </td>

              <td class="py-2 px-3">
                <a
                  *ngIf="r.email"
                  class="text-blue-600 hover:underline"
                  [href]="'mailto:' + r.email">
                  {{ r.email }}
                </a>
                <span *ngIf="!r.email" class="text-slate-400">—</span>
              </td>

              <td class="py-2 px-3">
                <span *ngIf="r.ci; else dashCi">{{ r.ci }}</span>
                <ng-template #dashCi>—</ng-template>
              </td>

              <td class="py-2 px-3">
                <span *ngIf="r.telefono; else dashTel">{{ r.telefono }}</span>
                <ng-template #dashTel>—</ng-template>
              </td>

              <!-- ✅ Roles múltiples -->
              <td class="py-2 px-3">
                <div class="flex flex-wrap gap-1">
                  <ng-container *ngIf="(r.roles?.length || 0) > 0; else legacyTpl">
                    <span
                      *ngFor="let role of r.roles"
                      class="inline-flex items-center rounded-full bg-slate-50 text-slate-700
                             px-2 py-0.5 text-[11px] border border-slate-200">
                      {{ role }}
                    </span>
                  </ng-container>

                  <ng-template #legacyTpl>
                    <span
                      class="inline-flex items-center rounded-full bg-slate-50 text-slate-700
                             px-2 py-0.5 text-[11px] border border-slate-200">
                      {{ r.rol || 'usuario' }}
                    </span>
                  </ng-template>
                </div>
              </td>

              <td class="py-2 px-3">
                <span
                  class="text-xs rounded-full px-2 py-1"
                  [class.bg-emerald-100]="r.activo"
                  [class.text-emerald-700]="r.activo"
                  [class.bg-red-100]="!r.activo"
                  [class.text-red-700]="!r.activo">
                  {{ r.activo ? 'Activo' : 'Inactivo' }}
                </span>
              </td>

              <td class="py-2 px-3">
                <div class="flex items-center gap-3 text-xs">
                  <button class="text-blue-600 hover:underline" (click)="edit(r)">
                    Editar
                  </button>

                  <button
                    class="hover:underline"
                    [class.text-amber-700]="r.activo"
                    [class.text-emerald-700]="!r.activo"
                    (click)="toggleActivo(r)">
                    {{ r.activo ? 'Desactivar' : 'Activar' }}
                  </button>

                  <button class="text-red-600 hover:underline" (click)="remove(r)">
                    Eliminar
                  </button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Paginación -->
      <div class="flex items-center justify-between p-3 text-sm">
        <div class="text-slate-500">
          Página {{ meta().page }} de {{ meta().total_pages }} • {{ meta().total }} registros
        </div>
        <div class="flex items-center gap-2">
          <button
            (click)="goTo(meta().page - 1)"
            [disabled]="meta().page <= 1"
            class="rounded-lg bg-white border border-slate-200 px-3 py-1.5 disabled:opacity-50 hover:bg-slate-50">
            <i class="bi bi-chevron-left"></i>
          </button>
          <button
            (click)="goTo(meta().page + 1)"
            [disabled]="meta().page >= meta().total_pages"
            class="rounded-lg bg-white border border-slate-200 px-3 py-1.5 disabled:opacity-50 hover:bg-slate-50">
            <i class="bi bi-chevron-right"></i>
          </button>
        </div>
      </div>
    </div>

    <!-- Modal Crear/Editar -->
    <div *ngIf="formOpen()" class="fixed inset-0 z-50 flex items-center justify-center">
      <div class="absolute inset-0 bg-black/50" (click)="closeForm()"></div>

      <div class="relative bg-white rounded-2xl shadow-xl w-full max-w-2xl">
        <div class="p-4 border-b border-slate-200 flex items-center justify-between">
          <div class="font-semibold">
            {{ editingId() ? 'Editar usuario' : 'Nuevo usuario' }}
          </div>
          <button
            class="w-8 h-8 rounded-lg border border-slate-200 hover:bg-slate-50"
            (click)="closeForm()">
            <i class="bi bi-x"></i>
          </button>
        </div>

        <div class="p-4 space-y-4 max-h-[70vh] overflow-auto">
          <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label class="text-xs text-slate-500">Nombre *</label>
              <input
                [(ngModel)]="form.nombre"
                class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none
                       focus:ring-2 focus:ring-blue-200 focus:border-blue-300"
                placeholder="Nombre completo">
            </div>

            <div>
              <label class="text-xs text-slate-500">Email *</label>
              <input
                [(ngModel)]="form.email"
                type="email"
                class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none
                       focus:ring-2 focus:ring-blue-200 focus:border-blue-300"
                placeholder="correo@dominio.com">
            </div>

            <div>
              <label class="text-xs text-slate-500">CI (opcional)</label>
              <input
                [(ngModel)]="form.ci"
                class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none
                       focus:ring-2 focus:ring-blue-200 focus:border-blue-300"
                placeholder="Ej. 1234567">
            </div>

            <div>
              <label class="text-xs text-slate-500">Teléfono (opcional)</label>
              <input
                [(ngModel)]="form.telefono"
                class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none
                       focus:ring-2 focus:ring-blue-200 focus:border-blue-300"
                placeholder="Ej. 7xxxxxxx">
            </div>

            <!-- ⚠️ rol legacy (role_id). Los roles reales se asignan en módulos Evaluadores/Responsables -->
            <div>
              <label class="text-xs text-slate-500">Rol principal (legacy)</label>
              <select
                [(ngModel)]="form.rol"
                class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
                <option [ngValue]="'usuario'">usuario</option>
                <option [ngValue]="'evaluador'">evaluador</option>
                <option [ngValue]="'responsable_area'">responsable_area</option>
                <option [ngValue]="'consulta'">consulta</option>
                <option [ngValue]="'admin'">admin</option>
              </select>
              <div class="text-[11px] text-slate-500 mt-1">
                Nota: Evaluador/Responsable reales se reflejan por su registro en sus módulos.
              </div>
            </div>

            <div class="flex items-center gap-2 mt-6">
              <input type="checkbox" [(ngModel)]="form.activo">
              <span class="text-sm">Usuario activo</span>
            </div>
          </div>

          <div *ngIf="!editingId()" class="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label class="text-xs text-slate-500">
                Contraseña *
                <span class="text-[11px] text-slate-400">(solo al crear)</span>
              </label>
              <input
                [(ngModel)]="form.password"
                type="password"
                class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none
                       focus:ring-2 focus:ring-blue-200 focus:border-blue-300"
                placeholder="••••••••">
            </div>
            <div>
              <label class="text-xs text-slate-500">Confirmar contraseña *</label>
              <input
                [(ngModel)]="form.password2"
                type="password"
                class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none
                       focus:ring-2 focus:ring-blue-200 focus:border-blue-300"
                placeholder="••••••••">
            </div>
          </div>

          <div
            *ngIf="errorMsg()"
            class="rounded-xl border border-red-200 bg-red-50 text-red-700 px-3 py-2 text-sm">
            {{ errorMsg() }}
          </div>

          <div
            *ngIf="successMsg()"
            class="rounded-xl border border-emerald-200 bg-emerald-50 text-emerald-700 px-3 py-2 text-sm">
            {{ successMsg() }}
          </div>
        </div>

        <div class="p-4 border-t border-slate-200 flex items-center justify-end gap-2">
          <button
            (click)="closeForm()"
            class="rounded-lg bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50">
            Cancelar
          </button>

          <button
            (click)="save()"
            [disabled]="saving()"
            class="rounded-lg bg-[#0f3f94] hover:bg-[#0d3580] text-white px-4 py-2 text-sm">
            <ng-container *ngIf="!saving(); else savingTpl">
              <i class="bi bi-save"></i> Guardar
            </ng-container>
          </button>

          <ng-template #savingTpl>
            <span class="inline-flex items-center gap-2">
              <span
                class="inline-block h-4 w-4 border-2 border-white/60 border-t-white rounded-full animate-spin"></span>
              Guardando...
            </span>
          </ng-template>
        </div>
      </div>
    </div>

  </section>
  `,
})
export class AdminUsuariosComponent {
  private api = inject(ApiService);

  // Filtros
  q = '';
  activoFilter = 0; // 0 todos, 1 activos, 2 inactivos

  rows = signal<UsuarioRow[]>([]);
  meta = signal<Meta>({ page: 1, per_page: 15, total: 0, total_pages: 0 });

  // Modal
  formOpen = signal(false);
  saving = signal(false);
  editingId = signal<number | null>(null);
  errorMsg = signal('');
  successMsg = signal('');

  form: {
    nombre: string;
    email: string;
    ci: string;
    telefono: string;
    rol: Rol | string;
    activo: boolean;
    password: string;
    password2: string;
  } = {
    nombre: '',
    email: '',
    ci: '',
    telefono: '',
    rol: 'usuario',
    activo: true,
    password: '',
    password2: '',
  };

  ngOnInit(): void {
    this.search();
  }

  // ======================= Listado =======================

  params(): Record<string, string> {
    const p: Record<string, string> = {
      page: String(this.meta().page),
      per_page: String(15),
    };
    if (this.q.trim()) p['q'] = this.q.trim();

    if (this.activoFilter === 1) p['activo'] = '1';
    if (this.activoFilter === 2) p['activo'] = '0';

    return p;
  }

  search(): void {
    const qs = new URLSearchParams(this.params()).toString();
    this.api.get(`/admin/usuarios?${qs}`).subscribe(
      (value) => {
        const res = value as ListResponse;
        this.rows.set(res?.data ?? []);
        this.meta.set(res?.meta ?? { page: 1, per_page: 15, total: 0, total_pages: 0 });
      },
      () => {
        this.rows.set([]);
        this.meta.set({ page: 1, per_page: 15, total: 0, total_pages: 0 });
      }
    );
  }

  clear(): void {
    this.q = '';
    this.activoFilter = 0;
    this.meta.set({ ...this.meta(), page: 1 });
    this.search();
  }

  onFilterChange(): void {
    this.meta.set({ ...this.meta(), page: 1 });
    this.search();
  }

  goTo(p: number): void {
    const m = this.meta();
    if (p < 1 || p > m.total_pages) return;
    this.meta.set({ ...m, page: p });
    this.search();
  }

  // ======================= Modal =======================

  openForm(): void {
    this.editingId.set(null);
    this.form = {
      nombre: '',
      email: '',
      ci: '',
      telefono: '',
      rol: 'usuario',
      activo: true,
      password: '',
      password2: '',
    };
    this.errorMsg.set('');
    this.successMsg.set('');
    this.formOpen.set(true);
  }

  closeForm(): void {
    if (this.saving()) return;
    this.formOpen.set(false);
  }

  edit(r: UsuarioRow): void {
    this.editingId.set(r.id);
    this.form = {
      nombre: r.nombre || '',
      email: r.email || '',
      ci: (r.ci || '') as string,
      telefono: (r.telefono || '') as string,
      rol: (r.rol || 'usuario') as any,
      activo: !!r.activo,
      password: '',
      password2: '',
    };
    this.errorMsg.set('');
    this.successMsg.set('');
    this.formOpen.set(true);
  }

  // ======================= Guardar =======================

  validate(): string | null {
    if (!this.form.nombre.trim()) return 'El nombre es obligatorio.';
    if (!this.form.email.trim()) return 'El email es obligatorio.';
    if (!this.form.email.includes('@')) return 'El email no tiene formato válido.';

    if (this.editingId() === null) {
      if (!this.form.password.trim()) return 'La contraseña es obligatoria.';
      if (this.form.password.trim().length < 6) return 'La contraseña debe tener al menos 6 caracteres.';
      if (this.form.password !== this.form.password2) return 'Las contraseñas no coinciden.';
    }
    return null;
  }

  save(): void {
    const v = this.validate();
    if (v) {
      this.errorMsg.set(v);
      return;
    }

    this.saving.set(true);
    this.errorMsg.set('');
    this.successMsg.set('');

    const payloadBase: any = {
      nombre: this.form.nombre.trim(),
      email: this.form.email.trim(),
      ci: this.form.ci.trim() || null,
      telefono: this.form.telefono.trim() || null,
      rol: this.form.rol || 'usuario',
      activo: !!this.form.activo,
    };

    if (this.editingId() === null) {
      const payload = {
        ...payloadBase,
        password: this.form.password.trim(),
        password_confirmation: this.form.password2.trim(),
      };

      this.api.post('/admin/usuarios', payload).subscribe(
        (value) => {
          const res = value as SaveResponse;
          if (res && res.ok) {
            this.successMsg.set(res.message || 'Usuario creado correctamente.');
            this.search();
            setTimeout(() => this.closeForm(), 450);
          } else {
            this.errorMsg.set((res && res.message) || 'No se pudo guardar.');
          }
          this.saving.set(false);
        },
        (err) => {
          const msg =
            (err as { error?: { message?: string } })?.error?.message ||
            'Error al guardar.';
          this.errorMsg.set(msg);
          this.saving.set(false);
        }
      );
    } else {
      const id = this.editingId() as number;

      this.api.put(`/admin/usuarios/${id}`, payloadBase).subscribe(
        (value) => {
          const res = value as SaveResponse;
          if (res && res.ok) {
            this.successMsg.set(res.message || 'Usuario actualizado.');
            this.search();
            setTimeout(() => this.closeForm(), 450);
          } else {
            this.errorMsg.set((res && res.message) || 'No se pudo guardar.');
          }
          this.saving.set(false);
        },
        (err) => {
          const msg =
            (err as { error?: { message?: string } })?.error?.message ||
            'Error al guardar.';
          this.errorMsg.set(msg);
          this.saving.set(false);
        }
      );
    }
  }

  // ======================= Acciones =======================

  toggleActivo(r: UsuarioRow): void {
    if (!confirm(`¿Cambiar estado del usuario "${r.nombre}"?`)) return;

    this.api.post(`/admin/usuarios/${r.id}/toggle-activo`, {}).subscribe(
      (value) => {
        const res = value as OkResponse;
        if (res && res.ok) {
          this.search();
        } else if (res && res.message) {
          alert(res.message);
        }
      },
      (err) => {
        const msg =
          (err as { error?: { message?: string } })?.error?.message ||
          'No se pudo cambiar el estado.';
        alert(msg);
      }
    );
  }

  remove(r: UsuarioRow): void {
    if (!confirm(`¿Eliminar al usuario "${r.nombre}"?\nEsta acción no se puede deshacer.`)) return;

    this.api.delete(`/admin/usuarios/${r.id}`).subscribe(
      (value) => {
        const res = value as OkResponse;
        if (res && res.ok) {
          this.search();
        } else if (res && res.message) {
          alert(res.message);
        }
      },
      (err) => {
        const msg =
          (err as { error?: { message?: string } })?.error?.message ||
          'No se pudo eliminar.';
        alert(msg);
      }
    );
  }
}
