import { CommonModule } from '@angular/common';
import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { ApiService } from '../../core/api.service';

type EstadoEdicion = 'borrador' | 'activa' | 'cerrada';

type Edicion = {
  id: number;
  nombre_oficial: string;
  estado: EstadoEdicion;
};

type ResultadoClasificacion = {
  area?: string;
  nivel?: string;
  total?: number;
  clasificados?: number;
  no_clasificados?: number;
};

const ENDPOINTS = {
  edicion: (id: number) => `/admin/ediciones/${id}`,
  ejecutar: (id: number) => `/admin/ediciones/${id}/clasificacion/ejecutar`, // POST
  preview: (id: number) => `/admin/ediciones/${id}/clasificacion/preview`,  // GET
};

@Component({
  standalone: true,
  selector: 'app-edicion-clasificacion',
  imports: [CommonModule, FormsModule, RouterModule],
  template: `
  <section class="space-y-4">

    <div class="bg-white border border-slate-200 rounded-2xl p-4 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3">
      <div class="min-w-0">
        <a class="text-xs text-slate-500 hover:text-slate-700 inline-flex items-center gap-1"
           [routerLink]="['/admin/ediciones', edicionId(), 'configuracion']">
          <i class="bi bi-arrow-left"></i> Volver a configuración
        </a>

        <h1 class="text-lg md:text-xl font-bold tracking-tight mt-1 truncate">
          Clasificación
        </h1>
        <div class="text-sm text-slate-500">
          {{ edicion()?.nombre_oficial || '—' }} · Estado: <strong>{{ edicion()?.estado || '—' }}</strong>
        </div>
      </div>

      <div class="flex items-center gap-2">
        <button class="rounded-lg bg-white border border-slate-200 px-4 py-2 text-sm hover:bg-slate-50"
                (click)="preview()" [disabled]="loading()">
          <i class="bi bi-eye"></i> Preview
        </button>

        <button class="rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 text-sm font-semibold"
                (click)="ejecutar()" [disabled]="loading()">
          <i class="bi bi-play-circle"></i> Ejecutar
        </button>
      </div>
    </div>

    <div *ngIf="error()" class="rounded-2xl border border-red-200 bg-red-50 p-4 text-red-700 text-sm">
      {{ error() }}
    </div>

    <div class="bg-white border border-slate-200 rounded-2xl p-4 space-y-3">
      <div class="text-sm font-semibold">Parámetros de ejecución</div>
      <div class="text-xs text-slate-500">
        Estos parámetros pueden sobrescribir reglas base temporalmente (gobernanza backend manda la última palabra).
      </div>

      <div class="grid md:grid-cols-4 gap-3">
        <div class="md:col-span-2">
          <label class="text-xs text-slate-500">Tipo</label>
          <select [(ngModel)]="tipo" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
            <option [ngValue]="'umbral'">Umbral</option>
            <option [ngValue]="'top_n'">Top N</option>
            <option [ngValue]="'mixta'">Mixta</option>
          </select>
        </div>

        <div>
          <label class="text-xs text-slate-500">Umbral</label>
          <input type="number" [(ngModel)]="umbral" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
        </div>

        <div>
          <label class="text-xs text-slate-500">Top N</label>
          <input type="number" [(ngModel)]="topN" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
        </div>
      </div>

      <div class="text-[11px] text-slate-500">
        Recomendación: ejecutar clasificación cuando la fase esté cerrada y las notas consolidadas.
      </div>
    </div>

    <div class="bg-white border border-slate-200 rounded-2xl overflow-hidden">
      <div class="p-4 border-b border-slate-200 flex items-center justify-between">
        <div class="font-semibold text-sm">Resumen</div>
        <div class="text-xs text-slate-500" *ngIf="loading()">Procesando...</div>
      </div>

      <div *ngIf="resultados().length===0 && !loading()" class="py-10 text-center text-slate-400 text-sm">
        Sin datos. Usa Preview o Ejecutar.
      </div>

      <div *ngIf="resultados().length>0" class="overflow-x-auto">
        <table class="min-w-full text-sm">
          <thead class="bg-slate-50 text-slate-600">
            <tr class="text-left">
              <th class="py-2 px-3">Área</th>
              <th class="py-2 px-3">Nivel</th>
              <th class="py-2 px-3">Total</th>
              <th class="py-2 px-3">Clasificados</th>
              <th class="py-2 px-3">No clasificados</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let r of resultados()" class="border-t border-slate-100">
              <td class="py-2 px-3">{{ r.area || '—' }}</td>
              <td class="py-2 px-3">{{ r.nivel || '—' }}</td>
              <td class="py-2 px-3">{{ r.total ?? '—' }}</td>
              <td class="py-2 px-3 font-semibold text-emerald-700">{{ r.clasificados ?? '—' }}</td>
              <td class="py-2 px-3 text-slate-700">{{ r.no_clasificados ?? '—' }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

  </section>
  `,
})
export class EdicionClasificacionComponent {
  private api = inject(ApiService);
  private route = inject(ActivatedRoute);

  edicionId = signal<number | null>(null);
  edicion = signal<Edicion | null>(null);

  loading = signal(false);
  error = signal<string | null>(null);

  tipo: 'umbral' | 'top_n' | 'mixta' = 'mixta';
  umbral: number | null = 60;
  topN: number | null = 10;

  resultados = signal<ResultadoClasificacion[]>([]);

  ngOnInit() {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    if (!id || Number.isNaN(id)) {
      this.error.set('ID de edición inválido.');
      return;
    }
    this.edicionId.set(id);
    this.loadEdicion();
  }

  loadEdicion() {
    const id = this.edicionId();
    if (!id) return;

    this.loading.set(true);
    this.error.set(null);

    this.api.get<{ ok: boolean; data: Edicion }>(ENDPOINTS.edicion(id)).subscribe({
      next: (r) => {
        this.loading.set(false);
        if (!r?.ok) {
          this.error.set('No se pudo cargar la competencia.');
          return;
        }
        this.edicion.set(r.data);
      },
      error: () => {
        this.loading.set(false);
        this.error.set('No se pudo cargar la competencia.');
      }
    });
  }

  preview() {
    const id = this.edicionId();
    if (!id) return;

    this.loading.set(true);
    this.error.set(null);

    this.api.get<{ ok: boolean; data: ResultadoClasificacion[] }>(ENDPOINTS.preview(id)).subscribe({
      next: (r) => {
        this.loading.set(false);
        if (!r?.ok) {
          this.error.set('No se pudo obtener preview.');
          return;
        }
        this.resultados.set(r.data || []);
      },
      error: () => {
        this.loading.set(false);
        this.error.set('No se pudo obtener preview.');
      }
    });
  }

  ejecutar() {
    const id = this.edicionId();
    if (!id) return;

    this.loading.set(true);
    this.error.set(null);

    const payload = {
      tipo: this.tipo,
      umbral_min: this.umbral ?? null,
      top_n: this.topN ?? null,
    };

    this.api.post<{ ok: boolean; data?: ResultadoClasificacion[]; message?: string }>(ENDPOINTS.ejecutar(id), payload).subscribe({
      next: (r) => {
        this.loading.set(false);
        if (!r?.ok) {
          this.error.set(r?.message || 'No se pudo ejecutar clasificación.');
          return;
        }
        this.resultados.set(r.data || []);
      },
      error: (err) => {
        this.loading.set(false);
        this.error.set(err?.error?.message || 'No se pudo ejecutar clasificación.');
      }
    });
  }
}
