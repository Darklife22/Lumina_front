import { Component } from '@angular/core';

@Component({
  standalone: true,
  selector: 'app-placeholder',
  template: `
    <div class="bg-white rounded-2xl border border-slate-200 p-6">
      <h2 class="text-lg font-semibold mb-1">Próximamente</h2>
      <p class="text-slate-600">Esta sección se implementará en breve.</p>
    </div>
  `
})
export class PlaceholderComponent {}
