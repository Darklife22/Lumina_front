import { Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';

type CsvRow = {
  linea: number;
  id: string | null;
  nombre: string | null;
  ci: string | null;
  area: string | null;
  nivel: string | null;
  unidad_educativa: string | null;
  profesor: string | null;
};

type EditRow = Required<Omit<CsvRow, 'linea'>> & { linea: number; error?: string };

type CsvError = {
  linea: number;
  detalle: string;
  campo?: 'id' | 'nombre' | 'ci' | 'area' | 'nivel' | 'unidad_educativa' | 'profesor' | 'global';
};

@Component({
  standalone: true,
  selector: 'app-importar-inscritos',
  imports: [CommonModule, FormsModule],
  template: `
  <section class="space-y-4">
    <!-- Header -->
    <div class="bg-white rounded-2xl border border-slate-200 p-4 flex items-center justify-between">
      <div>
        <div class="text-lg font-bold">Importación de inscritos</div>
        <div class="text-sm text-slate-500 -mt-0.5">
          Carga masiva desde CSV (id, nombre, ci, area, nivel, unidad_educativa, profesor)
        </div>
      </div>
      <div class="flex items-center gap-2">
        <button
          (click)="resetState()"
          class="rounded-xl bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50">
          <i class="bi bi-arrow-repeat"></i> Limpiar pantalla
        </button>
      </div>
    </div>

    <!-- Zona de carga -->
    <div class="bg-white rounded-2xl border border-slate-200 p-4">
      <div class="grid gap-3 md:grid-cols-[1fr_auto]">
        <div class="rounded-xl border-2 border-dashed p-6 text-center"
             [class.border-slate-300]="!dragOver()"
             [class.border-blue-400]="dragOver()"
             (dragover)="onDragOver($event)"
             (dragleave)="onDragLeave($event)"
             (drop)="onDrop($event)">
          <div class="text-slate-600">
            <div class="font-medium mb-1">Arrastra tu archivo CSV aquí</div>
            <div class="text-xs text-slate-500">o usa el botón “Seleccionar CSV”</div>
          </div>
          <div class="mt-3">
            <input type="file" accept=".csv" class="hidden" #fileInput (change)="onFileChosen($event)" />
            <button (click)="fileInput.click()"
              class="rounded-xl bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50">
              <i class="bi bi-folder2-open"></i> Seleccionar CSV
            </button>
            <span class="ml-2 text-sm text-slate-600" *ngIf="fileName()">{{ fileName() }}</span>
          </div>
        </div>

        <div class="flex flex-col items-start md:items-end md:justify-end gap-2">
          <button (click)="upload()"
            [disabled]="!file() || loading() || hasCsvErrors()"
            class="rounded-xl bg-[#0f3f94] hover:bg-[#0d3580] text-white px-4 py-2.5 text-sm shadow disabled:opacity-60">
            <ng-container *ngIf="!loading(); else uploading">
              <i class="bi bi-cloud-arrow-up"></i> Subir CSV al sistema
            </ng-container>
            <ng-template #uploading>
              <span class="inline-flex items-center gap-2">
                <span class="inline-block h-4 w-4 border-2 border-white/60 border-t-white rounded-full animate-spin"></span>
                Procesando...
              </span>
            </ng-template>
          </button>
          <div *ngIf="file() && hasCsvErrors()" class="text-xs text-red-600 max-w-xs text-right">
            Se detectaron {{ obs().length }} problemas en el archivo. Corrige todos los errores antes de subir.
          </div>
        </div>
      </div>

      <!-- Alertas -->
      <div class="mt-4 space-y-2">
        <div *ngIf="successMsg()" class="rounded-xl border border-emerald-200 bg-emerald-50 text-emerald-700 px-4 py-2 text-sm">
          <i class="bi bi-check-circle"></i> {{ successMsg() }}
        </div>
        <div *ngIf="errorMsg()" class="rounded-xl border border-red-200 bg-red-50 text-red-700 px-4 py-2 text-sm">
          <i class="bi bi-exclamation-triangle"></i> {{ errorMsg() }}
        </div>
      </div>

      <!-- Observaciones -->
      <div *ngIf="obs().length" class="mt-3">
        <div class="text-sm font-medium mb-1">
          Observaciones del archivo ({{ obs().length }} problemas detectados)
        </div>
        <div class="rounded-xl border border-amber-200 bg-amber-50 p-3 max-h-56 overflow-auto text-amber-800 text-sm space-y-1">
          <div *ngFor="let e of obs()">
            Línea {{ e.linea }}<span *ngIf="e.campo && e.campo !== 'global'"> · campo <strong>{{ e.campo }}</strong></span>: {{ e.detalle }}
          </div>
        </div>
        <div class="mt-3">
          <button class="rounded-xl bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50"
                  (click)="openFixModal()"
                  *ngIf="editableRejected().length">
            <i class="bi bi-pencil-square"></i> Corregir filas rechazadas (servidor)
          </button>
        </div>
      </div>
    </div>

    <!-- Tabla de PREVISUALIZACIÓN CSV -->
    <div class="bg-white rounded-2xl border border-slate-200 p-0">
      <div class="flex items-center justify-between p-4">
        <div class="font-semibold">
          Previsualización del archivo CSV ({{ csvPreview().length }} filas)
        </div>
        <div class="text-xs text-slate-500">
          El sistema solo importará el archivo si no hay errores.
        </div>
      </div>

      <!-- Desktop -->
      <div class="hidden md:block">
        <div class="overflow-auto max-h-[60vh]">
          <table class="min-w-full text-sm">
            <thead class="bg-slate-50 sticky top-0 z-10">
              <tr class="text-left text-slate-600">
                <th class="py-2 px-4">Línea</th>
                <th class="py-2 px-4">ID</th>
                <th class="py-2 px-4">Nombre</th>
                <th class="py-2 px-4">CI</th>
                <th class="py-2 px-4">Área</th>
                <th class="py-2 px-4">Nivel</th>
                <th class="py-2 px-4">Unidad educativa</th>
                <th class="py-2 px-4">Profesor</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngIf="csvPreview().length === 0">
                <td class="py-6 px-4 text-slate-400 text-center" colspan="8">
                  No hay datos cargados. Selecciona un archivo CSV para previsualizar los nuevos inscritos.
                </td>
              </tr>

              <tr *ngFor="let r of csvPreview()"
                  class="border-t border-slate-100 align-top">
                <td class="py-2 px-4 text-slate-500">{{ r.linea }}</td>

                <td class="py-2 px-4">
                  <div>{{ r.id }}</div>
                  <div *ngFor="let err of getCellErrors(r.linea, 'id')" class="text-xs text-red-600 mt-0.5">• {{ err }}</div>
                </td>

                <td class="py-2 px-4">
                  <div>{{ r.nombre }}</div>
                  <div *ngFor="let err of getCellErrors(r.linea, 'nombre')" class="text-xs text-red-600 mt-0.5">• {{ err }}</div>
                </td>

                <td class="py-2 px-4">
                  <div>{{ r.ci }}</div>
                  <div *ngFor="let err of getCellErrors(r.linea, 'ci')" class="text-xs text-red-600 mt-0.5">• {{ err }}</div>
                </td>

                <td class="py-2 px-4">
                  <div>{{ r.area }}</div>
                  <div *ngFor="let err of getCellErrors(r.linea, 'area')" class="text-xs text-red-600 mt-0.5">• {{ err }}</div>
                </td>

                <td class="py-2 px-4">
                  <div>{{ r.nivel }}</div>
                  <div *ngFor="let err of getCellErrors(r.linea, 'nivel')" class="text-xs text-red-600 mt-0.5">• {{ err }}</div>
                </td>

                <td class="py-2 px-4">
                  <div>{{ r.unidad_educativa }}</div>
                  <div *ngFor="let err of getCellErrors(r.linea, 'unidad_educativa')" class="text-xs text-red-600 mt-0.5">• {{ err }}</div>
                </td>

                <td class="py-2 px-4">
                  <div>{{ r.profesor }}</div>
                  <div *ngFor="let err of getCellErrors(r.linea, 'profesor')" class="text-xs text-red-600 mt-0.5">• {{ err }}</div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Mobile preview -->
      <div class="md:hidden px-3 pb-3 space-y-3 max-h-[60vh] overflow-auto">
        <div *ngIf="csvPreview().length === 0" class="text-slate-400 text-sm px-1">
          No hay datos cargados. Selecciona un CSV para ver los nuevos inscritos.
        </div>

        <div *ngFor="let r of csvPreview()" class="rounded-xl border border-slate-200 p-3">
          <div class="text-xs text-slate-500 mb-1">Línea {{ r.linea }}</div>
          <div class="text-sm font-medium mb-1">{{ r.nombre || '(sin nombre)' }}</div>

          <div class="text-xs text-slate-500 mb-2">
            <span *ngIf="r.ci">CI: {{ r.ci }}</span>
          </div>

          <div class="grid grid-cols-2 gap-2 text-xs">
            <div><span class="text-slate-500">Área: </span>{{ r.area }}</div>
            <div><span class="text-slate-500">Nivel: </span>{{ r.nivel }}</div>
            <div class="col-span-2">
              <span class="text-slate-500">Unidad: </span>{{ r.unidad_educativa }}</div>
            <div class="col-span-2">
              <span class="text-slate-500">Profesor: </span>{{ r.profesor }}</div>
          </div>

          <div *ngIf="getRowErrors(r.linea).length" class="mt-2 text-xs text-red-600">
            <div *ngFor="let err of getRowErrors(r.linea)">• {{ err }}</div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal de corrección -->
    <div *ngIf="fixOpen()" class="fixed inset-0 z-50 flex items-center justify-center">
      <div class="absolute inset-0 bg-black/50" (click)="closeFixModal()"></div>
      <div class="relative bg-white rounded-2xl shadow-xl w-full max-w-5xl max-h-[85vh] overflow-hidden">
        <div class="p-4 border-b border-slate-200 flex items-center justify-between">
          <div class="font-semibold">Corregir filas rechazadas</div>
          <button class="w-8 h-8 rounded-lg border border-slate-200 hover:bg-slate-50"
                  (click)="closeFixModal()"><i class="bi bi-x"></i></button>
        </div>
        <div class="p-4 overflow-auto max-h-[65vh]">
          <table class="min-w-full text-sm">
            <thead class="bg-slate-50 sticky top-0">
              <tr class="text-left text-slate-600">
                <th class="py-2 px-3">Línea</th>
                <th class="py-2 px-3">Nombre *</th>
                <th class="py-2 px-3">CI *</th>
                <th class="py-2 px-3">Área *</th>
                <th class="py-2 px-3">Nivel *</th>
                <th class="py-2 px-3">Unidad Educ.</th>
                <th class="py-2 px-3">Profesor</th>
                <th class="py-2 px-3">Estado</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let r of editableRejected(); let i = index; trackBy: trackEdit"
                  class="border-t border-slate-100">
                <td class="py-2 px-3 text-slate-500">{{ r.linea }}</td>
                <td class="py-2 px-3">
                  <input class="form-input" [(ngModel)]="r.nombre" [ngModelOptions]="{standalone:true}"
                         [class.border-red-300]="!r.nombre">
                </td>
                <td class="py-2 px-3">
                  <input class="form-input" [(ngModel)]="r.ci" [ngModelOptions]="{standalone:true}"
                         [class.border-red-300]="!r.ci">
                </td>
                <td class="py-2 px-3">
                  <input class="form-input" [(ngModel)]="r.area" [ngModelOptions]="{standalone:true}"
                         [class.border-red-300]="!r.area">
                </td>
                <td class="py-2 px-3">
                  <input class="form-input" [(ngModel)]="r.nivel" [ngModelOptions]="{standalone:true}"
                         [class.border-red-300]="!r.nivel">
                </td>
                <td class="py-2 px-3">
                  <input class="form-input" [(ngModel)]="r.unidad_educativa" [ngModelOptions]="{standalone:true}"
                         [class.border-red-300]="!r.unidad_educativa">
                </td>
                <td class="py-2 px-3">
                  <input class="form-input" [(ngModel)]="r.profesor" [ngModelOptions]="{standalone:true}"
                         [class.border-red-300]="!r.profesor">
                </td>
                <td class="py-2 px-3">
                  <span class="text-xs rounded-full px-2 py-1"
                        [class.bg-emerald-100]="rowValid(r)"
                        [class.text-emerald-700]="rowValid(r)"
                        [class.bg-red-100]="!rowValid(r)"
                        [class.text-red-700]="!rowValid(r)">
                    {{ rowValid(r) ? 'OK' : 'Incompleto' }}
                  </span>
                </td>
              </tr>
            </tbody>
          </table>
          <div class="text-xs text-slate-500 mt-2">Campos marcados con * son obligatorios.</div>
        </div>
        <div class="p-4 border-t border-slate-200 flex items-center justify-end gap-2">
          <button class="rounded-xl bg-white border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50"
                  (click)="closeFixModal()">Cancelar</button>
          <button class="rounded-xl bg-[#0f3f94] hover:bg-[#0d3580] text-white px-4 py-2.5 text-sm shadow disabled:opacity-60"
                  [disabled]="savingFix()" (click)="saveCorrections()">
            <ng-container *ngIf="!savingFix(); else savingTpl">
              <i class="bi bi-save"></i> Guardar y reintentar
            </ng-container>
            <ng-template #savingTpl>
              <span class="inline-flex items-center gap-2">
                <span class="inline-block h-4 w-4 border-2 border-white/60 border-t-white rounded-full animate-spin"></span>
                Enviando...
              </span>
            </ng-template>
          </button>
        </div>
      </div>
    </div>
  </section>
  `,
  styles: [`
    .form-input { @apply w-40 rounded-lg border border-slate-300 px-2 py-1 outline-none focus:ring-2 focus:ring-blue-200 focus:border-blue-300; }
  `]
})
export class ImportarInscritosComponent {
  private api = inject(ApiService);

  file = signal<File|null>(null);
  fileName = signal<string>('');
  loading = signal(false);
  successMsg = signal('');
  errorMsg = signal('');
  dragOver = signal(false);

  obs = signal<CsvError[]>([]);
  csvPreview = signal<CsvRow[]>([]);

  fixOpen = signal(false);
  savingFix = signal(false);
  editableRejected = signal<EditRow[]>([]);

  hasCsvErrors = computed(() => this.obs().length > 0);

  resetState() {
    this.file.set(null);
    this.fileName.set('');
    this.csvPreview.set([]);
    this.obs.set([]);
    this.editableRejected.set([]);
    this.successMsg.set('');
    this.errorMsg.set('');
    this.loading.set(false);
  }

  onFileChosen(ev: Event) {
    const input = ev.target as HTMLInputElement;
    const f = input.files?.[0] ?? null;
    this.setFile(f);
  }
  onDragOver(ev: DragEvent) { ev.preventDefault(); this.dragOver.set(true); }
  onDragLeave(ev: DragEvent) { ev.preventDefault(); this.dragOver.set(false); }
  onDrop(ev: DragEvent) {
    ev.preventDefault(); this.dragOver.set(false);
    const f = ev.dataTransfer?.files?.[0] ?? null;
    this.setFile(f);
  }

  setFile(f: File|null) {
    if (!f) {
      this.resetState();
      return;
    }
    const ext = f.name.split('.').pop()?.toLowerCase();
    if (ext !== 'csv') {
      // Limpio estado de archivo pero conservo el mensaje de error
      this.file.set(null);
      this.fileName.set('');
      this.csvPreview.set([]);
      this.obs.set([]);
      this.editableRejected.set([]);
      this.loading.set(false);
      this.successMsg.set('');
      this.errorMsg.set('Solo se permite subir archivos .csv');
      return;
    }

    this.errorMsg.set('');
    this.successMsg.set('');
    this.file.set(f);
    this.fileName.set(f.name);

    this.parseCsvLocal(f).then(({ rows, errors }) => {
      this.csvPreview.set(rows);
      this.obs.set(errors);
    }).catch(() => {
      this.csvPreview.set([]);
      this.obs.set([]);
    });
  }

  upload() {
    const f = this.file();
    if (!f) return;

    if (this.obs().length > 0) {
      this.errorMsg.set('El archivo CSV tiene errores. Corrige todos los problemas antes de subir al sistema.');
      return;
    }

    this.loading.set(true);
    this.successMsg.set('');
    this.errorMsg.set('');

    const fd = new FormData();
    fd.append('archivo', f);

    this.api.postForm<{ok:boolean; inserted:number; errors:Array<{linea:number;detalle:string;nombre?:string;ci?:string;area?:string;nivel?:string;unidad_educativa?:string;profesor?:string}>; message:string}>(
      '/admin/inscritos/import',
      fd
    ).subscribe({
      next: (res) => {
        // En el flujo actual, si hay errores el back responde 422 y cae en error, así que aquí normalmente solo llegan OK
        if (res.ok) {
          this.successMsg.set(res.message || 'Importación realizada con éxito.');
        } else {
          this.errorMsg.set(res.message || 'Importación con observaciones.');
        }
        this.loading.set(false);
      },
      error: (err) => {
        this.loading.set(false);

        const payload = err?.error || {};
        const msg = payload.message || 'No se pudo procesar el archivo CSV.';
        this.errorMsg.set(msg);

        const backendErrors = (payload.errors || []) as Array<{
          linea: number;
          detalle: string;
          nombre?: string;
          ci?: string;
          area?: string;
          nivel?: string;
          unidad_educativa?: string;
          profesor?: string;
        }>;

        if (!backendErrors.length) return;

        // Merge observaciones
        const currentObs = this.obs();
        const map = new Set(currentObs.map(o => `${o.linea}|${o.detalle}|${o.campo || ''}`));

       const extraObs: CsvError[] = backendErrors
  .map((e) => ({
    linea: e.linea ?? 0,
    detalle: e.detalle ?? 'Error en la fila',
    campo: 'global' as CsvError['campo'],   // 👈 aquí el casteo fino
  }))
  .filter((o) => {
    const k = `${o.linea}|${o.detalle}|${o.campo || ''}`;
    if (map.has(k)) return false;
    map.add(k);
    return true;
  });

this.obs.set([...currentObs, ...extraObs]);


        // Preparar filas editables
        const editables: EditRow[] = backendErrors.map(e => ({
          linea: e.linea ?? 0,
          id: '', // si quieres, puedes mapear al id original desde csvPreview usando linea
          nombre: e.nombre ?? '',
          ci: e.ci ?? '',
          area: e.area ?? '',
          nivel: e.nivel ?? '',
          unidad_educativa: e.unidad_educativa ?? '',
          profesor: e.profesor ?? '',
          error: e.detalle ?? ''
        }));

        this.editableRejected.set(editables);
      }
    });
  }

  openFixModal() { this.fixOpen.set(true); }
  closeFixModal() { this.fixOpen.set(false); }

  rowValid(r: EditRow) {
    // Alineado con validaciones del backend en /corregir
    return !!(r.nombre && r.ci && r.area && r.nivel && r.unidad_educativa && r.profesor);
  }

  saveCorrections() {
    const rows = this.editableRejected().filter(r => this.rowValid(r));
    if (!rows.length) {
      this.errorMsg.set('No hay filas completas para corregir.');
      return;
    }

    this.savingFix.set(true);
    this.api.post<{ ok: boolean; inserted: number; message?: string; errors?: Array<{linea:number;detalle:string}> }>(
      '/admin/inscritos/corregir',
      {
        rows: rows.map(r => ({
          id: r.id || null,
          nombre: r.nombre,
          ci: r.ci,
          area: r.area,
          nivel: r.nivel,
          unidad_educativa: r.unidad_educativa || null,
          profesor: r.profesor || null,
          linea: r.linea,
        }))
      }
    ).subscribe({
      next: (res) => {
        if (res.ok) {
          this.successMsg.set(res.message || 'Correcciones aplicadas.');
          const corregidas = new Set(rows.map(r => r.linea));
          this.editableRejected.set(this.editableRejected().filter(r => !corregidas.has(r.linea)));
          this.obs.set(this.obs().filter(o => !corregidas.has(o.linea)));
          this.closeFixModal();
        } else {
          this.errorMsg.set(res.message || 'No se pudo corregir algunas filas.');
          const backObs = res.errors || [];
          if (backObs.length) {
            const currentObs = this.obs();
            const map = new Set(currentObs.map(o => `${o.linea}|${o.detalle}|${o.campo || ''}`));
            const extra = backObs.map(e => ({
              linea: e.linea ?? 0,
              detalle: e.detalle ?? 'Error en la fila',
              campo: 'global' as const
            })).filter(o => {
              const k = `${o.linea}|${o.detalle}|${o.campo || ''}`;
              if (map.has(k)) return false;
              map.add(k);
              return true;
            });
            this.obs.set([...currentObs, ...extra]);
          }
        }
        this.savingFix.set(false);
      },
      error: (err) => {
        this.errorMsg.set(err?.error?.message || 'Error al enviar correcciones.');
        this.savingFix.set(false);
      }
    });
  }

  private async parseCsvLocal(file: File): Promise<{ rows: CsvRow[]; errors: CsvError[] }> {
    const text = await file.text();
    const lines = text.replace(/\r/g, '').split('\n').filter(l => l.trim().length > 0);
    if (lines.length === 0) {
      return {
        rows: [],
        errors: [{ linea: 1, detalle: 'Archivo CSV vacío', campo: 'global' }]
      };
    }

    const header = lines[0].split(',').map(h => h.trim().toLowerCase());
    const must = ['id','nombre','ci','area','nivel','unidad_educativa','profesor'];
    const missing = must.filter(m => !header.includes(m));
    if (missing.length) {
      return {
        rows: [],
        errors: [{
          linea: 1,
          detalle: `Faltan columnas obligatorias: ${missing.join(', ')}`,
          campo: 'global'
        }]
      };
    }

    const idx: Record<string, number> = {};
    for (const k of must) idx[k] = header.indexOf(k);

    const rows: CsvRow[] = [];
    const errors: CsvError[] = [];

    for (let i = 1; i < lines.length; i++) {
      const linea = i + 1;
      const parts = lines[i].split(',');
      const row: CsvRow = {
        linea,
        id: parts[idx['id']]?.trim() || null,
        nombre: parts[idx['nombre']]?.trim() || null,
        ci: parts[idx['ci']]?.trim() || null,
        area: parts[idx['area']]?.trim() || null,
        nivel: parts[idx['nivel']]?.trim() || null,
        unidad_educativa: parts[idx['unidad_educativa']]?.trim() || null,
        profesor: parts[idx['profesor']]?.trim() || null,
      };
      rows.push(row);

      if (!row.nombre)            errors.push({ linea, campo: 'nombre',            detalle: 'Nombre vacío' });
      if (!row.ci)                errors.push({ linea, campo: 'ci',                detalle: 'CI vacío' });
      if (!row.area)              errors.push({ linea, campo: 'area',              detalle: 'Área vacía' });
      if (!row.nivel)             errors.push({ linea, campo: 'nivel',             detalle: 'Nivel vacío' });
      if (!row.unidad_educativa)  errors.push({ linea, campo: 'unidad_educativa',  detalle: 'Unidad educativa vacía' });
      if (!row.profesor)          errors.push({ linea, campo: 'profesor',          detalle: 'Profesor vacío' });
    }

    const seen = new Map<string, number>();
    for (const r of rows) {
      if (!r.ci) continue;
      if (seen.has(r.ci)) {
        const first = seen.get(r.ci)!;
        errors.push({
          linea: r.linea,
          campo: 'ci',
          detalle: `CI duplicado en archivo (también en línea ${first})`
        });
      } else {
        seen.set(r.ci, r.linea);
      }
    }

    return { rows, errors };
  }

  getCellErrors(linea: number, campo: CsvError['campo']): string[] {
    return this.obs()
      .filter(e => e.linea === linea && e.campo === campo)
      .map(e => e.detalle);
  }

  getRowErrors(linea: number): string[] {
    return this.obs()
      .filter(e => e.linea === linea && e.campo !== 'global')
      .map(e => e.campo && e.campo !== 'global'
        ? `${e.campo}: ${e.detalle}`
        : e.detalle
      );
  }

  trackEdit = (_: number, r: EditRow) => r.linea;
}
