import { CommonModule } from '@angular/common';
import { Component, inject, signal } from '@angular/core';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { ApiService } from '../../core/api.service';

type EstadoEdicion = 'borrador' | 'activa' | 'cerrada';

type Edicion = {
  id: number;
  nombre_oficial: string;
  estado: EstadoEdicion;
};

type Medalla = 'oro' | 'plata' | 'bronce';

type MedalleroItem = {
  area?: string;
  nivel?: string;
  medalla: Medalla;
  participante?: string;
  colegio?: string;
  puntaje?: number | null;
};

const ENDPOINTS = {
  edicion: (id: number) => `/admin/ediciones/${id}`,
  medallero: (id: number) => `/admin/ediciones/${id}/medallero`,
};

@Component({
  standalone: true,
  selector: 'app-edicion-medallero',
  imports: [CommonModule, RouterModule],
  template: `
  <section class="space-y-4">

    <div class="bg-white border border-slate-200 rounded-2xl p-4 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3">
      <div class="min-w-0">
        <a class="text-xs text-slate-500 hover:text-slate-700 inline-flex items-center gap-1"
           [routerLink]="['/admin/ediciones', edicionId(), 'configuracion']">
          <i class="bi bi-arrow-left"></i> Volver a configuración
        </a>

        <h1 class="text-lg md:text-xl font-bold tracking-tight mt-1 truncate">
          Medallero
        </h1>

        <div class="text-sm text-slate-500">
          {{ edicion()?.nombre_oficial || '—' }} · Estado: <strong>{{ edicion()?.estado || '—' }}</strong>
        </div>
      </div>

      <div class="flex items-center gap-2">
        <button class="rounded-lg bg-white border border-slate-200 px-4 py-2 text-sm hover:bg-slate-50"
                (click)="reload()" [disabled]="loading()">
          <i class="bi bi-arrow-repeat"></i> Actualizar
        </button>
      </div>
    </div>

    <div *ngIf="error()" class="rounded-2xl border border-red-200 bg-red-50 p-4 text-red-700 text-sm">
      {{ error() }}
    </div>

    <div class="bg-white border border-slate-200 rounded-2xl overflow-hidden">
      <div class="p-4 border-b border-slate-200 flex items-center justify-between">
        <div class="font-semibold text-sm">Resultados por área/nivel</div>
        <div class="text-xs text-slate-500" *ngIf="loading()">Cargando...</div>
      </div>

      <div *ngIf="!loading() && items().length===0" class="py-10 text-center text-slate-400 text-sm">
        Sin datos de medallero.
      </div>

      <div *ngIf="items().length>0" class="overflow-x-auto">
        <table class="min-w-full text-sm">
          <thead class="bg-slate-50 text-slate-600">
            <tr class="text-left">
              <th class="py-2 px-3">Área</th>
              <th class="py-2 px-3">Nivel</th>
              <th class="py-2 px-3">Medalla</th>
              <th class="py-2 px-3">Participante</th>
              <th class="py-2 px-3">Colegio</th>
              <th class="py-2 px-3">Puntaje</th>
            </tr>
          </thead>

          <tbody>
            <tr *ngFor="let it of items()" class="border-t border-slate-100">
              <td class="py-2 px-3">{{ it.area || '—' }}</td>
              <td class="py-2 px-3">{{ it.nivel || '—' }}</td>
              <td class="py-2 px-3">
                <span class="px-2 py-0.5 rounded-full border text-xs"
                      [ngClass]="medallaBadge(it.medalla)">
                  {{ it.medalla }}
                </span>
              </td>
              <td class="py-2 px-3 font-semibold text-slate-800">{{ it.participante || '—' }}</td>
              <td class="py-2 px-3 text-xs text-slate-700">{{ it.colegio || '—' }}</td>
              <td class="py-2 px-3">{{ it.puntaje ?? '—' }}</td>
            </tr>
          </tbody>
        </table>
      </div>

    </div>

  </section>
  `,
})
export class EdicionMedalleroComponent {
  private api = inject(ApiService);
  private route = inject(ActivatedRoute);

  edicionId = signal<number | null>(null);
  edicion = signal<Edicion | null>(null);

  items = signal<MedalleroItem[]>([]);
  loading = signal(false);
  error = signal<string | null>(null);

  ngOnInit() {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    if (!id || Number.isNaN(id)) {
      this.error.set('ID de edición inválido.');
      return;
    }
    this.edicionId.set(id);
    this.reload();
  }

  reload() {
    const id = this.edicionId();
    if (!id) return;

    this.loading.set(true);
    this.error.set(null);

    this.api.get<{ ok: boolean; data: Edicion }>(ENDPOINTS.edicion(id)).subscribe({
      next: (r) => {
        if (!r?.ok) {
          this.loading.set(false);
          this.error.set('No se pudo cargar la competencia.');
          return;
        }
        this.edicion.set(r.data);

        this.api.get<{ ok: boolean; data: MedalleroItem[] }>(ENDPOINTS.medallero(id)).subscribe({
          next: (r2) => {
            this.loading.set(false);
            if (!r2?.ok) {
              this.error.set('No se pudo cargar el medallero.');
              this.items.set([]);
              return;
            }
            this.items.set(r2.data || []);
          },
          error: () => {
            this.loading.set(false);
            this.error.set('No se pudo cargar el medallero.');
            this.items.set([]);
          }
        });
      },
      error: () => {
        this.loading.set(false);
        this.error.set('No se pudo cargar la competencia.');
      }
    });
  }

  medallaBadge(m: Medalla) {
    if (m === 'oro') return 'bg-amber-50 text-amber-800 border-amber-200';
    if (m === 'plata') return 'bg-slate-50 text-slate-700 border-slate-200';
    return 'bg-orange-50 text-orange-700 border-orange-200';
  }
}
