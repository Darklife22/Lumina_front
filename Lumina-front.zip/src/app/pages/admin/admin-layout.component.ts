// src/app/pages/admin/admin-layout.component.ts
import { Component, inject, signal, effect, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  Router,
  RouterLink,
  RouterLinkActive,
  RouterOutlet,
  NavigationEnd,
} from '@angular/router';
import { filter } from 'rxjs/operators';
import { AuthService } from '../../core/auth.service';
import { ApiService } from '../../core/api.service';

@Component({
  standalone: true,
  selector: 'app-admin-layout',
  imports: [CommonModule, RouterLink, RouterLinkActive, RouterOutlet],
  template: `
    <!-- ROOT: usar 100dvh para evitar el “espacio arriba” en móviles -->
    <div class="h-[100dvh] w-full bg-slate-100 text-slate-800 overflow-hidden">
      <!-- WRAPPER: flex + min-h-0 para que el overflow funcione -->
      <div class="h-full min-h-0 flex">

        <!-- Overlay móvil -->
        <div
          *ngIf="sidebarOpen() && isMobile()"
          class="fixed inset-0 z-30 bg-black/50 md:hidden"
          (click)="closeSidebar()"
        ></div>

        <!-- Sidebar -->
        <aside
          class="fixed md:static top-0 left-0 z-40
                 h-[100dvh] md:h-full
                 w-72 md:w-64
                 bg-gradient-to-b from-[#0b1f46] via-[#13366f] to-[#1a55a9] text-white
                 shadow-lg
                 transform transition-transform duration-300 ease-in-out
                 flex flex-col
                 md:translate-x-0"
          [class.-translate-x-full]="!sidebarOpen() && isMobile()"
        >
          <!-- Importante: min-h-0 para que el scroll interno no “empuje” -->
          <div class="flex-1 min-h-0 flex flex-col">
            <!-- Header sidebar (no scrollea) -->
            <div class="p-4 flex items-center gap-2">
              <img src="/logo/logo.png" alt="Logo" class="h-8 w-auto" />
              <div class="leading-tight">
                <div class="font-bold tracking-wide text-lg">Oh! SanSi</div>
                <div class="text-[11px] opacity-80">Admin Console</div>
              </div>
            </div>

            <!-- Nav: único scroll del sidebar -->
            <nav class="flex-1 min-h-0 overflow-y-auto px-3 pb-4 space-y-1">
              <a
                *ngFor="let link of links"
                [routerLink]="link.path"
                routerLinkActive="bg-white/20"
                [routerLinkActiveOptions]="{ exact: true }"
                class="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-white/10 transition"
                (click)="onNavClick()"
              >
                <i class="bi" [ngClass]="link.icon"></i>
                <span class="truncate">{{ link.label }}</span>
              </a>
            </nav>
          </div>

          <!-- Footer sidebar (no scrollea) -->
          <div class="bg-white/10 rounded-xl p-3 m-4 mt-0 flex-none">
            <div class="text-xs opacity-90">
              {{ userName() || 'Administrador' }}
            </div>
            <div class="text-[11px] opacity-70">Admin</div>
            <button
              (click)="logout()"
              class="mt-3 w-full text-sm rounded-lg bg-white/20 hover:bg-white/25 py-2 transition"
            >
              <i class="bi bi-box-arrow-right me-1"></i> Salir
            </button>
          </div>
        </aside>



        <!-- Main content -->
        <main class="flex-1 min-w-0 min-h-0 flex flex-col">
          <!-- Header -->
          <header class="flex-none sticky top-0 z-20 bg-white border-b border-slate-200/70 shadow-sm">
            <div class="w-full px-4 py-4 flex items-center justify-between gap-3">
              <h1 class="text-xl md:text-2xl font-bold tracking-tight text-slate-800 truncate">
                {{ pageTitle() }}
              </h1>

              <button
                (click)="toggleSidebar()"
                class="md:hidden inline-flex items-center justify-center w-10 h-10 rounded-lg border border-slate-200 hover:bg-slate-50 flex-none"
              >
                <i class="bi bi-list text-xl"></i>
              </button>
            </div>
          </header>

          <!-- Área de contenido: único scroll del main -->
          <section class="flex-1 min-h-0 overflow-y-auto px-4 py-4">
            <router-outlet></router-outlet>
          </section>
        </main>
      </div>
    </div>
  `,
})
export class AdminLayoutComponent {
  private auth = inject(AuthService);
  private api = inject(ApiService);
  private router = inject(Router);

  sidebarOpen = signal(false);
  userName = signal(this.auth.user()?.nombre ?? null);
  pageTitle = signal('Panel de control');

  links = [
    { path: '/admin', label: 'Dashboard', icon: 'bi-speedometer' },
    { path: '/admin/usuarios', label: 'Usuarios', icon: 'bi-person-gear' },
    { path: '/admin/importaciones', label: 'Importaciones', icon: 'bi-upload' },
    { path: '/admin/responsables', label: 'Responsables', icon: 'bi-person-badge' },
    { path: '/admin/evaluadores', label: 'Evaluadores', icon: 'bi-people' },
    { path: '/admin/areas', label: 'Áreas', icon: 'bi-diagram-3' },
    { path: '/admin/ediciones', label: 'Ediciones', icon: 'bi-calendar3' },
    { path: '/admin/evaluaciones', label: 'Evaluaciones', icon: 'bi-card-checklist' },
    { path: '/admin/clasificacion', label: 'Clasificación', icon: 'bi-trophy' },
    { path: '/admin/filtro-clasificacion', label: 'Filtro por Umbral', icon: 'bi-funnel' },
    { path: '/admin/final', label: 'Final', icon: 'bi-flag' },
    { path: '/admin/reportes', label: 'Reportes', icon: 'bi-file-earmark-text' },
    { path: '/admin/medallero', label: 'Medallero', icon: 'bi-award' },
  ];

  constructor() {
    // Governance: redirección inmediata si no hay sesión
    effect(() => {
      if (!this.auth.isLoggedIn()) this.router.navigateByUrl('/login');
    });

    // UX: cerrar sidebar en móvil al navegar + actualizar título
    this.router.events
      .pipe(filter((e) => e instanceof NavigationEnd))
      .subscribe(() => {
        if (this.isMobile()) this.sidebarOpen.set(false);

        let r = this.router.routerState.snapshot.root;
        while (r.firstChild) r = r.firstChild;
        this.pageTitle.set(r.data?.['title'] || 'Panel de control');
      });
  }

  isMobile() {
    return window.innerWidth < 768;
  }

  toggleSidebar() {
    if (!this.isMobile()) return; // en desktop no hace falta
    this.sidebarOpen.set(!this.sidebarOpen());
  }

  closeSidebar() {
    this.sidebarOpen.set(false);
  }

  onNavClick() {
    if (this.isMobile()) this.closeSidebar();
  }

  @HostListener('window:resize')
  onResize() {
    // si pasa a desktop, cerramos estado móvil y evitamos overlays zombis
    if (!this.isMobile()) this.sidebarOpen.set(false);
  }

  logout() {
    this.api.post('/logout', {}).subscribe({
      next: () => {
        this.auth.clear();
        this.router.navigateByUrl('/login');
      },
      error: () => {
        this.auth.clear();
        this.router.navigateByUrl('/login');
      },
    });
  }
}
