import { CommonModule } from '@angular/common';
import { Component, inject, signal, computed } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { ApiService } from '../../core/api.service';

type EstadoEdicion = 'borrador' | 'activa' | 'cerrada';

type Edicion = {
  id: number;
  nombre_oficial: string;
  estado: EstadoEdicion;
  fecha_inicio: string;
  fecha_fin: string;
};

type UsuarioLite = {
  id: number;
  nombre?: string;
  apellido?: string;
  email?: string;
  rol?: string;
};

type RolesEdicion = {
  responsables: UsuarioLite[];
  evaluadores: UsuarioLite[];
  locks?: {
    roles?: boolean;
  };
  deps?: {
    evaluaciones?: number;
    resultados?: number;
  };
};

const ENDPOINTS = {
  edicion: (id: number) => `/admin/ediciones/${id}`,
  roles: (id: number) => `/admin/ediciones/${id}/roles`,
  searchUsuarios: `/admin/usuarios`, // recomendado: GET ?q=...&rol=...
};

@Component({
  standalone: true,
  selector: 'app-edicion-roles',
  imports: [CommonModule, FormsModule, RouterModule],
  template: `
  <section class="space-y-4">

    <div class="bg-white border border-slate-200 rounded-2xl p-4 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3">
      <div class="min-w-0">
        <a class="text-xs text-slate-500 hover:text-slate-700 inline-flex items-center gap-1"
           [routerLink]="['/admin/ediciones', edicionId(), 'configuracion']">
          <i class="bi bi-arrow-left"></i> Volver a configuración
        </a>

        <h1 class="text-lg md:text-xl font-bold tracking-tight mt-1 truncate">
          Roles de la competencia
        </h1>
        <div class="text-sm text-slate-500">
          {{ edicion()?.nombre_oficial || '—' }}
          <span class="text-slate-300">·</span>
          {{ edicion()?.fecha_inicio }} – {{ edicion()?.fecha_fin }}
        </div>

        <div class="mt-1 text-[11px] text-slate-500" *ngIf="roles()?.deps">
          Dependencias: <strong>{{ roles()?.deps?.evaluaciones ?? 0 }}</strong> evaluaciones ·
          <strong>{{ roles()?.deps?.resultados ?? 0 }}</strong> resultados
        </div>
      </div>

      <div class="flex items-center gap-2">
        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs border"
              [ngClass]="isLocked() ? 'bg-slate-50 text-slate-600 border-slate-200' : 'bg-emerald-50 text-emerald-700 border-emerald-200'">
          <i class="bi" [ngClass]="isLocked() ? 'bi-lock-fill' : 'bi-unlock'"></i>
          <span class="ml-1">{{ isLocked() ? 'Bloqueado' : 'Editable' }}</span>
        </span>

        <button class="rounded-lg bg-white border border-slate-200 px-4 py-2 text-sm hover:bg-slate-50"
                (click)="reload()" [disabled]="loading()">
          <i class="bi bi-arrow-repeat"></i> Actualizar
        </button>
      </div>
    </div>

    <div *ngIf="error()" class="rounded-2xl border border-red-200 bg-red-50 p-4 text-red-700 text-sm">
      {{ error() }}
    </div>

    <div class="grid lg:grid-cols-2 gap-4">

      <!-- RESPONSABLES -->
      <div class="bg-white border border-slate-200 rounded-2xl overflow-hidden">
        <div class="p-4 border-b border-slate-200 flex items-center justify-between">
          <div>
            <div class="font-semibold text-sm">Responsables</div>
            <div class="text-xs text-slate-500">Asignación por edición (scope).</div>
          </div>
          <div class="text-xs text-slate-500">{{ (roles()?.responsables?.length ?? 0) }} asignados</div>
        </div>

        <div class="p-4 space-y-3">
          <div class="flex gap-2">
            <input [(ngModel)]="qResp"
                   (keyup.enter)="buscar('responsable')"
                   placeholder="Buscar usuario (nombre/email)..."
                   class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-200 focus:border-blue-300"
                   [disabled]="isLocked()">
            <button class="rounded-lg bg-[#0f3f94] hover:bg-[#0d3580] text-white px-3 py-2 text-sm"
                    (click)="buscar('responsable')" [disabled]="isLocked()">
              <i class="bi bi-search"></i>
            </button>
          </div>

          <div *ngIf="buscando()" class="text-sm text-slate-400 py-6 text-center">
            Buscando...
          </div>

          <div *ngIf="!buscando() && resultados().length>0" class="space-y-2">
            <div *ngFor="let u of resultados()" class="rounded-xl border border-slate-200 px-3 py-2 flex items-center justify-between gap-3">
              <div class="min-w-0">
                <div class="text-sm font-medium text-slate-800 truncate">
                  {{ labelUser(u) }}
                </div>
                <div class="text-[11px] text-slate-500 truncate">
                  ID {{ u.id }} <span *ngIf="u.email">· {{ u.email }}</span>
                </div>
              </div>
              <button class="rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-1.5 text-xs font-semibold"
                      (click)="asignar(u.id, 'responsable')" [disabled]="isLocked()">
                <i class="bi bi-plus-lg"></i> Asignar
              </button>
            </div>
          </div>

          <div class="mt-3 space-y-2">
            <div *ngFor="let u of (roles()?.responsables || [])" class="rounded-xl border border-slate-200 px-3 py-2 flex items-center justify-between gap-3">
              <div class="min-w-0">
                <div class="text-sm font-semibold text-slate-800 truncate">{{ labelUser(u) }}</div>
                <div class="text-[11px] text-slate-500 truncate">ID {{ u.id }} <span *ngIf="u.email">· {{ u.email }}</span></div>
              </div>
              <button class="rounded-lg bg-white border border-slate-200 px-3 py-1.5 text-xs hover:bg-slate-50"
                      (click)="quitar(u.id, 'responsable')" [disabled]="isLocked()">
                <i class="bi bi-x-lg"></i> Quitar
              </button>
            </div>

            <div *ngIf="(roles()?.responsables?.length ?? 0) === 0" class="text-sm text-slate-400 py-6 text-center">
              Sin responsables asignados.
            </div>
          </div>
        </div>
      </div>

      <!-- EVALUADORES -->
      <div class="bg-white border border-slate-200 rounded-2xl overflow-hidden">
        <div class="p-4 border-b border-slate-200 flex items-center justify-between">
          <div>
            <div class="font-semibold text-sm">Evaluadores</div>
            <div class="text-xs text-slate-500">Asignación por edición (scope).</div>
          </div>
          <div class="text-xs text-slate-500">{{ (roles()?.evaluadores?.length ?? 0) }} asignados</div>
        </div>

        <div class="p-4 space-y-3">
          <div class="flex gap-2">
            <input [(ngModel)]="qEval"
                   (keyup.enter)="buscar('evaluador')"
                   placeholder="Buscar usuario (nombre/email)..."
                   class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-200 focus:border-blue-300"
                   [disabled]="isLocked()">
            <button class="rounded-lg bg-[#0f3f94] hover:bg-[#0d3580] text-white px-3 py-2 text-sm"
                    (click)="buscar('evaluador')" [disabled]="isLocked()">
              <i class="bi bi-search"></i>
            </button>
          </div>

          <div *ngIf="buscando()" class="text-sm text-slate-400 py-6 text-center">
            Buscando...
          </div>

          <div *ngIf="!buscando() && resultados().length>0" class="space-y-2">
            <div *ngFor="let u of resultados()" class="rounded-xl border border-slate-200 px-3 py-2 flex items-center justify-between gap-3">
              <div class="min-w-0">
                <div class="text-sm font-medium text-slate-800 truncate">
                  {{ labelUser(u) }}
                </div>
                <div class="text-[11px] text-slate-500 truncate">
                  ID {{ u.id }} <span *ngIf="u.email">· {{ u.email }}</span>
                </div>
              </div>
              <button class="rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-1.5 text-xs font-semibold"
                      (click)="asignar(u.id, 'evaluador')" [disabled]="isLocked()">
                <i class="bi bi-plus-lg"></i> Asignar
              </button>
            </div>
          </div>

          <div class="mt-3 space-y-2">
            <div *ngFor="let u of (roles()?.evaluadores || [])" class="rounded-xl border border-slate-200 px-3 py-2 flex items-center justify-between gap-3">
              <div class="min-w-0">
                <div class="text-sm font-semibold text-slate-800 truncate">{{ labelUser(u) }}</div>
                <div class="text-[11px] text-slate-500 truncate">ID {{ u.id }} <span *ngIf="u.email">· {{ u.email }}</span></div>
              </div>
              <button class="rounded-lg bg-white border border-slate-200 px-3 py-1.5 text-xs hover:bg-slate-50"
                      (click)="quitar(u.id, 'evaluador')" [disabled]="isLocked()">
                <i class="bi bi-x-lg"></i> Quitar
              </button>
            </div>

            <div *ngIf="(roles()?.evaluadores?.length ?? 0) === 0" class="text-sm text-slate-400 py-6 text-center">
              Sin evaluadores asignados.
            </div>
          </div>
        </div>
      </div>

    </div>

  </section>
  `,
})
export class EdicionRolesComponent {
  private api = inject(ApiService);
  private route = inject(ActivatedRoute);

  edicionId = signal<number | null>(null);
  edicion = signal<Edicion | null>(null);
  roles = signal<RolesEdicion | null>(null);

  loading = signal(false);
  buscando = signal(false);
  error = signal<string | null>(null);

  qResp = '';
  qEval = '';
  resultados = signal<UsuarioLite[]>([]);

  ngOnInit() {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    if (!id || Number.isNaN(id)) {
      this.error.set('ID de edición inválido.');
      return;
    }
    this.edicionId.set(id);
    this.reload();
  }

  reload() {
    const id = this.edicionId();
    if (!id) return;

    this.loading.set(true);
    this.error.set(null);
    this.resultados.set([]);

    this.api.get<{ ok: boolean; data: Edicion }>(ENDPOINTS.edicion(id)).subscribe({
      next: (r) => {
        if (!r?.ok) {
          this.error.set('No se pudo cargar la competencia.');
          this.loading.set(false);
          return;
        }
        this.edicion.set(r.data);

        this.api.get<{ ok: boolean; data: RolesEdicion }>(ENDPOINTS.roles(id)).subscribe({
          next: (r2) => {
            this.loading.set(false);
            if (!r2?.ok) {
              this.error.set('No se pudo cargar roles de la competencia.');
              return;
            }
            const data = r2.data || ({} as RolesEdicion);
            data.responsables = Array.isArray(data.responsables) ? data.responsables : [];
            data.evaluadores = Array.isArray(data.evaluadores) ? data.evaluadores : [];
            data.locks = data.locks || {};
            data.deps = data.deps || { evaluaciones: 0, resultados: 0 };

            // Bloqueo sugerido por estado si backend no lo manda
            if (typeof data.locks.roles === 'undefined') {
              data.locks.roles = (this.edicion()?.estado === 'cerrada');
            }

            this.roles.set(data);
          },
          error: () => {
            this.loading.set(false);
            this.error.set('No se pudo cargar roles de la competencia.');
          }
        });
      },
      error: () => {
        this.loading.set(false);
        this.error.set('No se pudo cargar la competencia.');
      }
    });
  }

  isLocked(): boolean {
    const ed = this.edicion();
    const lock = this.roles()?.locks?.roles;
    if (lock) return true;
    return ed?.estado === 'cerrada';
  }

  buscar(tipo: 'responsable' | 'evaluador') {
    if (this.isLocked()) return;

    const q = (tipo === 'responsable' ? this.qResp : this.qEval).trim();
    if (!q) {
      this.resultados.set([]);
      return;
    }

    this.buscando.set(true);
    this.resultados.set([]);

    // Contract recomendado:
    // GET /admin/usuarios?q=...&rol=responsable_area | evaluador
    const rol = (tipo === 'responsable') ? 'responsable_area' : 'evaluador';
    const url = `${ENDPOINTS.searchUsuarios}?q=${encodeURIComponent(q)}&rol=${encodeURIComponent(rol)}`;

    this.api.get<{ ok: boolean; data: UsuarioLite[] }>(url).subscribe({
      next: (r) => {
        this.buscando.set(false);
        this.resultados.set(r?.ok ? (r.data || []) : []);
      },
      error: () => {
        this.buscando.set(false);
        this.resultados.set([]);
      }
    });
  }

  asignar(userId: number, tipo: 'responsable' | 'evaluador') {
    const id = this.edicionId();
    if (!id || this.isLocked()) return;

    const payload = { user_id: userId, tipo };

    this.api.post<{ ok: boolean; message?: string }>(ENDPOINTS.roles(id), payload).subscribe({
      next: (r) => {
        if (!r?.ok) {
          this.error.set(r?.message || 'No se pudo asignar.');
          return;
        }
        this.error.set(null);
        this.resultados.set([]);
        this.reload();
      },
      error: (err) => {
        this.error.set(err?.error?.message || 'No se pudo asignar.');
      }
    });
  }

  quitar(userId: number, tipo: 'responsable' | 'evaluador') {
    const id = this.edicionId();
    if (!id || this.isLocked()) return;

    // Contract recomendado: DELETE /admin/ediciones/:id/roles?tipo=...&user_id=...
    const url = `${ENDPOINTS.roles(id)}?tipo=${encodeURIComponent(tipo)}&user_id=${encodeURIComponent(String(userId))}`;

    this.api.delete<{ ok: boolean; message?: string }>(url).subscribe({
      next: (r) => {
        if (!r?.ok) {
          this.error.set(r?.message || 'No se pudo quitar.');
          return;
        }
        this.error.set(null);
        this.reload();
      },
      error: (err) => {
        this.error.set(err?.error?.message || 'No se pudo quitar.');
      }
    });
  }

  labelUser(u: UsuarioLite): string {
    const full = `${u.nombre ?? ''} ${u.apellido ?? ''}`.trim();
    return full || u.email || `Usuario ${u.id}`;
  }
}
