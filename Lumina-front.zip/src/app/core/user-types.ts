export type Role = 'admin' | 'responsable_area' | 'evaluador' | 'consulta';

export type AuthUser = {
  id: number;
  nombre: string;
  email: string;
  role: Role;
  token: string;
};
