import { CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';
import { AuthService } from './auth.service';

export function requireRole(...roles: Array<'admin'|'responsable_area'|'evaluador'|'consulta'>): CanActivateFn {
  return () => {
    const auth = inject(AuthService);
    const router = inject(Router);
    const u = auth.user();
    if (!u) { router.navigate(['/login']); return false; }
    if (!roles.length || roles.includes(u.role)) return true;
    router.navigate(['/']);
    return false;
  };
}
