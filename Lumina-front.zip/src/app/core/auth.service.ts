import { Injectable, signal } from '@angular/core';
import { AuthUser } from './user-types';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private _user = signal<AuthUser | null>(null);

  constructor() {
    const token = localStorage.getItem('token');
    const user = localStorage.getItem('user');
    if (token && user) {
      try {
        const parsed = JSON.parse(user) as Omit<AuthUser, 'token'>;
        this._user.set({ ...parsed, token });
      } catch {
        localStorage.removeItem('user');
        localStorage.removeItem('token');
      }
    }
  }

  /** Devuelve el usuario actual */
  user() {
    return this._user();
  }

  /** Devuelve el rol del usuario (admin, responsable, evaluador, etc.) */
  role() {
    return this._user()?.role ?? null;
  }

  /** Devuelve el token JWT actual (o null si no hay sesión) */
  token() {
    return this._user()?.token ?? localStorage.getItem('token');
  }

  /** Indica si hay sesión activa */
  isLoggedIn() {
    return !!this.token();
  }

  /** Guarda los datos del usuario y token */
  setUser(u: AuthUser) {
    this._user.set(u);
    localStorage.setItem('token', u.token);
    localStorage.setItem(
      'user',
      JSON.stringify({
        id: u.id,
        nombre: u.nombre,
        email: u.email,
        role: u.role,
      })
    );
  }

  /** Cierra sesión limpiando storage y signal */
  clear() {
    this._user.set(null);
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  }
}
