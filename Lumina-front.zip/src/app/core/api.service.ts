// src/app/core/api.service.ts
import { Injectable, inject } from '@angular/core';
import {
  HttpClient,
  HttpHeaders,
  HttpParams
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class ApiService {
  private http = inject(HttpClient);
  private auth = inject(AuthService);

  // Base de la API
  base = environment.apiBaseUrl || 'http://localhost:8000/api';

  // ================================
  // HEADERS CON AUTH
  // ================================
  private headers(json = true): HttpHeaders {
    const token = this.auth.token();

    let headers = new HttpHeaders({
      Accept: 'application/json',
      'X-Requested-With': 'XMLHttpRequest',
    });

    if (token) {
      headers = headers.set('Authorization', `Bearer ${token}`);
    }

    // HttpClient ya maneja Content-Type cuando es JSON
    return headers;
  }

  // ================================
  // URL ABSOLUTA
  // ================================
  private buildUrl(url: string): string {
    if (url.startsWith('http://') || url.startsWith('https://')) {
      return url;
    }
    return this.base + url;
  }

  // ================================
  // MÉTODOS CRUD BÁSICOS
  // ================================
  get<T>(url: string, params?: Record<string, string | number | boolean | undefined | null>): Observable<T> {
    let httpParams = new HttpParams();
    if (params) {
      Object.keys(params).forEach(k => {
        const v = params[k];
        if (v !== undefined && v !== null && v !== '') {
          httpParams = httpParams.set(k, String(v));
        }
      });
    }
    return this.http.get<T>(this.buildUrl(url), {
      headers: this.headers(),
      params: httpParams
    });
  }

  post<T>(url: string, body: any): Observable<T> {
    return this.http.post<T>(this.buildUrl(url), body, {
      headers: this.headers()
    });
  }

  postForm<T>(url: string, form: FormData): Observable<T> {
    // No seteamos Content-Type: el navegador lo hace (multipart/form-data)
    return this.http.post<T>(this.buildUrl(url), form, {
      headers: this.headers(false)
    });
  }

  put<T>(url: string, body: any): Observable<T> {
    return this.http.put<T>(this.buildUrl(url), body, {
      headers: this.headers()
    });
  }

  patch<T>(url: string, body: any): Observable<T> {
    return this.http.patch<T>(this.buildUrl(url), body, {
      headers: this.headers()
    });
  }

  delete<T>(url: string): Observable<T> {
    return this.http.delete<T>(this.buildUrl(url), {
      headers: this.headers()
    });
  }

  // ============================================================
  // 🔥 DOWNLOAD — CSV / "PDF" (HTML) CON TOKEN
  // ============================================================
  download(
    url: string,
    params?: Record<string, string | number | boolean | undefined | null>
  ): Observable<Blob> {
    let httpParams = new HttpParams();
    if (params) {
      Object.keys(params).forEach(k => {
        const v = params[k];
        if (v !== undefined && v !== null && v !== '') {
          httpParams = httpParams.set(k, String(v));
        }
      });
    }

    return this.http.get(this.buildUrl(url), {
      headers: this.headers(),
      params: httpParams,
      responseType: 'blob' // Siempre blob, luego tú decides si lo tratas como CSV o HTML
    });
  }
}
