// src/app/core/env.ts 
export const environment = {
  production: false,
  apiBaseUrl: 'http://localhost:8000/api'
};

// src/app/core/env.ts
// export const environment = {
//   production: true,
//   apiBaseUrl: 'https://loscastoresbol.com/Lumina_back/public/api'
// };
