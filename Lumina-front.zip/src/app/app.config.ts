import { ApplicationConfig, importProvidersFrom } from '@angular/core';
import { provideRouter, withInMemoryScrolling } from '@angular/router';
// CORRECCIÓN 1: 'appRoutes' no existe. El archivo exporta 'routes'.
import { routes } from './app.routes';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
// CORRECCIÓN 2: 'apiInterceptor' no existe. El archivo exporta 'authInterceptor'.
import { authInterceptor } from './core/api.interceptor';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';

export const appConfig: ApplicationConfig = {
  providers: [
    // Usamos el nombre 'routes' corregido
    provideRouter(routes, withInMemoryScrolling({ anchorScrolling: 'enabled', scrollPositionRestoration: 'enabled' })),
    // Usamos el nombre 'authInterceptor' corregido
    provideHttpClient(withInterceptors([authInterceptor])), provideAnimationsAsync(),
  ]
};