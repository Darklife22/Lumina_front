/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{html,ts}", // 👈 muy importante
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          primary: "#0f3f94",
          secondary: "#1a55a9",
          accent: "#E63A48",
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
